# Industrialisation V1 des règles DQ sur SQL Server

Dossier de **conception** pour passer des règles DQ validées (moteur Python du projet) à
une chaîne SQL Server industrialisée : une table source alimentée par le job SSIS, un
traitement SQL appelé après le job, des tables de résultats et de score, et un modèle
Power BI qui reprend le dashboard actuel. Seule la **proposition V1** (partie droite du
schéma « Proposition Industrialisation DQ ») est reprise ; l'ancien modèle (partie
gauche) est ignoré.

> **État : conception, non exécutée.** Aucun SQL Server n'était disponible pour écrire ce
> dossier. Les scripts de [`../../sql/`](../../sql/) n'ont **jamais été exécutés** : seule
> une vérification de syntaxe faible a été faite. La recette
> ([`sql/tests/recette_chiffres_cles.sql`](../../sql/tests/recette_chiffres_cles.sql))
> est faite pour valider les résultats dès que le serveur est disponible.
> Le dossier s'appuie sur les règles et chiffres de la PR #12 (décisions du 2026-11-11).

## Périmètre

| Dans le périmètre | Hors périmètre |
|---|---|
| Table source « comptage API » (une ligne par train, colonnes JSON) alimentée par SSIS | GTFS (plan de transport) |
| Staging, contrôles techniques, éclatement du JSON | « Réalisé » |
| Les 14 règles DQ (décisions validées appliquées) | Cube SSAS (non disponible, remplacé, voir 05) |
| Score, verdict, imputation | Corrections de la donnée (le projet qualifie, il ne corrige pas) |
| Tables de restitution et modèle Power BI (pages du dashboard, DAX, drill-down) | |

## Lecture conseillée

| # | Document | Contenu |
|---|---|---|
| 01 | [01_architecture_cible.md](01_architecture_cible.md) | Couches, flux, correspondance avec la V1, volumes |
| 02 | [02_modele_de_donnees.md](02_modele_de_donnees.md) | Dictionnaire des tables, clés, index |
| 03 | [03_regles_tsql.md](03_regles_tsql.md) | Les 14 règles : définition, mailles, statuts, procédure, chiffres attendus |
| 04 | [04_orchestration_exploitation.md](04_orchestration_exploitation.md) | Appel après SSIS, SQL Agent, rejeu, erreurs, rétention, droits, déploiement, recette |
| 05 | [05_performance_et_restitution.md](05_performance_et_restitution.md) | Alternative au cube : columnstore, agrégats matérialisés, actualisation incrémentale |
| 06 | [06_modele_power_bi.md](06_modele_power_bi.md) | Relations, pages, mesures DAX, drill-through, code M |
| 07 | [07_choix_a_trancher.md](07_choix_a_trancher.md) | Liste des décisions à prendre et hypothèses à confirmer |
| 08 | [08_guide_ssis_pas_a_pas.md](08_guide_ssis_pas_a_pas.md) | Guide pas à pas : installation SQL, packages SSIS des projets CFL_STA_COMPTAGE et CFL_DWH_COMPTAGE, tests, passage en QUAL |
| 09 | [09_lineage_et_pages.md](09_lineage_et_pages.md) | Lineage table par table (procédure, package SSIS, sources, lecteurs), chemin de la description des règles, tables lues par chaque page Power BI |

## Scripts SQL ([`sql/`](../../sql/))

Ordre d'installation dans [`sql/install.sql`](../../sql/install.sql) (mode SQLCMD). Les mêmes scripts, regroupés en **un seul fichier commenté** (but de chaque étape et de chaque requête) : [`sql/DQ_script_unique.sql`](../../sql/DQ_script_unique.sql), régénéré par `python sql/construire_script_unique.py` :

| Fichier | Rôle |
|---|---|
| `00_schemas.sql` | Schéma `audit` (et `comptage_API` s'il n'existe pas), rôles et droits |
| `01_source_et_staging.sql` | Synonyme vers la table source, vue typée, table de staging |
| `02_tables_parsing.sql` | `comptage_API.DQ_Train`, `comptage_API.DQ_Arret`, `comptage_API.DQ_ArretEVN`, `comptage_API.DQ_EVNAttendu`, vue des motifs d'arrêts manquants |
| `03_audit_catalogue_logs.sql` | Catalogue des règles, paramètres, exécutions, `LogsDQ`, `ScoresDQ`, `fn_BuildRunId` |
| `04_fonctions_parsing.sql` | `comptage_API.fn_DQ_Val`, `comptage_API.fn_DQ_EtatCapteur` |
| `05_proc_staging_parsing.sql` | Chargement du staging, contrôles techniques, éclatement du JSON |
| `07_ecriture_et_orchestrateur.sql` | Écriture commune des résultats, synthèse Train, orchestrateur |
| `regles/DQ01…DQ14_*.sql` | Une procédure par règle |
| `08_score.sql` | Score, couverture, verdict, imputation |
| `09_tables_restitution.sql`, `10_proc_restitution_et_vues.sql` | Modèle en étoile, rafraîchissement, vues V1 et vues Power BI |
| `11_pipeline.sql` | Procédure unique appelée après le job SSIS |
| `12_seed_catalogue.sql` | Les 14 règles et les paramètres du score |
| `13_maintenance.sql` | Purge et maintenance |
| `tests/recette_chiffres_cles.sql` | Comparaison aux chiffres de référence du moteur Python |
| `ssis/execute_sql_task.sql` | Exemples d'appel (SSIS, SQL Agent) |
| [`../../ssis/`](../../ssis/) | Packages `.dtsx` des projets CFL_STA_COMPTAGE et CFL_DWH_COMPTAGE (master packages et enfants), générés par `generer_packages.py` ; non ouverts dans Visual Studio, voir le guide 08 |

## En une phrase

Le job SSIS charge la table source ; une tâche « Exécuter SQL » appelle
`audit.usp_DQ_Pipeline_SIV_APC`, qui éclate le JSON, exécute les 14 procédures de règles,
calcule le score et reconstruit un modèle en étoile en columnstore ; Power BI importe ce
modèle (actualisation incrémentale) à la place du cube SSAS.
