# 06 – Modèle Power BI

> **TEST3** : les sources sont les tables `comptage_API.DQ_*` (liste de colonnes explicite) ; `FaitExecution` et `ParametresScore` viennent des tables `audit.*` ; `AggStatutRegle` n'existe plus. Voir [09_lineage_et_pages.md](09_lineage_et_pages.md) et le guide du pack TEST3.


Objectif : reproduire le dashboard actuel ([`dashboard/index.html`](../../dashboard/index.html))
sur le modèle `comptage_API.DQ_*`, hors GTFS et « réalisé ». Le modèle n'a pas été construit (Power BI
Desktop n'est pas installé) : ce document est le plan de construction, à valider par une
maquette. Pour comparer à l'ancien dashboard, les chiffres des pages doivent égaler ceux
de la recette ([03](03_regles_tsql.md), section 4).

> **Mise à jour 2026-11-19.** Le modèle est maintenant généré par
> [`src/build_powerbi_dwh.py`](../../src/build_powerbi_dwh.py) (projet `powerbi_dwh/DQ_DWH.pbip`) ; description
> et écarts avec ce plan : [`../01_documentation_technique.md`](../01_documentation_technique.md) § 9ter. Jamais
> testé sur un serveur (à confirmer). Écarts avec le plan ci-dessous : pas de table `_Mesures` (mesures rangées
> sur leur table), pas de hiérarchies ni de signets, pas de carte des gares, `DimStatut`, `DimGrain`, etc. sans changement.

## 1. Sources et relations

Sources : les vues `comptage_API.vw_DQ_*` (lecture seule, compte `db_dq_lecteur`). Mode
**import** (option A, voir 05).

| Table Power BI | Vue source | Rôle |
|---|---|---|
| DimDate | `comptage_API.vw_DQ_DimDate` | Calendrier (marquée table de dates) |
| DimTrain | `comptage_API.DQ_DimTrain` | Un train, ses 14 statuts, score, verdict, imputation |
| DimRegle | `comptage_API.vw_DQ_DimRegle` | Règles |
| DimStatut | `comptage_API.vw_DQ_DimStatut` | Statuts et couleurs |
| DimGrain | `comptage_API.vw_DQ_DimGrain` | Mailles Train / Arrêt / Véhicule |
| DimGare | `comptage_API.vw_DQ_DimGare` | Gares |
| FaitResultat | `comptage_API.vw_DQ_FaitResultat` | Résultat objet x règle |
| FaitArret | `comptage_API.vw_DQ_FaitArret` | Un arrêt (mesures, score) |
| FaitExecution | `comptage_API.vw_DQ_FaitExecution` | Suivi des exécutions |
| ParametresScore | `comptage_API.vw_DQ_ParametresScore` | Paramètres affichés |
| AggStatutRegle | `comptage_API.vw_DQ_AggStatutRegle` | **Non chargée en option A** ; réservée à l'option B (agrégat) |

Relations (toutes **un vers plusieurs**, filtre dans le sens dimension → fait,
`Direction croisée` : simple) :

| De (1) | Vers (*) | Colonne |
|---|---|---|
| DimDate | DimTrain | `DateKey` |
| DimTrain | FaitResultat | `CountingId` |
| DimTrain | FaitArret | `CountingId` |
| DimRegle | FaitResultat | `RegleKey` |
| DimStatut | FaitResultat | `StatutKey` |
| DimGrain | FaitResultat | `GrainKey` |
| DimGare | FaitArret | `StationCode` |
| DimGare | FaitResultat | `StationCode` |

À ne **pas** créer : une relation `DimDate` → `FaitResultat` (la date passe par
`DimTrain`, ce qui évite deux chemins), ni de relation bidirectionnelle (risque
d'ambiguïté entre `FaitArret` et `FaitResultat`). `FaitExecution` reste isolée.

## 2. Pages (reproduction du dashboard)

| Page Power BI | Page du dashboard | Visuels principaux | Source |
|---|---|---|---|
| Vue d'ensemble | Vue d'ensemble | 6 cartes (trains, arrêts, véhicules x arrêts, trains avec au moins un FAIL, arrêts sans donnée, trains aux capteurs extérieurs valides) ; barres empilées « Statut des 14 règles » avec segmenteur de maille (Train / Arrêt / Véhicule) ; FAIL par jour ; FAIL par ligne | FaitResultat, DimRegle, DimStatut, DimGrain, DimTrain |
| Score de confiance | Score de confiance | Histogramme des scores (`TrancheScore`) ; verdict par ligne ; décision d'imputation ; trains à imputer par position des arrêts manquants ; causes de chute en « Mauvaise » (règles les plus en échec chez les trains « Mauvaise ») ; tableau des paramètres du score | DimTrain, ParametresScore |
| Complétude et imputation | Complétude et imputation | Où manquent les arrêts dans le trajet (`MotifManquants`) ; arrêts sans donnée selon leur rôle (`StopType`) ; gares les plus souvent sans donnée ; taux de valeurs exploitables par train (DQ-12) ; règles non testables faute de données | FaitArret, DimTrain, DimGare |
| Capteurs (DQ-06) | Capteurs (DQ-06) | DQ-06 à chaque maille ; capteurs extérieurs valides à chaque maille ; DQ-06 par série de véhicule ; trains aux capteurs extérieurs valides par jour ; véhicules les plus souvent en défaut | FaitResultat (règle DQ-06), DimTrain |
| Trains | Trains | Table des trains avec 14 statuts en mise en forme conditionnelle, recherche, tri ; **page cible du drill-through** | DimTrain |
| Détail du train (masquée) | Détail par train | Arrêts du train avec occupation, flux, cumul, score ; résultats par règle | FaitArret, FaitResultat |
| Carte des gares (facultative) | Carte des gares | Carte à bulles : part d'arrêts sans donnée par gare (coordonnées et communes dans `DimGare`) | FaitArret, DimGare |
| Règles appliquées | Règles appliquées | Table `DimRegle` : calcul, choix validés, statut de validation, seuils | DimRegle |
| **Suivi des exécutions** (nouvelle) | — | Dernière exécution, statut, durée, règles en erreur, historique par jour | FaitExecution |

Hors périmètre : pages « GTFS vs comptage » et « Couverture du plan ».

Carte : le visuel de carte natif de Power BI reste moins riche que la carte actuelle
(couches des cantons et communes, filtre par heure). Page facultative ; voir 07, choix 17.

## 3. Mesures DAX

Les mesures sont définies dans une table `_Mesures`. Les noms français correspondent aux
libellés du dashboard.

```dax
-- Volumes
Nb Trains            = COUNTROWS ( DimTrain )
Nb Arrêts            = COUNTROWS ( FaitArret )
Nb Arrêts sans donnée = CALCULATE ( COUNTROWS ( FaitArret ), FaitArret[SansDonnee] = TRUE () )
Nb Véhicules x arrêts = CALCULATE ( COUNTROWS ( FaitResultat ), DimGrain[Grain] = "Véhicule", DimRegle[RuleCode] = "DQ-12" )  -- à vérifier à la recette

-- Statuts (à la maille et aux règles sélectionnées)
Nb Objets            = COUNTROWS ( FaitResultat )
Nb PASS              = CALCULATE ( [Nb Objets], DimStatut[Statut] = "PASS" )
Nb WARNING           = CALCULATE ( [Nb Objets], DimStatut[Statut] = "WARNING" )
Nb FAIL              = CALCULATE ( [Nb Objets], DimStatut[EstEchec] = TRUE () )
Nb NOT_TESTED        = CALCULATE ( [Nb Objets], DimStatut[Statut] = "NOT_TESTED" )
Nb Testés            = CALCULATE ( [Nb Objets], DimStatut[EstTeste] = TRUE () )
% FAIL (sur testés)  = DIVIDE ( [Nb FAIL], [Nb Testés] )
% NOT_TESTED         = DIVIDE ( [Nb NOT_TESTED], [Nb Objets] )

-- Trains
Trains avec un FAIL        = CALCULATE ( COUNTROWS ( DimTrain ), DimTrain[NbFail] > 0 )
Trains capteurs ext. valides = CALCULATE ( COUNTROWS ( DimTrain ), DimTrain[ExtValides] = "Oui" )
% Trains capteurs ext. valides = DIVIDE ( [Trains capteurs ext. valides], [Nb Trains] )

-- Score
Score moyen        = AVERAGE ( DimTrain[Score] )
Couverture moyenne = AVERAGE ( DimTrain[Couverture] )
Trains Bonne       = CALCULATE ( COUNTROWS ( DimTrain ), DimTrain[Verdict] = "Bonne" )
Trains À surveiller = CALCULATE ( COUNTROWS ( DimTrain ), DimTrain[Verdict] = "À surveiller" )
Trains Mauvaise    = CALCULATE ( COUNTROWS ( DimTrain ), DimTrain[Verdict] = "Mauvaise" )
Trains Non évaluable = CALCULATE ( COUNTROWS ( DimTrain ), DimTrain[Verdict] = "Non évaluable" )
Trains à imputer   = CALCULATE ( COUNTROWS ( DimTrain ), DimTrain[Imputation] = "Imputer" )
Trains à exclure   = CALCULATE ( COUNTROWS ( DimTrain ), DimTrain[Imputation] = "Exclure" )

-- Complétude
Part arrêts sans donnée = DIVIDE ( [Nb Arrêts sans donnée], [Nb Arrêts] )
Taux exploitable moyen (DQ-12) = AVERAGE ( DimTrain[Dq12TauxPct] )

-- Maille choisie par un segmenteur (une seule valeur, Train par défaut)
Maille choisie = IF ( HASONEVALUE ( DimGrain[Grain] ), VALUES ( DimGrain[Grain] ), "Train" )

-- Suivi
Dernière exécution = MAX ( FaitExecution[ExecutionDateTime] )
Durée règle (s)    = DIVIDE ( SUM ( FaitExecution[DureeMs] ), 1000 )
Règles en erreur   = CALCULATE ( COUNTROWS ( FaitExecution ), FaitExecution[StatutRegle] = "Erreur" )
```

Pour la couleur des barres, utiliser `DimStatut[CouleurHex]` (mise en forme conditionnelle
« valeur du champ ») ; trier `DimStatut[Statut]` par `Ordre`.

La page de synthèse peut utiliser `Nb Objets` sur `FaitResultat` (1,27 million de lignes
par exécution complète, voir 01) : l'import reste rapide. Si l'historique grandit au point
de justifier l'option B, la même mesure s'appuie sur `AggStatutRegle` déclarée comme
agrégat.

## 4. Hiérarchies et drill-down

| Hiérarchie | Niveaux |
|---|---|
| Date | Année → Mois → Jour (`DimDate`) |
| Réseau | Ligne → Train (`DimTrain`) |
| Géographie | Canton → Commune → Gare (`DimGare`) |
| Règle | Règle → Maille → Statut |

**Drill-through** (clic droit) :

1. depuis n'importe quel visuel portant `CountingId` ou `TrainNumber` vers « Détail du train » ;
2. de la page « Vue d'ensemble » (barre d'une règle) vers la page « Trains » filtrée sur les
   trains en échec de cette règle (colonne `DQnn` de `DimTrain`) ;
3. d'un arrêt vers le détail des véhicules (`FaitResultat`, maille Véhicule) ;
4. d'une gare vers la liste des trains concernés.

**Signets** : un par maille (Train, Arrêt, Véhicule) pour remplacer les boutons du
dashboard ; **info-bulles** de page pour la définition d'une règle (`DimRegle[Calcul]`).

## 5. Actualisation incrémentale (option A)

Paramètres `RangeStart` et `RangeEnd` (type Date/Heure), filtrage dans la requête de
`DimTrain`, `FaitResultat` et `FaitArret` :

```m
let
    Source = Sql.Database("serveur", "CFL_GOV"),
    Vue    = Source{[Schema = "comptage_API", Item = "vw_DQ_FaitResultat"]}[Data],
    Filtre = Table.SelectRows(Vue, each [DateCirculation] >= DateTime.Date(RangeStart)
                                    and [DateCirculation] <  DateTime.Date(RangeEnd))
in
    Filtre
```

| Réglage | Valeur proposée (à confirmer) |
|---|---|
| Stocker les données | 24 mois (selon la rétention décidée en 07) |
| Actualiser les données | 5 derniers jours (le pipeline recalcule J-3 à J-1, marge de sécurité) |
| Détecter les modifications | Sur `DimTrain[MajUtc]` |
| Dimensions (`DimRegle`, `DimStatut`, `DimGrain`, `DimGare`, `DimDate`) | Actualisation complète |
| Planification | Après le pipeline SQL (par exemple heure fixe, ou déclenchement par l'API après la tâche SSIS) ; passerelle de données requise si SQL Server est sur site |

Le filtre doit se replier (*query folding*) : ne pas ajouter d'étape non repliable avant le
filtre de date.

## 6. Autres usages des vues

- `audit.vw_DQ_RuleReport` et `vw_DQ_HighLevelReport` : rapports de la V1, pour les
  analystes qui veulent le journal brut sans passer par Power BI.
- `audit.vw_ReglesDQ_DataGalaxy` : alimentation du catalogue DataGalaxy (hors flux V1).
- Lorsqu'on choisira une variante de DQ-06, DQ-08 ou DQ-13, le modèle Power BI ne change
  pas : seuls les chiffres changent (voir 03).
