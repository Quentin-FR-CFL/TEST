# Documentation métier des règles de qualité des données

Ce document explique, pour un lecteur non développeur, comment les données de comptage
passagers sont contrôlées : les 14 règles de qualité (DQ-01 à DQ-14), le score de
confiance, la recommandation d'imputation et la lecture du dashboard.

| Document lié | Contenu |
|---|---|
| [referentiel/regles_dq_metier.md](referentiel/regles_dq_metier.md) | **Référentiel des 14 règles** (transcription des captures [regles_dq_metier.jpg](referentiel/regles_dq_metier.jpg) et [regles_dq13_dq14.png](referentiel/regles_dq13_dq14.png)) |
| [00_vue_ensemble.md](00_vue_ensemble.md) | Vue d'ensemble du projet |
| [01_documentation_technique.md](01_documentation_technique.md) | Scripts, paramètres, fichiers produits |
| [03_dataset_et_maille.md](03_dataset_et_maille.md) | Extraction brute, colonnes, éclatement en mailles |

**Convention** : ce qui n'a pas pu être vérifié dans le référentiel, le code, les données
ou les sorties est marqué **à confirmer**. Les exemples chiffrés viennent de trains réels
du jeu, sauf ceux marqués « exemple illustratif ».

**Sources utilisées** : le référentiel [referentiel/regles_dq_metier.md](referentiel/regles_dq_metier.md),
`output/dashboard/dq_rules.csv`, `src/dq_engine.py`, `src/score_engine.py`,
`config/score_config.json`, `dashboard/index.html` et les sorties `output/train_dq.csv`,
`output/station_dq.csv`, `output/evn_dq.csv`, `output/train_score.csv`,
`output/station_score.csv`. Tous les chiffres ont été recalculés le 2026-11-05 à partir
de ces sorties.

Dernière mise à jour : 2026-11-05.

---

## Sommaire

1. [Le référentiel](#1-le-référentiel)
2. [Contexte métier](#2-contexte-métier)
3. [Synthèse des 14 règles](#3-synthèse-des-14-règles)
4. [Fiches des règles](#4-fiches-des-règles) : [DQ-01](#dq-01--cohérence-flux--occupation) ·
   [DQ-02](#dq-02--complétude-evn) · [DQ-03](#dq-03--remise-à-zéro-au-terminus) ·
   [DQ-04](#dq-04--charge-critique) · [DQ-05](#dq-05--état-du-matériel) ·
   [DQ-06](#dq-06--disponibilité-des-capteurs) · [DQ-07](#dq-07--complétude-des-arrêts) ·
   [DQ-08](#dq-08--équilibre-des-flux) · [DQ-09](#dq-09--remise-à-zéro-à-lorigine) ·
   [DQ-10](#dq-10--occupation-reconstruite-non-négative) ·
   [DQ-11](#dq-11--cohérence-entre-les-mailles) · [DQ-12](#dq-12--valeurs-exploitables) · [DQ-13](#dq-13--capteur-figé) ·
   [DQ-14](#dq-14--flux-aux-extrémités)
5. [Score de confiance](#5-score-de-confiance)
6. [Imputation](#6-imputation)
7. [Guide de lecture du dashboard](#7-guide-de-lecture-du-dashboard)
8. [Questions ouvertes à trancher par le métier](#8-questions-ouvertes-à-trancher-par-le-métier)
9. [Écarts entre le référentiel et l'application](#9-écarts-entre-le-référentiel-et-lapplication)

---

## 1. Le référentiel

Le référentiel des 14 règles est l'onglet « Règles DQ - Métier » du classeur de
l'utilisateur, dont les captures d'écran sont dans le dépôt :
[referentiel/regles_dq_metier.jpg](referentiel/regles_dq_metier.jpg) (DQ-01 à DQ-12) et
[referentiel/regles_dq13_dq14.png](referentiel/regles_dq13_dq14.png) (DQ-13 et DQ-14, ajoutées le 2026-11-06). Sa transcription mot pour
mot est [referentiel/regles_dq_metier.md](referentiel/regles_dq_metier.md). Pour chaque règle,
il donne : le numéro, le nom, la granularité, une description, l'évolution de la règle, la
formule complète et les conditions PASS / WARNING / FAIL / NOT_TESTED.

Le fichier `OLD/Analyse des KPI's de Qualité de données.xlsx` est une ancienne version, sans
cet onglet, conservée dans `OLD/` pour l'historique seulement.

Le référentiel ne dit pas comment lire certains champs de l'extraction (qui se présente en
JSON : `StopsJson`, `vehicles`). Ces points ont été tranchés avec l'utilisateur ; ils sont
listés à la fin de la transcription et repérés « **Choix validé** » dans les fiches. Les
points que le code a dû interpréter sans validation sont repérés « **Hypothèse à valider** ».

Le score de confiance et la recommandation d'imputation ne figurent pas dans le référentiel :
leurs paramètres sont **provisoires** (sections 5 et 6).

---

## 2. Contexte métier

### 2.1 Ce que mesure le comptage passagers

Les trains sont équipés de capteurs de comptage automatique. À chaque arrêt, le système
produit :

| Notion | Définition | Champ utilisé |
|---|---|---|
| Montées | Voyageurs entrés dans le train à l'arrêt | `boarding.allClasses` (arrêt) ; 1re + 2e classe (véhicule) |
| Descentes | Voyageurs sortis du train à l'arrêt | `alighting.allClasses` (arrêt) ; 1re + 2e classe (véhicule) |
| Occupation | Voyageurs à bord après l'arrêt | `occupancy.allClasses` (arrêt et véhicule), `TotalOccupancy` (train) |
| Capacité | Nombre de places du train ou du véhicule | `capacity.allClasses` (arrêt), `sensorCapacity.allClasses` (véhicule), `TotalCapacity` (train) |
| Fiabilité des capteurs | Pourcentage de fonctionnement des capteurs d'un véhicule | `reliability.exteriorPercent` et `interiorPercent` (véhicule) |
| Matériel dégradé | Indicateur de matériel ou de composition dégradé | `IsDegraded` (train), `isDegraded` (arrêt) |
| Type d'arrêt | Origine, arrêt intermédiaire, terminus | `stopType` = `Start`, `Stop`, `End` |
| EVN | European Vehicle Number : numéro européen unique d'un véhicule (voiture, motrice) | `europeanVehicleNumber` ; liste attendue `EuropeanVehicleNumbersJson` |

Relation de base entre ces grandeurs : l'occupation après un arrêt doit être égale à
l'occupation après l'arrêt précédent, plus les montées, moins les descentes. Plusieurs
règles (DQ-01, DQ-03, DQ-08, DQ-09, DQ-10) vérifient cette relation sous différents angles.

Points **à confirmer** sur le sens des champs :

- si `occupancy.allClasses` inclut les vélos, alors que les flux de montées / descentes ne
  les compteraient pas ;
- ce que représentent exactement les capteurs « extérieur » et « intérieur » d'un véhicule
  (le choix validé considère qu'un véhicule a ces deux capteurs) ;
- le sens précis de `isDegraded` (matériel en panne, comptage dégradé, composition, autre) ;
- si l'occupation au terminus est mesurée avant ou après la descente des voyageurs.

### 2.2 Le jeu de données contrôlé

| Élément | Valeur recalculée |
|---|---|
| Trains (circulations) | 5 000 |
| Dates de circulation | 22 dates du 2026-08-04 au 2026-08-26, sans le 24 ; le 23, le 25 et le 26 ne comptent que 42, 3 et 2 trains (période annoncée : « du 4 au 25 août », **à confirmer**) |
| Arrêts (maille Station) | 44 949, dont 40 077 avec une occupation mesurée et 4 872 sans aucune donnée |
| Véhicules à un arrêt (maille EVN) | 167 553 lignes, 162 véhicules distincts |
| Lignes | L70 (1 466 trains), L60 (1 326), L10 (1 170), T10/60 (486), L30 (268), L50 (202), non renseignée (82) |
| Types de train | RB (3 603), RE (1 214), HPV140 (92), non renseigné (82), IC (9) |
| Séries | 2400 (1 978), 2450 (1 211), TER2N (975), LOCOMOTIVE (366), DOSTO (364), non renseignée (106) |

Les 82 trains sans ligne n'ont ni origine (`Start`) ni terminus (`End`) dans leurs arrêts,
et 80 d'entre eux ont déjà des voyageurs à bord au premier arrêt listé : il s'agit
probablement de trajets partiels (par exemple la partie d'un train transfrontalier),
**à confirmer**.

### 2.3 Objectifs du contrôle qualité

1. **Détecter les anomalies de comptage** : capteur en panne, flux incohérents, véhicule
   ou arrêt non transmis, capacité absente.
2. **Distinguer « conforme » de « non vérifiable »** : une donnée absente ne doit pas passer
   pour une donnée correcte. Le référentiel ajoute pour cela le statut NOT_TESTED à la
   plupart des règles (colonne « Évolution de la règle »).
3. **Donner une note de confiance par train** pour décider quels trains utiliser tels quels,
   lesquels compléter (imputer) et lesquels écarter.

### 2.4 Les trois mailles

Une ligne de l'extraction correspond à un train. Le code l'éclate en trois niveaux :

| Maille | Objet | Nombre | Exemple |
|---|---|---|---|
| **Train** | Une circulation (un numéro de train un jour donné) | 5 000 | Train 6107 du 2026-08-04, ligne L60 |
| **Station** | Un arrêt d'un train (un élément de `StopsJson`) | 44 949 | Ce train à Dudelange-Ville (3e arrêt) |
| **EVN** | Un véhicule de la composition à un arrêt | 167 553 | Le véhicule 948200220911 à Pétange |

Règles calculées à chaque maille, comparées à la granularité du référentiel :

| Règle | Granularité du référentiel | Train | Station | EVN |
|---|---|:-:|:-:|:-:|
| DQ-01 Cohérence flux / occupation | Train / Station | ✓ (pire statut des arrêts) | ✓ | |
| DQ-02 Complétude EVN | Train / Station | ✓ | ✓ | |
| DQ-03 Remise à zéro au terminus | Train | ✓ | | |
| DQ-04 Charge critique | Train (synthèse) + Train / Station / EVN (détail) | ✓ | ✓ | ✓ |
| DQ-05 État du matériel | Train / Station / EVN | ✓ | ✓ | ✓ (hérité de l'arrêt) |
| DQ-06 Disponibilité des capteurs | Train / Station / EVN | ✓ | ✓ | ✓ |
| DQ-07 Complétude des arrêts | Train | ✓ | | |
| DQ-08 Équilibre des flux | Train | ✓ | | |
| DQ-09 Remise à zéro à l'origine | Train | ✓ | | |
| DQ-10 Occupation reconstruite non négative | Train / Station | ✓ | ✓ | |
| DQ-11 Cohérence entre les mailles | Train / Station / EVN | ✓ (pire statut des arrêts) | ✓ | pas de statut propre |
| DQ-12 Valeurs exploitables | Tous grains | ✓ | ✓ | ✓ |
| DQ-13 Capteur figé | EVN / Séquence | ✓ (pire statut des EVN) | | ✓ (statut de la séquence de l'EVN) |
| DQ-14 Flux aux extrémités | Train | ✓ | | |

Pour DQ-11, les véhicules servent seulement à calculer le statut de l'arrêt : aucun statut
DQ-11 n'est produit à la maille EVN.

### 2.5 Les statuts

| Statut | Signification | Effet dans le score |
|---|---|---|
| PASS | Contrôle exécuté, résultat conforme | 1 point |
| WARNING | Contrôle exécuté, écart tolérable (prévu seulement pour DQ-04, DQ-06, DQ-10, DQ-11, DQ-12, DQ-13, DQ-14) | 0,5 point |
| FAIL | Contrôle exécuté, résultat non conforme | 0 point |
| NOT_TESTED | Contrôle impossible : donnée d'entrée absente | Exclu du score, réduit la couverture |

Quand un statut Train résume plusieurs arrêts ou véhicules, on prend **le pire** :
FAIL l'emporte sur WARNING, qui l'emporte sur PASS ; NOT_TESTED seulement si rien n'a pu
être testé.

### 2.6 Comment lire une fiche

Chaque fiche suit le même plan : objectif métier, granularité, texte du référentiel
(description, évolution, formule, conditions des quatre statuts), application dans le code
(choix validés, hypothèses à valider et écarts, séparés), exemple chiffré, résultats
observés, interprétation, actions possibles. Dans les tableaux de résultats, la colonne
« FAIL parmi testés » rapporte les FAIL aux seuls cas testés (hors NOT_TESTED).

---

## 3. Synthèse des 14 règles

Résultats à la maille Train (5 000 trains).

| Règle | PASS | WARNING | FAIL | NOT_TESTED | Constat principal |
|---|--:|--:|--:|--:|---|
| DQ-01 Cohérence flux / occupation | 1 029 | 0 | 2 047 | 1 924 | Reconstruction cumulée depuis l'origine (2026-11-11) : 45 % des arrêts testés sont FAIL ; non testable dès qu'un flux manque avant l'arrêt |
| DQ-02 Complétude EVN | 4 517 | 0 | 483 | 0 | Surtout des trains à 6 véhicules attendus dont 3 seulement transmettent |
| DQ-03 Remise à zéro au terminus | 1 173 | 0 | 1 183 | 2 644 | Non testable sur plus de la moitié des trains : terminus sans donnée |
| DQ-04 Charge critique | 4 996 | 3 | 0 | 1 | **Aucune charge > 250 %** ; la capacité nulle avec occupation 0 est NOT_TESTED depuis le 2026-11-11 (3 513 passages de véhicule, C21) |
| DQ-05 État du matériel | 2 511 | 0 | 2 489 | 0 | **Environ la moitié des trains (49,8 %) sont déclarés dégradés** |
| DQ-06 Disponibilité des capteurs | 2 074 | 297 | 2 622 | 7 | Capteurs extérieurs à 0 % sur la série 2450 ; capteurs sans valeur comptés invalides |
| DQ-07 Complétude des arrêts | 2 594 | 0 | 2 406 | 0 | 48 % des trains ont au moins un arrêt manquant, surtout à l'origine et au terminus |
| DQ-08 Équilibre des flux | 390 | 0 | 1 368 | 3 242 | 78 % de FAIL parmi les trains testés ; non testable dès qu'un arrêt manque |
| DQ-09 Remise à zéro à l'origine | 1 934 | 0 | 324 | 2 742 | Non testable sur 55 % des trains (origine sans donnée ou capacité nulle) |
| DQ-10 Occupation reconstruite non négative | 948 | 242 | 679 | 3 131 | 36 % de FAIL parmi les trains testés |
| DQ-11 Cohérence entre les mailles | 4 825 | 0 | 0 | 175 | **Écart toujours égal à 0** : la règle ne détecte rien sur cette extraction |
| DQ-12 Valeurs exploitables | 4 248 | 0 | 752 | 0 | Aucune valeur illisible ; les arrêts sans donnée ne comptent plus au niveau Train (2026-11-11), les FAIL sont des valeurs ou flux manquants dans les arrêts renseignés |
| DQ-13 Capteur figé | 473 | 507 | 1 516 | 2 504 | Une occupation répétée est le plus souvent un zéro (82 % des FAIL, constat C28) ; non testable dès qu'un arrêt de la séquence manque |
| DQ-14 Flux aux extrémités | 1 907 | 2 | 4 | 3 087 | Presque aucune anomalie, mais 62 % de NOT_TESTED (extrémité ou flux d'extrémité absent) ; point Dosto à investiguer (constat C27) |

4 968 trains sur 5 000 (99,4 %) ont au moins une règle en FAIL ; 32 n'en ont aucune.

---

## 4. Fiches des règles

Le texte du référentiel cité dans chaque fiche vient de
[referentiel/regles_dq_metier.md](referentiel/regles_dq_metier.md).

### DQ-01 – Cohérence flux / occupation

**Objectif métier.** Vérifier qu'à chaque arrêt, l'occupation mesurée correspond au cumul
des montées et descentes depuis l'origine du train. Un écart signale un
capteur qui compte mal les entrées / sorties, ou une occupation mal mesurée.

**Granularité.** Train / Station : le statut est calculé à chaque arrêt ; Train = pire
statut de ses arrêts.

**Texte du référentiel.**

| | |
|---|---|
| Description | Vérifie que l'occupation mesurée est cohérente avec l'occupation reconstruite à partir des montées et descentes. |
| Évolution | Seuil rendu plus robuste avec un minimum de 5 voyageurs et 2 % de l'occupation théorique. |
| Formule | Écart = \|Occupation mesurée − Occupation reconstruite\| ; seuil = MAX(5 voyageurs ; 2 % × Occupation reconstruite). |
| PASS | Écart ≤ seuil |
| WARNING | Non prévu |
| FAIL | Écart > seuil |
| NOT_TESTED | Occupation ou flux absent, ou ordre des arrêts inexploitable |

**Application dans le code.**

| | |
|---|---|
| **Choix validé (2026-11-11)** | Occupation reconstruite (n) = Σ (montées − descentes) des arrêts 1..n : reconstruction **cumulée depuis l'origine** (1er arrêt listé). Remplace la reconstruction locale du 2026-11-05 (occupation mesurée (n−1) + montées (n) − descentes (n)). Conséquence : une erreur de flux se propage à tous les arrêts suivants (dérive cumulée) |
| Conforme | Formule, plancher de 5 voyageurs, seuil de 2 %, pas de WARNING |
| NOT_TESTED appliqué | Arrêt sans occupation mesurée, ou montées / descentes absentes à l'un des arrêts 1..n. Le premier arrêt est désormais testé |
| Point ouvert | Le cas « ordre des arrêts inexploitable » n'est pas contrôlé : le code suit l'ordre de `StopsJson` sans le vérifier |

**Exemple chiffré** (train 6118 du 2026-08-10, Bettembourg-V → Volmerange-les-M, cas FAIL de
l'atelier). Arrêts 1 à 4 (montées / descentes) : 50 / 0, 0 / 5, 1 / 22, 0 / 9. À
Dudelange-Centre (4e arrêt), occupation mesurée 43. Reconstruite =
(50 − 0) + (0 − 5) + (1 − 22) + (0 − 9) = 15. Écart = |43 − 15| = 28. Seuil =
MAX(5 ; 2 % × 15 = 0,3) = 5. 28 > 5 → **FAIL**. Dès le 1er arrêt l'écart est de 7
(57 mesurés pour 50 montées) et il ne se résorbe pas : c'est la dérive cumulée.

**Résultats observés** (relancés le 2026-11-11 avec la reconstruction cumulée).

| Maille | PASS | WARNING | FAIL | NOT_TESTED | FAIL parmi testés |
|---|--:|--:|--:|--:|--:|
| Train | 1 029 (20,6 %) | 0 | 2 047 (40,9 %) | 1 924 (38,5 %) | 66,5 % |
| Station | 15 073 (33,5 %) | 0 | 12 251 (27,3 %) | 17 625 (39,2 %) | 44,8 % |

- Sur les 27 324 arrêts testés, l'écart médian est de 4 voyageurs, 90 % des écarts sont
  ≤ 32 voyageurs, 4 868 arrêts ont un écart nul ; l'écart maximal est de 580. Parmi les
  FAIL, l'écart médian est de 14 voyageurs.
- NOT_TESTED à la maille Station : 4 872 arrêts sans donnée et 12 753 arrêts mesurés dont
  les montées / descentes manquent à l'un des arrêts 1..n.
- Aucun arrêt n'est sauvé par la partie « 2 % » du seuil : le plus grand écart PASS est 5.
- **Avant la modification** (reconstruction locale) : Train 2 575 PASS, 2 099 FAIL, 326
  NOT_TESTED ; Station 3 644 FAIL (8,1 %). La version cumulée est donc nettement plus
  sévère (variante ré-ancrée sur l'occupation mesurée : non validée, voir les points ouverts).

**Interprétation.** Un seul arrêt en FAIL suffit à mettre le train en FAIL, et l'erreur d'un
arrêt se reporte sur tous les suivants : 45 % des arrêts testés sont FAIL. Cette sévérité
est la conséquence du choix cumulé ; elle est à valider par l'utilisateur. Le plancher
de 5 voyageurs évite de déclencher sur des trains presque vides.

**Actions possibles.** Examiner les arrêts à fort écart (`station_dq.csv`, colonne
`dq01_ecart`, en valeur absolue) ; vérifier si les vélos sont inclus dans l'occupation
mais pas dans les flux, ce qui créerait un écart sans défaut de capteur.

---

### DQ-02 – Complétude EVN

**Objectif métier.** Vérifier qu'à chaque arrêt, tous les véhicules de la composition
transmettent leurs comptages. Un véhicule muet signifie des voyageurs non comptés.

**Granularité.** Train / Station.

**Texte du référentiel.**

| | |
|---|---|
| Description | Vérifie que tous les EVN attendus sont présents à chaque arrêt. |
| Évolution | Ajout de statuts explicites ; plafond métier maintenu à 9 EVN. |
| Formule | Comparer le nombre d'EVN observés au maximum d'EVN attendu sur la circulation, avec un maximum autorisé de 9. |
| PASS | EVN observés = maximum attendu connu et maximum attendu ≤ 9 |
| WARNING | Non prévu |
| FAIL | Maximum attendu inconnu, > 9, ou EVN observés ≠ maximum attendu |
| NOT_TESTED | Non prévu : un maximum inconnu reste FAIL |

**Application dans le code.**

| | |
|---|---|
| **Choix validé** | Maximum attendu = nombre de véhicules distincts de `EuropeanVehicleNumbersJson` ; un arrêt sans aucune donnée est NOT_TESTED (c'est DQ-07 qui signale l'arrêt manquant) |
| Conforme | Comparaison de nombres ; plafond de 9 ; maximum inconnu (liste vide) → FAIL. Train : FAIL si maximum inconnu ou > 9, sinon pire statut des arrêts |
| Écart par rapport au texte | NOT_TESTED pour un arrêt sans donnée, alors que le référentiel ne prévoit pas NOT_TESTED (couvert par le choix validé) |
| Limite constatée | La règle compare des **nombres**, pas des identités de véhicules : sur 44 trains dont des véhicules observés ne sont pas dans la liste attendue, 29 obtiennent PASS, dont 28 où les véhicules observés n'ont aucun point commun avec la liste |

**Exemple chiffré** (train 86552 du 2026-08-04, ligne L70, série TER2N, CountingId 26219).
La liste attendue compte 6 véhicules ; à Luxembourg, Hollerich, Dippach-Reckange,
Bascharage-Sanem…, 3 véhicules seulement transmettent. 3 ≠ 6 → **FAIL** à chaque arrêt,
donc FAIL pour le train.

**Résultats observés.**

| Maille | PASS | WARNING | FAIL | NOT_TESTED | FAIL parmi testés |
|---|--:|--:|--:|--:|--:|
| Train | 4 517 (90,3 %) | 0 | 483 (9,7 %) | 0 | 9,7 % |
| Station | 36 905 (82,1 %) | 0 | 3 172 (7,1 %) | 4 872 (10,8 %) | 7,9 % |

- Trains en FAIL : 106 ont une liste attendue vide (ce sont exactement les 106 trains
  `HasComposition = 0`) ; 377 ont un nombre de véhicules différent à au moins un arrêt.
- Arrêts en FAIL : 2 658 avec moins de véhicules qu'attendu, 492 avec une liste attendue
  vide, 22 avec plus de véhicules qu'attendu. Cas les plus fréquents : 6 attendus pour
  3 observés (1 763 arrêts), 5 attendus pour 1 observé (755 arrêts).

**Interprétation.** Le cas « 6 attendus, 3 observés » ressemble à une unité multiple (deux
rames de 3 véhicules) dont une seule rame transmet : la moitié des voyageurs ne serait pas
comptée (**à confirmer** avec l'exploitant). Les 106 trains sans composition sont en FAIL,
conformément au référentiel.

**Actions possibles.** Décider s'il faut aussi comparer l'identité des véhicules ; remonter
aux équipes matériel les compositions où une rame entière est muette.

---

### DQ-03 – Remise à zéro au terminus

**Objectif métier.** Au terminus, tous les voyageurs descendent : les descentes doivent
égaler l'occupation. Un résidu signale un capteur qui sous-compte les descentes ou une
occupation qui ne se remet pas à zéro.

**Granularité.** Train.

**Texte du référentiel.**

| | |
|---|---|
| Description | Vérifie que l'occupation résiduelle au terminus reste négligeable. |
| Évolution | Ajout de NOT_TESTED pour distinguer une donnée manquante d'un écart mesuré ; seuil de 2 % conservé. |
| Formule | Taux résiduel = \|Occupation au terminus − Descentes au terminus\| / Capacité au terminus. |
| PASS | Terminus identifié, données disponibles et taux résiduel ≤ 2 % |
| WARNING | Non prévu |
| FAIL | Terminus identifié et taux résiduel > 2 % |
| NOT_TESTED | Terminus non identifiable ou données nécessaires absentes |

**Application dans le code.**

| | |
|---|---|
| **Choix validé** | Terminus = arrêt `stopType = End` ; pas de terminus ou terminus sans donnée → NOT_TESTED |
| Conforme | Formule, seuil de 2 %, pas de WARNING, NOT_TESTED si occupation, descentes ou capacité du terminus manquent |
| **Confirmé (2026-11-11)** | L'occupation du terminus est mesurée **avant** les descentes (c'est pourquoi la formule retire les descentes). Constaté dans la donnée : pour 792 trains testables sur 2 356 (33,6 %), l'occupation au terminus est inférieure aux descentes (constat C30). La lecture « après les descentes » aurait changé le verdict de 546 trains (385 FAIL → PASS, 161 PASS → FAIL) ; elle est écartée |
| Précisions | Une capacité nulle au terminus donne NOT_TESTED (taux non calculable ; aucun cas dans ce jeu). Le code prend le dernier arrêt `End` sans vérifier qu'il est le dernier arrêt du trajet (5 trains ont un dernier arrêt de type `Stop`) |

**Exemple chiffré** (train 503623 du 2026-08-11, ligne L10, CountingId 26283).
Au terminus Ettelbruck : occupation 94, descentes 0, capacité 610.
Taux = |94 − 0| / 610 = 15,41 % > 2 % → **FAIL**. Le train arrive au terminus avec 94
voyageurs à bord et personne ne descend : les descentes ne sont pas comptées.

**Résultats observés.**

| Maille | PASS | WARNING | FAIL | NOT_TESTED | FAIL parmi testés |
|---|--:|--:|--:|--:|--:|
| Train | 1 173 (23,5 %) | 0 | 1 183 (23,7 %) | 2 644 (52,9 %) | 50,2 % |

- NOT_TESTED : 1 856 terminus sans aucune donnée, 706 terminus mesurés mais sans
  montées / descentes, 82 trains sans terminus.
- Sur les 2 356 trains testés, le taux résiduel médian est de 2,04 % (juste au-dessus du
  seuil) ; 314 trains ont un taux nul ; le maximum est de 123,19 %.
- FAIL : 1 110 trains sur 1 183 arrivent avec une occupation positive au terminus ; 409 ont
  zéro descente au terminus ; 503 des 1 183 FAIL ont un taux compris entre 2 et 5 %.

**Interprétation.** La règle est rarement testable : le terminus est l'arrêt qui manque le
plus souvent (voir DQ-07 et la section 6). Quand elle est testable, la moitié des trains
échouent, souvent parce que les descentes au terminus ne sont pas comptées. Le taux médian
étant juste au-dessus de 2 %, le seuil a un effet fort sur le résultat.

**Actions possibles.** Signaler les terminus mesurés sans flux ; examiner les trains dont
l'occupation au terminus est inférieure aux descentes (C30), qui indiquent soit un capteur
d'occupation qui décompte déjà les descentes, soit des descentes surestimées.

---

### DQ-04 – Charge critique

**Objectif métier.** Détecter une occupation physiquement aberrante par rapport à la
capacité (plus de deux fois et demie la capacité), ou une capacité absente ou nulle, qui rend
tout taux de charge impossible à calculer.

**Granularité.** Train (synthèse) + Train / Station / EVN (détail).

**Texte du référentiel.**

| | |
|---|---|
| Description | Détecte une occupation physiquement aberrante par rapport à la capacité du matériel. Conserve le détail Train / Station / EVN et signale, à la maille Train, la présence d'au moins une anomalie. |
| Évolution | Ajout d'une synthèse Train dès qu'au moins un détail est WARNING ou FAIL ; détail Train / Station / EVN conservé. WARNING au-delà de 200 % et jusqu'à 250 % ; FAIL au-delà de 250 %. Capacité nulle ou inconnue toujours traitée comme anomalie. |
| Formule | Taux de charge = Occupation / Capacité. Synthèse Train : au moins une anomalie si au moins un détail Train / Station / EVN est WARNING ou FAIL ; retenir FAIL si au moins un FAIL, sinon WARNING si au moins un WARNING. Conserver le traitement des occupations absentes. |
| PASS | Capacité renseignée et > 0, et taux de charge ≤ 200 % |
| WARNING | Capacité renseignée et > 0, et 200 % < taux de charge ≤ 250 %. Synthèse Train : au moins un WARNING et aucun FAIL |
| FAIL | Taux de charge > 250 %, ou capacité nulle/inconnue. Synthèse Train : au moins un FAIL |
| NOT_TESTED | Occupation absente ; à confirmer selon le traitement métier |

**Application dans le code.**

| | |
|---|---|
| **Choix validé** | Capacité EVN = `sensorCapacity` ; Station = `capacity` de l'arrêt ; Train = `TotalCapacity` |
| **Choix validé (2026-11-11)** | Capacité nulle ou inconnue **avec une occupation de 0** → NOT_TESTED (véhicule vide, rien à juger) ; avec une occupation > 0 → FAIL (taux incalculable alors qu'il y a des voyageurs). Remplace l'ancien FAIL systématique (constat C21) |
| Conforme | Seuils 200 % / 250 %, capacité nulle avec voyageurs → FAIL, synthèse Train (pire statut de tous les détails) |
| Point ouvert (le référentiel le laisse ouvert) | Occupation absente → NOT_TESTED, appliqué en attendant la décision métier. Le code teste l'occupation avant la capacité : un détail sans occupation et à capacité nulle est NOT_TESTED, pas FAIL (1 cas : le détail Train du CountingId 30086, `TotalCapacity = 0` et `TotalOccupancy` absente) |

**Exemple chiffré** (train 3795 du 2026-08-16, ligne L10, CountingId 29801).
À Ettelbruck, le véhicule DOSTO 508286700184 a une occupation de 158 pour une capacité
capteur de 69. Taux = 158 / 69 = 228,99 % → **WARNING** (entre 200 et 250 %).
Exemple de NOT_TESTED : un véhicule avec `sensorCapacity = 0` et une occupation de 0 est
NOT_TESTED (avant le 2026-11-11 : FAIL). Un véhicule à capacité 0 avec des voyageurs serait
FAIL, car le taux ne peut pas être calculé ; aucun cas n'existe dans l'extraction.

**Résultats observés.**

| Maille | PASS | WARNING | FAIL | NOT_TESTED | FAIL parmi testés |
|---|--:|--:|--:|--:|--:|
| Train (synthèse) | 4 996 (99,9 %) | 3 (0,1 %) | 0 | 1 (< 0,1 %) | 0 % |
| Station | 39 319 (87,5 %) | 0 | 0 | 5 630 (12,5 %) | 0 % |
| EVN | 164 021 (97,9 %) | 19 (< 0,1 %) | 0 | 3 513 (2,1 %) | 0 % |

- **Constat notable : avant la modification du 2026-11-11, tous les FAIL (829 trains, 758
  arrêts, 3 513 passages de véhicule) venaient d'une capacité égale à 0 avec une occupation
  de 0, aucun d'une charge supérieure à 250 %.** Ces cas sont maintenant NOT_TESTED, et DQ-04
  ne produit plus aucun FAIL sur cette extraction.
- Taux de charge maximal observé : 236,23 % pour un véhicule, 153,62 % pour un arrêt,
  122,71 % pour un train. 206 passages de véhicule dépassent 100 %, 19 dépassent 200 %
  (tous des véhicules DOSTO, tous en WARNING).
- Détail Train (`TotalCapacity`) : 4 999 PASS et 1 NOT_TESTED. Les 829 trains qui étaient en
  FAIL avant le 2026-11-11 l'étaient à cause d'arrêts et de véhicules (754 trains) ou de
  véhicules seuls (75 trains) ; ils ne sont plus FAIL (les WARNING passent de 2 à 3 trains, les PASS de 4 169 à 4 996).
- 82 véhicules distincts sur 162 ont au moins un passage à capacité nulle ; par série :
  2450 (1 962 passages), 2400 (1 278), DOSTO (243), série non renseignée (24), TER2N (6).

**Interprétation.** Sur ce jeu, DQ-04 détecte en pratique un **problème de données de
capacité** (capacité à 0), pas une surcharge : la règle traite les deux de la même façon,
comme le demande le référentiel.

**Actions possibles.** Corriger ou compléter les capacités à 0 des véhicules concernés
(liste dans `evn_dq.csv`) ; trancher le traitement des occupations absentes.

---

### DQ-05 – État du matériel

**Objectif métier.** Signaler les comptages produits par un matériel ou une composition
déclaré dégradé, dont les mesures sont moins fiables.

**Granularité.** Train / Station / EVN.

**Texte du référentiel.**

| | |
|---|---|
| Description | Identifie un matériel ou une composition signalé comme dégradé. |
| Évolution | Ajout de NOT_TESTED lorsque l'état n'est pas fourni. |
| Formule | Contrôle binaire : État matériel = 0 si conforme ; État matériel = 1 si dégradé. |
| PASS | État = 0 |
| WARNING | Non prévu |
| FAIL | État = 1 |
| NOT_TESTED | État absent |

**Application dans le code.**

| | |
|---|---|
| **Choix validé** | Train = `IsDegraded` ; Station = `isDegraded` de l'arrêt ; EVN hérite de son arrêt (l'extraction ne fournit pas d'indicateur par véhicule) |
| Conforme | Statuts et NOT_TESTED (aucun indicateur absent dans ce jeu) |
| Précision | Les indicateurs Train et Station sont lus séparément : un train peut être dégradé alors que certains de ses arrêts ne le sont pas |

**Exemple chiffré** (exemple illustratif). Un train a `IsDegraded = 1` : DQ-05 Train = FAIL.
Sur ses 6 arrêts, 2 ont `isDegraded = vrai` : ces 2 arrêts et tous leurs véhicules sont en
FAIL, les 4 autres arrêts et leurs véhicules en PASS.

**Résultats observés.**

| Maille | PASS | WARNING | FAIL | NOT_TESTED | FAIL parmi testés |
|---|--:|--:|--:|--:|--:|
| Train | 2 511 (50,2 %) | 0 | 2 489 (49,8 %) | 0 | 49,8 % |
| Station | 33 872 (75,4 %) | 0 | 11 077 (24,6 %) | 0 | 24,6 % |
| EVN | 120 764 (72,1 %) | 0 | 46 789 (27,9 %) | 0 | 27,9 % |

- **Constat notable : environ la moitié des trains (2 489 sur 5 000) sont déclarés
  dégradés.** Parmi eux, 732 le sont à tous leurs arrêts et 1 757 à une partie seulement.
  Aucun train non dégradé n'a d'arrêt dégradé.
- Par série : LOCOMOTIVE 366 trains sur 366 en FAIL, série non renseignée 106 sur 106,
  2400 981 sur 1 978, 2450 577 sur 1 211, DOSTO 197 sur 364, TER2N 262 sur 975.
- Par type : RE 849 sur 1 214 (69,9 %), RB 1 493 sur 3 603 (41,4 %).

**Interprétation.** Un taux de 50 % est très élevé pour un indicateur de panne : soit
l'indicateur a un sens plus large que « matériel en panne » (le référentiel parle aussi de
« composition » dégradée), soit le parc est réellement très touché. Le fait que **toutes**
les circulations de la série LOCOMOTIVE soient dégradées suggère un effet systématique lié au
type de matériel (**à confirmer**). DQ-05 est la règle la plus présente chez les trains en
verdict Mauvaise (voir section 5).

**Actions possibles.** Faire confirmer par l'exploitant la définition de `isDegraded` ;
ajuster le poids de DQ-05 dans le score en conséquence.

---

### DQ-06 – Disponibilité des capteurs

**Objectif métier.** Vérifier que les capteurs de comptage de chaque véhicule fonctionnent.
Un capteur défaillant fausse les montées, descentes ou occupations de son véhicule.

**Granularité.** Train / Station / EVN.

**Texte du référentiel.**

| | |
|---|---|
| Description | Vérifie que les capteurs nécessaires au comptage sont disponibles. |
| Évolution | Ajout des statuts ; distinction proposée pour le cas d'un seul capteur invalide. Ajout au dashboard d'un filtre « Capteurs extérieurs valides » fondé sur les données DQ-06 : Non si au moins un capteur extérieur est invalide, Oui sinon. Statuts DQ-06 inchangés. |
| Formule | Nombre de capteurs invalides = total des capteurs attendus − capteurs valides. Filtre dashboard « Capteurs extérieurs valides » : si nombre de capteurs extérieurs invalides ≥ 1, alors Non ; sinon Oui. Ce filtre est distinct du statut DQ-06 et ne remplace pas NOT_TESTED en cas d'absence de données. |
| PASS | 0 capteur invalide et données de comptage disponibles |
| WARNING | Exactement 1 capteur invalide, avec données encore exploitables |
| FAIL | Plus de 1 capteur invalide |
| NOT_TESTED | Aucune donnée de capteur disponible |

**Application dans le code.**

| | |
|---|---|
| **Choix validé** | 1 véhicule = 2 capteurs (extérieur, intérieur) ; un capteur est valide si sa fiabilité vaut 100 % |
| Conforme | Compte de capteurs invalides (0 / 1 / plus de 1) ; NOT_TESTED si aucune donnée capteur ; filtre « Capteurs extérieurs valides » (Oui / Non, et « Sans donnée » quand il n'y a aucune donnée capteur) |
| Capteurs attendus | EVN : 2. Station : 2 × véhicules présents à l'arrêt. Train : 2 × véhicules du train (liste attendue et véhicules observés) ; un véhicule attendu jamais observé compte pour 2 capteurs invalides |
| **Hypothèses à valider** | Un capteur **sans valeur** compte comme invalide quand l'autre capteur du véhicule a une valeur (629 passages de véhicule en WARNING ou FAIL pour cette seule raison) ; au niveau Train, un capteur est valide seulement s'il est à 100 % **à chaque arrêt mesuré**, et un capteur sans valeur à un arrêt le rend invalide |
| Point ouvert | Les conditions « données de comptage disponibles » (PASS) et « données encore exploitables » (WARNING) ne sont pas testées par le code. Aucun véhicule en PASS n'a d'occupation absente dans ce jeu |

**Exemple chiffré** (exemple illustratif). Un train de 3 véhicules passe par 5 arrêts.
Le capteur extérieur du 2e véhicule affiche 75 % à un seul arrêt, tous les autres sont à
100 % partout. À cet arrêt : 1 capteur invalide sur 6 → Station WARNING, et le véhicule
est WARNING. Au niveau du train : ce capteur n'est pas à 100 % à chaque arrêt, il est donc
invalide → 1 capteur invalide → Train WARNING ; « Capteurs extérieurs valides » = Non ;
« Tous les capteurs au vert » = Non.

**Résultats observés.**

| Maille | PASS | WARNING | FAIL | NOT_TESTED | FAIL parmi testés |
|---|--:|--:|--:|--:|--:|
| Train | 2 074 (41,5 %) | 297 (5,9 %) | 2 622 (52,4 %) | 7 (0,1 %) | 52,5 % |
| Station | 25 347 (56,4 %) | 2 997 (6,7 %) | 10 984 (24,4 %) | 5 621 (12,5 %) | 27,9 % |
| EVN | 122 098 (72,9 %) | 39 290 (23,4 %) | 483 (0,3 %) | 5 682 (3,4 %) | 0,3 % |

| « Capteurs extérieurs valides » | Oui | Non | Sans donnée |
|---|--:|--:|--:|
| Train | 2 383 (47,7 %) | 2 610 (52,2 %) | 7 |
| Station | 28 106 | 11 222 | 5 621 |
| EVN | 128 123 | 33 748 | 5 682 |

- Capteur extérieur à **0 %** sur 30 656 passages de véhicule, dont 22 075 sur la série
  2450 et 8 358 sur la série 2400. Le capteur intérieur est à 100 % dans 155 363 passages.
- Les 5 682 passages EVN NOT_TESTED (aucune valeur pour les deux capteurs) sont presque tous
  des véhicules DOSTO (5 537).
- Trains en FAIL ou WARNING (2 919) : 2 063 ont au moins un capteur sous 100 % ;
  **661 sont en FAIL uniquement parce que des capteurs n'ont pas de valeur** (séries DOSTO,
  LOCOMOTIVE et TER2N) ; 195 parce qu'un véhicule attendu n'est jamais observé.
- Par série au niveau train : LOCOMOTIVE 365 FAIL sur 366, DOSTO 363 sur 364,
  2450 1 040 sur 1 211, 2400 537 sur 1 978, TER2N 303 sur 975.
- Combinaisons au niveau train : 284 trains ont tous leurs capteurs extérieurs valides mais
  sont en FAIL (problème de capteurs intérieurs) ; 272 sont en WARNING avec « Capteurs
  extérieurs valides » = Non (le seul capteur invalide est extérieur).

**Interprétation.** À la maille véhicule, la situation est bonne (0,3 % de FAIL) : le cas
typique est un seul capteur en défaut, souvent l'extérieur. Au niveau train, la règle est
très sévère : deux capteurs non parfaits sur tout le trajet, ou des capteurs sans valeur,
suffisent pour un FAIL ; et un train long (plus de véhicules, donc plus de capteurs) a plus
de chances d'échouer qu'un train court. Le capteur extérieur systématiquement à 0 % sur une
partie des 2450 pourrait signifier un capteur absent ou non raccordé plutôt qu'une panne
(**à confirmer**).

**Actions possibles.** Décider si un capteur sans valeur doit compter invalide, en
particulier au niveau train ; faire vérifier par les équipes matériel les véhicules 2450 /
2400 à capteur extérieur nul (liste dans `evn_dq.csv` et onglet Capteurs du dashboard).

---

### DQ-07 – Complétude des arrêts

**Objectif métier.** Vérifier que le train a transmis des comptages à tous les arrêts de
son parcours. Un arrêt manquant crée un trou dans la chaîne montées / descentes /
occupation et empêche plusieurs autres contrôles.

**Granularité.** Train.

**Texte du référentiel.**

| | |
|---|---|
| Description | Détecte les arrêts manquants dans la séquence d'un trajet. |
| Évolution | Ajout de NOT_TESTED lorsque le rang maximal attendu est absent. |
| Formule | Comparer le nombre d'arrêts observés au rang maximal attendu du trajet. |
| PASS | Rang maximal disponible et nombre d'arrêts observés = rang maximal |
| WARNING | Non prévu |
| FAIL | Rang maximal disponible et nombre d'arrêts observés ≠ rang maximal |
| NOT_TESTED | Rang maximal attendu absent |

**Application dans le code.**

| | |
|---|---|
| **Choix validé** | Rang maximal attendu = nombre d'arrêts de `StopsJson` ; arrêt observé = arrêt avec une occupation mesurée |
| Conforme | Statuts ; NOT_TESTED si aucun arrêt listé (aucun cas dans ce jeu) |
| Ajout | Position des manques publiée (`missing_pattern`) : début (origine), fin (terminus), trou (arrêt intermédiaire entre deux arrêts mesurés), ou une combinaison |
| Point ouvert | Un arrêt listé mais réellement non desservi compte comme manquant (voir `stationPassed` ci-dessous) |

**Exemple chiffré** (train 6107 du 2026-08-04, ligne L60, CountingId 26241).
6 arrêts listés ; l'origine Bettembourg et le terminus Volmerange-les-Mines n'ont aucune
donnée. 4 observés ≠ 6 attendus → **FAIL**, position des manques « début+fin ».

**Résultats observés.**

| Maille | PASS | WARNING | FAIL | NOT_TESTED | FAIL parmi testés |
|---|--:|--:|--:|--:|--:|
| Train | 2 594 (51,9 %) | 0 | 2 406 (48,1 %) | 0 | 48,1 % |

| Position des arrêts manquants | Trains |
|---|--:|
| Aucun manque | 2 594 |
| Début et fin | 1 570 |
| Début seulement | 305 |
| Fin seulement | 262 |
| Trou seulement | 236 |
| Début, fin et trou | 19 |
| Début et trou | 9 |
| Fin et trou | 5 |

- 4 872 arrêts sans donnée : 1 903 premiers arrêts, 1 856 derniers arrêts, 1 113 arrêts
  intermédiaires. Taux de manque : 38,7 % des origines, 37,7 % des terminus, 3,2 % des
  arrêts intermédiaires.
- 4 871 de ces 4 872 arrêts ont `stationPassed = faux` dans l'extraction.

**Interprétation.** Les manques sont concentrés aux extrémités du trajet (détail en
section 6). Le champ `stationPassed = faux` peut signifier que le train n'a pas desservi
l'arrêt (suppression partielle : ce ne serait pas un défaut de donnée) ou que le système de
comptage n'a pas enregistré le passage (vrai défaut de donnée) : **à confirmer**, car cela
change la nature de ces FAIL.

**Actions possibles.** Faire préciser le sens de `stationPassed` ; si des arrêts sont
réellement non desservis, décider s'il faut les retirer de l'attendu.

---

### DQ-08 – Équilibre des flux

**Objectif métier.** Sur un trajet complet, le total des montées doit être proche du total
des descentes (tout voyageur monté finit par descendre). Un déséquilibre signale un capteur
qui surcompte ou sous-compte un sens de passage.

**Granularité.** Train.

**Texte du référentiel.**

| | |
|---|---|
| Description | Vérifie l'équilibre entre montées et descentes sur le trajet complet et sur le tronçon intermédiaire. |
| Évolution | Conservation du seuil de 5 % ; ajout du détail global et intermédiaire pour expliquer l'alerte. |
| Formule | Écart global = \|Total montées − Total descentes\| / Total montées ; écart intermédiaire = \|Montées intermédiaires − Descentes intermédiaires\| / Montées intermédiaires. |
| PASS | Les deux écarts ne dépassent pas simultanément 5 % |
| WARNING | Non prévu |
| FAIL | Écart global > 5 % ET écart intermédiaire > 5 % |
| NOT_TESTED | Flux nécessaires absents ou dénominateur non calculable |

**Application dans le code.**

| | |
|---|---|
| Conforme | Formules, seuil de 5 %, règle du ET ; détail publié dans `train_dq.csv` (`dq08_global`, `dq08_inter`, en %) ; NOT_TESTED si total des montées (global ou intermédiaire) nul |
| **Choix validé** | Tronçon intermédiaire = tous les arrêts sauf le premier et le dernier de `StopsJson` (le référentiel ne le définit pas) |
| **Choix validé** | « Flux nécessaires » = montées et descentes de **tous** les arrêts listés : un seul arrêt sans flux rend la règle NOT_TESTED |

**Exemple chiffré** (train 952106 du 2026-08-04, ligne non renseignée, CountingId 26214,
5 arrêts d'Athus à Libramont).
Montées : 1 + 1 + 2 + 2 + 2 = 8 ; descentes : 2 + 6 + 6 + 1 + 3 = 18.
Écart global = |8 − 18| / 8 = 125 %. Tronçon intermédiaire (Longwy, Virton, Marbehan) :
montées 5, descentes 13 → |5 − 13| / 5 = 160 %. Les deux dépassent 5 % → **FAIL**.

**Résultats observés.**

| Maille | PASS | WARNING | FAIL | NOT_TESTED | FAIL parmi testés |
|---|--:|--:|--:|--:|--:|
| Train | 390 (7,8 %) | 0 | 1 368 (27,4 %) | 3 242 (64,8 %) | 77,8 % |

- NOT_TESTED : 3 131 trains ont au moins un arrêt sans montées / descentes ; 111 ont un total
  de montées nul (dont 36 trajets de moins de 3 arrêts, sans tronçon intermédiaire).
- Sur les 1 758 trains testés : 1 368 dépassent 5 % sur les deux écarts (FAIL) ; 296 ne
  dépassent que sur le tronçon intermédiaire et 32 que sur le global (PASS, car le ET exige
  les deux) ; 62 sont sous 5 % des deux côtés.
- L'écart global médian des trains testés est de 33,1 %.

**Interprétation.** La règle n'est testable que sur un train sur trois, car il suffit d'un
arrêt sans flux. Quand elle l'est, le déséquilibre est la norme (écart médian 33 %) : les
montées et les descentes ne se compensent pas sur la plupart des trajets complets.

**Actions possibles.** Valider la définition du tronçon intermédiaire ; décider si la règle
doit être calculée sur les seuls arrêts mesurés plutôt que NOT_TESTED.

---

### DQ-09 – Remise à zéro à l'origine

**Objectif métier.** À l'origine, le train part vide : l'occupation doit égaler les montées.
Une occupation nulle avec des montées signale un capteur d'occupation hors service au départ.

**Granularité.** Train.

**Texte du référentiel.**

| | |
|---|---|
| Description | Vérifie qu'aucune occupation incohérente n'est présente avant les premières montées. |
| Évolution | Ajout du cas Occupation = 0 avec montées > 0, classé FAIL. |
| Formule | Écart origine = \|Occupation à l'origine − Montées à l'origine\| ; comparer l'écart au seuil métier de 2 %. |
| PASS | Origine identifiée, données disponibles, écart dans le seuil et absence de cas incohérent |
| WARNING | Non prévu |
| FAIL | Occupation = 0 avec montées > 0, ou écart hors seuil de 2 % |
| NOT_TESTED | Origine non identifiable ou occupation/montées absentes |

**Application dans le code.**

| | |
|---|---|
| **Choix validé** | Origine = arrêt `stopType = Start` ; pas d'origine ou origine sans donnée → NOT_TESTED |
| Conforme | Cas « occupation = 0 et montées > 0 » → FAIL ; NOT_TESTED si occupation ou montées absentes |
| **Choix validé** | Le référentiel ne dit pas à quoi rapporter les 2 % : le code les rapporte à la **capacité** à l'origine, comme DQ-03 (taux = écart / capacité) |
| Conséquence de l'hypothèse | Une capacité nulle à l'origine rend la règle NOT_TESTED (742 trains), cas absent de la liste NOT_TESTED du référentiel |

**Exemple chiffré** (train 10459 du 2026-08-08, ligne T10/60, CountingId 27599).
À l'origine Troisvierges : occupation 0, montées 1, capacité 69. Occupation nulle avec
montées positives → **FAIL**, même si l'écart (1 voyageur, soit 1,4 % de la capacité) serait
sous le seuil de 2 %.

**Résultats observés.**

| Maille | PASS | WARNING | FAIL | NOT_TESTED | FAIL parmi testés |
|---|--:|--:|--:|--:|--:|
| Train | 1 934 (38,7 %) | 0 | 324 (6,5 %) | 2 742 (54,8 %) | 14,3 % |

- NOT_TESTED : 1 903 origines sans donnée, 742 origines avec capacité nulle, 82 trains sans
  origine, 15 origines sans montées.
- FAIL : 307 pour un taux > 2 %, 17 pour une occupation nulle avec montées.
- Sur les 2 241 trains où le taux est calculé, le taux médian est de 0,3 % ; le maximum de
  63,77 %. Dans 1 519 trains, l'occupation à l'origine est exactement égale aux montées.
- Sensibilité à l'hypothèse (simulation, non appliquée) : si les 2 % étaient rapportés aux
  **montées** à l'origine, 3 000 trains seraient testables (les 742 à capacité nulle le
  deviendraient) et 1 436 seraient en FAIL au lieu de 324.

**Interprétation.** Quand l'origine est mesurée, la remise à zéro est en général correcte.
Le principal problème est l'origine manquante. La base des 2 % change fortement le
résultat : elle doit être tranchée par le métier.

**Actions possibles.** Choisir la base des 2 % (capacité, montées, autre) et le traitement
d'une capacité nulle à l'origine.

---

### DQ-10 – Occupation reconstruite non négative

**Objectif métier.** En cumulant montées moins descentes depuis le début du trajet, on ne
doit jamais obtenir un nombre négatif de voyageurs à bord. Un cumul négatif signale des
descentes surcomptées (ou des montées sous-comptées) et localise le premier arrêt fautif.

**Granularité.** Train / Station.

**Texte du référentiel.**

| | |
|---|---|
| Description | Vérifie que le cumul des montées moins les descentes ne devient pas négatif pendant le trajet. |
| Évolution | Nouveau KPI : identification du premier arrêt où l'occupation reconstruite devient négative. |
| Formule | Occupation reconstruite à l'arrêt n = somme cumulée des montées jusqu'à n − somme cumulée des descentes jusqu'à n ; retenir le minimum du trajet. |
| PASS | Minimum du cumul ≥ 0 |
| WARNING | −3 ≤ minimum du cumul < 0 |
| FAIL | Minimum du cumul < −3 |
| NOT_TESTED | Au moins un flux nécessaire du parcours est absent |

**Application dans le code.**

| | |
|---|---|
| Conforme | Formule, seuils, minimum du trajet au niveau Train, NOT_TESTED dès qu'un flux du parcours manque ; premier arrêt négatif publié (`dq10_first_neg` dans `train_dq.csv`) |
| **Choix validé** | Maille Station : le statut porte sur le cumul à l'arrêt n, NOT_TESTED dès qu'un arrêt sans flux précède ou est l'arrêt n |
| Point ouvert | Le cumul part de 0 au premier arrêt listé : faux pour les trajets partiels (80 des 82 trains sans origine ont déjà des voyageurs au premier arrêt) |

**Exemple chiffré** (train 952106 du 2026-08-04, CountingId 26214, déjà vu en DQ-08).
Cumuls successifs : Athus 1 − 2 = −1 ; Longwy −1 + 1 − 6 = −6 ; Virton −6 + 2 − 6 = −10 ;
Marbehan −9 ; Libramont −10. Minimum −10 < −3 → **FAIL** ; premier arrêt négatif : Athus.
Ce train a déjà 54 voyageurs à bord à Athus (premier arrêt listé, de type `Stop`) : le cumul
négatif vient ici du trajet partiel, pas forcément d'un défaut de capteur.

**Résultats observés.**

| Maille | PASS | WARNING | FAIL | NOT_TESTED | FAIL parmi testés |
|---|--:|--:|--:|--:|--:|
| Train | 948 (19,0 %) | 242 (4,8 %) | 679 (13,6 %) | 3 131 (62,6 %) | 36,3 % |
| Station | 23 915 (53,2 %) | 1 004 (2,2 %) | 2 405 (5,4 %) | 17 625 (39,2 %) | 8,8 % |

- NOT_TESTED Train : le premier arrêt sans flux est l'origine pour 1 924 trains, le terminus
  pour 897, un arrêt intermédiaire pour 310.
- Minimum le plus bas : −142.
- Gares où le cumul devient le plus souvent négatif pour la première fois :
  Bascharage-Sanem (121 trains), Luxembourg (109), Dippach-Reckange (95), Rodange (84),
  Bettembourg-V (76).
- Parmi les 679 FAIL, 20 sont des trains sans origine (trajets partiels probables).

**Interprétation.** Quand le trajet est complet, un train sur trois passe sous zéro, souvent
aux mêmes gares : piste d'un défaut localisé (sens de passage, porte ou quai particulier,
**à confirmer**). L'absence de flux à l'origine bloque la majorité des contrôles.

**Actions possibles.** Examiner les gares récurrentes ; pour les trains sans origine, décider
s'il faut démarrer le cumul à l'occupation mesurée au premier arrêt plutôt qu'à 0.

---

### DQ-11 – Cohérence entre les mailles

**Objectif métier.** Les chiffres d'un arrêt doivent être égaux à la somme des chiffres de
ses véhicules, et ceux du train à la somme de ses arrêts. Sinon, le total publié dépend de la
maille d'agrégation choisie.

**Granularité.** Train / Station / EVN.

**Texte du référentiel.**

| | |
|---|---|
| Description | Vérifie que les résultats calculés aux mailles Train, Station et EVN se réconcilient. |
| Évolution | Nouveau KPI de réconciliation entre les vues. |
| Formule | Écart relatif = \|Valeur maille A − valeur maille B\| / MAX(\|valeur A\| ; \|valeur B\|) × 100 ; comparer occupation Station et somme EVN au même arrêt, puis montées Train et somme Station. |
| PASS | Écart relatif ≤ 1 % |
| WARNING | 1 % < écart relatif ≤ 5 % |
| FAIL | Écart relatif > 5 % |
| NOT_TESTED | Une des vues ou une des valeurs nécessaires est incomplète |

**Application dans le code.**

| | |
|---|---|
| **Choix validé** | Station comparée à la somme de ses véhicules seulement : la comparaison « montées Train et somme Station » n'est pas faite, car l'extraction n'a pas de montées à la maille Train. Train = pire statut de ses arrêts |
| Conforme | Formule de l'écart relatif, seuils 1 % / 5 %, NOT_TESTED si une valeur manque à l'arrêt ou sur un véhicule |
| Extension | Le code compare aussi les montées et les descentes de l'arrêt à la somme des véhicules (le référentiel ne cite que l'occupation) et garde le pire des trois écarts. Montées et descentes d'un véhicule = 1re + 2e classe |
| Écart | Pas de statut DQ-11 à la maille EVN, alors que la granularité du référentiel la cite |

**Exemple chiffré** (exemple illustratif). Un arrêt indique 120 voyageurs à bord ; ses trois
véhicules en indiquent 40 + 45 + 32 = 117. Écart = |120 − 117| / 120 = 2,5 % → WARNING.

**Résultats observés.**

| Maille | PASS | WARNING | FAIL | NOT_TESTED | FAIL parmi testés |
|---|--:|--:|--:|--:|--:|
| Train | 4 825 (96,5 %) | 0 | 0 | 175 (3,5 %) | 0 % |
| Station | 37 257 (82,9 %) | 0 | 0 | 7 692 (17,1 %) | 0 % |

- **Constat notable : sur les 37 257 arrêts testés, l'écart est exactement 0 à chaque fois.**
- NOT_TESTED : 4 872 arrêts sans donnée et 2 820 arrêts mesurés où une valeur manque
  (à l'arrêt ou sur un véhicule) ou sans véhicule.

**Interprétation.** Les valeurs d'arrêt de l'extraction sont très probablement calculées
comme la somme des véhicules (**à confirmer**). Dans ce cas, DQ-11 ne peut rien détecter sur
cette extraction et compte toujours PASS dans le score, ce qui le gonfle légèrement.

**Actions possibles.** Confirmer l'origine des valeurs d'arrêt ; si elles sont calculées,
envisager une comparaison Train / Station sur une grandeur disponible au niveau train (le
sens de `TotalOccupancy` est **à confirmer**) ou donner à DQ-11 un poids nul.

---

### DQ-12 – Valeurs exploitables

**Objectif métier.** Mesurer la part des valeurs attendues réellement présentes et lisibles.
Une valeur absente ne doit pas être confondue avec un vrai zéro ; un vrai zéro est une valeur
exploitable.

**Granularité.** Tous grains.

**Texte du référentiel.**

| | |
|---|---|
| Description | Mesure la part de valeurs réellement utilisables en distinguant absences, valeurs illisibles et vrais zéros. |
| Évolution | Nouveau KPI de taux d'exploitabilité. |
| Formule | Taux exploitable = 1 − (nombre de valeurs absentes + nombre de valeurs illisibles) / nombre total de valeurs. |
| PASS | Taux exploitable = 100 % |
| WARNING | 98 % ≤ taux exploitable < 100 % |
| FAIL | Taux exploitable < 98 % |
| NOT_TESTED | Périmètre vide, comptage indisponible ou taux non calculable |

**Application dans le code.**

| | |
|---|---|
| Conforme | Formule et seuils ; absences et valeurs illisibles comptées séparément (`dq12_absents`, `dq12_illisibles`) ; vrais zéros exploitables ; NOT_TESTED si aucune valeur attendue (aucun cas dans ce jeu) |
| **Choix validé (périmètre)** | Le référentiel ne fixe pas la liste des valeurs contrôlées. Train : `TotalCapacity`, `TotalOccupancy`, `OccupancyRatePercent` + 4 valeurs par arrêt **avec donnée** (occupation, capacité, montées, descentes) ; Station : ces 4 valeurs ; EVN : occupation, `sensorCapacity`, montées, descentes |
| **Choix validé (2026-11-11)** | Au niveau Train, les arrêts sans aucune donnée **ne sont plus comptés** : ils relèvent de DQ-07 et ne doivent plus être pénalisés une seconde fois. Au niveau Station, un arrêt sans donnée reste à 0 % exploitable |

**Exemple chiffré** (train 6107 du 2026-08-04, CountingId 26241).
Valeurs attendues = 3 (train) + 4 arrêts avec donnée × 4 = 19 ; les 2 arrêts sans donnée
(origine et terminus) ne sont pas comptés. Les 19 valeurs sont présentes : taux = 100 % →
**PASS**. Avant le 2026-11-11, ces 2 arrêts comptaient pour 8 valeurs absentes : taux 19 / 27 =
70,37 % → FAIL.

**Résultats observés.**

| Maille | PASS | WARNING | FAIL | NOT_TESTED | FAIL parmi testés |
|---|--:|--:|--:|--:|--:|
| Train | 4 248 (85,0 %) | 0 | 752 (15,0 %) | 0 | 15,0 % |
| Station | 39 314 (87,5 %) | 0 | 5 635 (12,5 %) | 0 | 12,5 % |
| EVN | 161 829 (96,6 %) | 0 | 5 724 (3,4 %) | 0 | 3,4 % |

- **Aucune valeur illisible** dans tout le jeu : tous les défauts sont des absences
  (1 528 valeurs absentes comptées au niveau train, arrêts sans donnée exclus). 3 934 arrêts ont une occupation de
  vrai zéro, comptée comme exploitable.
- Station en FAIL : 4 872 arrêts sans donnée (taux 0 %) et 763 arrêts mesurés sans montées
  ni descentes (taux 50 %), dont 706 terminus.
- EVN en FAIL : 5 724 passages sans montées ni descentes (taux 50 %).
- Train : sur les 752 trains en FAIL, 26 sont aussi en FAIL DQ-07 ; les autres ont tous leurs
  arrêts mais des flux manquent (surtout au terminus). Taux minimal : 71,43 %. 2 380 trains en
  FAIL DQ-07 sont PASS en DQ-12 : l'arrêt manquant n'est plus pénalisé deux fois.
- **Avant la modification** (arrêts sans donnée comptés) : Train 1 868 PASS, 3 132 FAIL ; les
  2 406 trains en FAIL DQ-07 étaient tous en FAIL DQ-12 ; taux minimal 12,73 %.

**Interprétation.** Le recouvrement DQ-07 / DQ-12 est levé au niveau Train : DQ-12 ne mesure
plus que la qualité des valeurs des arrêts renseignés. Les flux absents au terminus sont un
défaut distinct de l'arrêt manquant.

**Actions possibles.** Valider le périmètre des valeurs contrôlées ; signaler à l'émetteur
les terminus sans flux.

---

### DQ-13 – Capteur figé

**Objectif métier.** Repérer un véhicule dont le comptage reste identique d'un arrêt à l'autre,
ce qui peut trahir un capteur figé. Le référentiel précise qu'une suspicion seule ne prouve pas
une panne : la règle qualifie, elle ne corrige rien.

**Granularité.** EVN / Séquence ; le Train prend le pire statut de ses EVN. Pas de statut à la
maille Station.

**Texte du référentiel.**

| | |
|---|---|
| Description | Détecte une valeur identique répétée sur plusieurs arrêts, pouvant indiquer un capteur figé. |
| Évolution | Nouveau KPI sur les répétitions consécutives : une suspicion seule ne prouve pas une panne. |
| Formule | Compter, par EVN et par séquence ordonnée d'arrêts, le nombre maximal de répétitions consécutives d'une même valeur de comptage. |
| PASS | Au plus 3 répétitions, sans occupation constante sur au moins 5 arrêts. |
| WARNING | 4 ou 5 répétitions, sans cas de constance classé FAIL. |
| FAIL | Au moins 6 répétitions, ou occupation constante sur au moins 5 arrêts. |
| NOT_TESTED | Séquence incomplète ou parcours trop court pour conclure. |

**Application dans le code** (`dq13_status`, colonnes `DQ13` et `dq13_repetitions` de `evn_dq.csv`,
`DQ13`, `dq13_repetitions_max` et `dq13_evn_figes` de `train_dq.csv`).

| | |
|---|---|
| Conforme | Seuils 3 / 4-5 / 6 et règle de constance ; statut propre à chaque EVN ; Train = pire statut des EVN |
| **Hypothèse à valider (valeur)** | La « valeur de comptage » est l'occupation de l'EVN à l'arrêt (`occupancy.allClasses`) |
| **Hypothèse à valider (répétitions)** | Une répétition = un arrêt de la plus longue suite d'arrêts consécutifs à valeur identique : 4 arrêts identiques font 4 répétitions |
| **Hypothèse à valider (constance)** | « Occupation constante » = même valeur à tous les arrêts de la séquence, sur au moins 5 arrêts |
| **Hypothèse à valider (NOT_TESTED)** | Séquence incomplète = au moins un arrêt du train où l'EVN n'a pas d'occupation (arrêt sans donnée, EVN absent) ; parcours trop court = moins de 5 arrêts |
| **Hypothèse à valider (zéros)** | Un zéro répété compte comme une valeur répétée, comme le texte le dit (constat C28) |

**Exemple chiffré** (train 26215, EVN 948200241537). Occupation de l'EVN aux 5 arrêts : 5, 5, 5, 5, 5.
Séquence complète de 5 arrêts, occupation constante → **FAIL**. Avec 5, 5, 5, 5, 6 : 4 répétitions → WARNING.

**Résultats observés.**

| Maille | PASS | WARNING | FAIL | NOT_TESTED | FAIL parmi testés |
|---|--:|--:|--:|--:|--:|
| Train | 473 (9,5 %) | 507 (10,1 %) | 1 516 (30,3 %) | 2 504 (50,1 %) | 60,3 % |
| EVN / séquence (20 097) | 4 900 (24,4 %) | 2 716 (13,5 %) | 3 101 (15,4 %) | 9 380 (46,7 %) | 28,4 % |

- NOT_TESTED : 9 086 séquences incomplètes (arrêt sans donnée ou EVN absent d'un arrêt) et 294 de
  moins de 5 arrêts.
- Les 3 101 séquences FAIL : 1 496 ont une occupation constante sur tout le trajet, dont 1 448 constamment à zéro ;
  2 535 ont leur plus longue suite sur un zéro (82 %), 566 sur une valeur non nulle.
- Plus longue suite la plus fréquente parmi les FAIL : 10 arrêts (895 séquences).

**Interprétation.** La règle est mécaniquement sévère sur les zéros : un véhicule vide sur tout
le trajet est classé FAIL, alors que le référentiel dit lui-même qu'une suspicion ne prouve pas
une panne. Le chiffre mesure donc surtout des véhicules à zéro, pas des capteurs figés
prouvés (constat C28). Les valeurs non nulles répétées (566 séquences FAIL) sont les cas les plus
suspects. Voir [05_constats_qualite.md](05_constats_qualite.md), C28.

**Actions possibles.** Faire confirmer par le métier le traitement des zéros répétés (exclusion,
seuil distinct) et la définition de « répétition » ; croiser avec DQ-06 (capteurs à 100 %) pour
distinguer un véhicule vide d'un capteur muet.

---

### DQ-14 – Flux aux extrémités

**Objectif métier.** Vérifier qu'aucun voyageur ne descend à l'origine ni ne monte au terminus,
ce qui indiquerait un flux mal affecté ou un trajet mal découpé.

**Granularité.** Train.

**Texte du référentiel.**

| | |
|---|---|
| Description | Vérifie les descentes à l'origine et les montées au terminus. |
| Évolution | Nouveau KPI sur les flux anormaux aux extrémités du trajet. Point à investiguer — Dosto : un même fichier couvre les descentes au terminus d'une circulation et les montées à l'origine de la suivante, pour le même train physique mais des numéros de train différents (ex. Luxembourg). Vérifier le rattachement des flux aux deux circulations et son impact sur le KPI avant toute évolution. Formule et seuils inchangés dans l'attente de confirmation. |
| Formule | Part aux extrémités = (Descentes à l'origine + Montées au terminus) / Total des flux du trajet × 100. |
| PASS | Descentes à l'origine = 0 ET montées au terminus = 0. |
| WARNING | Flux non nuls aux extrémités et part ≤ 2 %. |
| FAIL | Part aux extrémités > 2 %. |
| NOT_TESTED | Extrémités ou flux absents, ou ratio non calculable. |

**Application dans le code** (`dq14_status`, colonnes `DQ14`, `dq14_part`, `dq14_desc_origine`,
`dq14_mont_terminus` de `train_dq.csv`).

| | |
|---|---|
| Conforme | Formule et seuils tels que dans le référentiel, sans prise en compte du point Dosto (« formule et seuils inchangés ») |
| **Choix par défaut (origine / terminus)** | Arrêts `Start` / `End`, comme DQ-03 et DQ-09 ; sans l'un des deux, NOT_TESTED |
| **Choix validé (2026-11-11, total des flux et NOT_TESTED)** | NOT_TESTED seulement si une extrémité (`Start` ou `End`) ou son flux (descentes à l'origine, montées au terminus) manque, ou si le total est nul. Le total des flux porte sur les arrêts qui ont leurs deux flux (`dq14_arrets_sans_flux` donne le nombre d'arrêts écartés). Remplace le choix par défaut « un flux absent à un arrêt quelconque rend la règle NOT_TESTED » |

**Exemple chiffré** (train 5060 du 2026-08-04, CountingId 26339). Descentes à l'origine 0, montées
au terminus (Athus) 45, part = 33,09 % > 2 % → **FAIL**.

**Résultats observés.**

| Maille | PASS | WARNING | FAIL | NOT_TESTED | FAIL parmi testés |
|---|--:|--:|--:|--:|--:|
| Train | 1 907 (38,1 %) | 2 (< 0,1 %) | 4 (0,1 %) | 3 087 (61,7 %) | 0,3 % |

- NOT_TESTED : 3 005 trains dont une extrémité est mesurée sans le flux attendu (surtout les
  montées au terminus), ou au total nul, et 82 trains sans `Start` ni `End`.
- 155 trains sont PASS alors qu'un arrêt intermédiaire n'a pas ses flux : avec l'ancien choix
  ils étaient NOT_TESTED.
- Les 6 trains en écart : 26339 (train 5060, Luxembourg > Athus, 45 montées au terminus, 33,1 %),
  29850 (3630, Diekirch > Luxembourg, 7 montées, 8,1 %), 30095 (504854, Luxembourg > Wasserbillig,
  1 montée sur 2 arrêts, 25,0 %), 26456 (6844, Pétange > Bettembourg-V, 4 descentes à l'origine, FAIL à 2,1 %),
  26510 (6721, Bettembourg-V > Rodange, 1 descente, WARNING à 0,4 %) et 28196 (10459,
  Troisvierges > Luxembourg, 1 montée au terminus, WARNING à 0,35 %).

**Interprétation.** Aucune anomalie massive, mais la règle ne peut être testée que sur 38 % des
trains. Les 6 écarts sont trop peu nombreux pour conclure sur le point Dosto (voir C27).

**Actions possibles.** Faire confirmer le rattachement des flux Dosto aux deux circulations avant
toute évolution de la formule.

---

## 5. Score de confiance

### 5.1 Principe

Le score résume, sur 100, la confiance qu'on peut accorder aux comptages d'un train (et,
séparément, d'un arrêt). Il est calculé par `src/score_engine.py` avec les paramètres de
`config/score_config.json`.

**Le score ne fait pas partie du référentiel des règles. Tous ses paramètres sont
PROVISOIRES.** En particulier, les 14 règles ont le **même poids (1)**, en attendant que le
métier définisse des poids.

### 5.2 Calcul

| Élément | Règle |
|---|---|
| Points par statut | PASS = 1 ; WARNING = 0,5 ; FAIL = 0 |
| NOT_TESTED | Exclu du calcul (ni au numérateur, ni au dénominateur) |
| Score | 100 × Σ (poids × points) / Σ poids des règles testées |
| Couverture | 100 × Σ poids des règles testées / Σ poids des règles applicables |
| Règles du train | Les 14 règles |
| Règles d'un arrêt | DQ-01, 02, 04, 05, 06, 10, 11, 12 |

**Verdict** :

| Verdict | Condition |
|---|---|
| Non évaluable | Couverture < 50 % |
| Bonne | Score ≥ 80 |
| À surveiller | 60 ≤ score < 80 |
| Mauvaise | Score < 60 |

**Exemple chiffré** (train 6107, CountingId 26241, chiffres au 2026-11-11). Statuts : DQ-01 NOT_TESTED
(le premier arrêt n'a pas de flux), DQ-02 PASS, DQ-03 NOT_TESTED, DQ-04 PASS, DQ-05 FAIL, DQ-06 PASS,
DQ-07 FAIL, DQ-08 NOT_TESTED, DQ-09 NOT_TESTED, DQ-10 NOT_TESTED, DQ-11 PASS, DQ-12 PASS, DQ-13 et
DQ-14 NOT_TESTED (arrêts manquants).
7 règles testées, 5 PASS → score = 100 × 5 / 7 = **71,4** ; couverture = 7 / 14 = **50,0 %**
→ verdict **À surveiller** (avant les modifications du 2026-11-11 : 50,0 et Mauvaise).

### 5.3 Résultats

| Verdict | Trains | Part |
|---|--:|--:|
| Bonne | 1 319 | 26,4 % |
| À surveiller | 2 235 | 44,7 % |
| Mauvaise | 1 438 | 28,8 % |
| Non évaluable | 8 | 0,2 % |

- Score médian 71,4 (minimum 20,0, maximum 100) ; couverture médiane 71,4 % (minimum 35,7 %).
- Répartition des scores : 11 trains entre 20 et 30, 101 entre 30 et 40, 323 entre 40 et 50,
  1 011 entre 50 et 60, 936 entre 60 et 70, 1 299 entre 70 et 80, 1 249 entre 80 et 90,
  65 entre 90 et 100, 5 à 100.
- Les 8 trains « Non évaluable » ont moins de la moitié des règles testées (couverture minimale
  35,7 %, soit 5 règles sur 14).
- Arrêts : 26 688 Bonne, 11 380 À surveiller, 2 009 Mauvaise, 4 872 Non évaluable
  (les arrêts sans donnée).
- **Avant les modifications du 2026-11-11** : Bonne 366, À surveiller 2 679, Mauvaise 1 948,
  Non évaluable 7 ; arrêts 30 857 / 8 124 / 1 096 / 4 872. Le changement vient surtout de DQ-12
  (FAIL 3 132 → 752) et de DQ-04 (FAIL 829 → 0).

### 5.4 Ce qui fait chuter les trains en Mauvaise

Part des 1 438 trains « Mauvaise » où chaque règle est en FAIL (recalculé le 2026-11-11) :

| Règle | Part des trains Mauvaise en FAIL |
|---|--:|
| DQ-05 État du matériel | 95,7 % |
| DQ-06 Disponibilité des capteurs | 95,1 % |
| DQ-01 Cohérence flux / occupation | 75,7 % |
| DQ-13 Capteur figé | 60,4 % |
| DQ-08 Équilibre des flux | 39,5 % |
| DQ-12 Valeurs exploitables | 38,3 % |
| DQ-03 Remise à zéro au terminus | 32,2 % |
| DQ-02 Complétude EVN | 25,5 % |
| DQ-07 Complétude des arrêts | 21,8 % |
| DQ-09 Remise à zéro à l'origine | 20,8 % |
| DQ-10 Occupation reconstruite non négative | 17,5 % |
| DQ-14 Flux aux extrémités | 0,2 % |
| DQ-11 Cohérence entre les mailles | 0 % |
| DQ-04 Charge critique | 0 % |

Un train Mauvaise cumule de 3 à 8 FAIL (91 trains à 3 FAIL, 257 à 4, 396 à 5, 627 à 6,
63 à 7, 4 à 8).

Lecture : avec des poids égaux, le verdict Mauvaise est porté d'abord par DQ-05 (indicateur
dégradé, dont le sens est à confirmer) et DQ-06 (règle très sévère au niveau train), puis
par DQ-01 (reconstruction cumulée, sévère), puis par DQ-13, dont les FAIL viennent
surtout de zéros répétés (C28). Le double comptage de la complétude (DQ-07 et DQ-12) et le
poids de DQ-04 (capacités nulles) ont disparu avec les modifications du 2026-11-11.

### 5.5 Ce qu'il faudra décider

1. **Les poids métier des 14 règles.** Points d'attention : DQ-11 qui ne détecte rien sur
   cette extraction ; DQ-05 dont le sens est à confirmer ; DQ-04 qui ne produit plus aucun
   FAIL ; DQ-01 cumulée très sévère. Le recouvrement DQ-07 / DQ-12 est levé au niveau Train.
2. Les seuils de verdict (80 / 60) et la couverture minimale (50 %).
3. Le traitement de NOT_TESTED (exclu aujourd'hui ; le code permet aussi de le compter
   comme FAIL ou à 0,5).

---

## 6. Imputation

### 6.1 Règle de décision

Pour chaque train, `score_engine.py` recommande :

| Décision | Condition |
|---|---|
| Rien à imputer | Tous les arrêts listés sont mesurés |
| Imputer | Des arrêts manquent, le verdict est Bonne ou À surveiller, et au moins 50 % des arrêts sont mesurés |
| Exclure | Tous les autres cas (trop d'arrêts manquants, ou verdict Mauvaise / Non évaluable) |

Cette règle ne fait pas partie du référentiel : le seuil de 50 % et la liste des verdicts
imputables sont des paramètres **provisoires** de `score_config.json`. Le projet **liste les
arrêts à imputer, il ne calcule pas les valeurs imputées** : la méthode d'imputation reste à
définir.

### 6.2 Lire `train_score.csv`

| Colonne | Contenu |
|---|---|
| `score`, `couverture`, `verdict` | Voir section 5 |
| `part_arrets_mesures` | Part des arrêts listés qui ont une occupation mesurée (%) |
| `imputation` | Rien à imputer / Imputer / Exclure |
| `position_manquants` | Rempli si des arrêts manquent : `début` (origine), `fin` (terminus), `trou` (arrêt intermédiaire entre deux arrêts mesurés), ou une combinaison (`début+fin`…) |
| `arrets_a_imputer` | Rempli seulement pour « Imputer » : noms des arrêts à compléter, séparés par `|` |

Exemple : le train 6107 (CountingId 26241) a `part_arrets_mesures = 66.7`,
`position_manquants = début+fin` et un verdict À surveiller (Mauvaise avant le 2026-11-11, donc
alors exclu) : `imputation = Imputer` et `arrets_a_imputer = Bettembourg|Volmerange-les-Mines`.

### 6.3 Résultats

| Décision | Trains | Détail par verdict |
|---|--:|---|
| Rien à imputer | 2 594 (51,9 %) | 368 Bonne, 1 096 À surveiller, **1 124 Mauvaise**, 6 Non évaluable |
| Imputer | 1 939 (38,8 %) | 883 Bonne, 1 056 À surveiller |
| Exclure | 467 (9,3 %) | 314 Mauvaise, 83 À surveiller, 68 Bonne, 2 Non évaluable |

(Chiffres du 2026-11-11 ; avant les modifications de règles : Imputer 1 430, Exclure 976.)

- Trains à imputer, selon la position des manques : début et fin 1 411, trou 176, fin 168,
  début 163, début + fin + trou 16, fin + trou 3, début + trou 2.
- Nombre d'arrêts à imputer par train : 1 arrêt (443 trains), 2 arrêts (1 429), 3 (18),
  4 (17), 5 (5), 6 (9), 7 (18).
- Trains exclus : 292 Mauvaise avec au moins 50 % d'arrêts mesurés, 22 Mauvaise avec moins
  de 50 %, 83 À surveiller avec moins de 50 %, 68 Bonne avec moins de 50 %, 2 Non évaluable.

**Point d'attention** : la décision ne regarde la qualité que si des arrêts manquent. Les
1 124 trains complets mais au verdict Mauvaise sont classés « Rien à imputer », ce qui ne
veut pas dire qu'ils sont fiables. Le métier doit décider s'ils doivent être exclus ou
signalés.

### 6.4 Pourquoi les manques sont surtout à l'origine et au terminus

Constats vérifiés :

- 4 872 arrêts sans donnée : 1 903 origines, 1 856 terminus, 1 113 arrêts intermédiaires.
  Plus d'une origine sur trois (38,7 %) et plus d'un terminus sur trois (37,7 %) manquent,
  contre 3,2 % des arrêts intermédiaires.
- Les manques aux extrémités sont concentrés sur les trains RB des séries 2400 et 2450 :
  68,3 % des origines / terminus manquent pour les RB série 2400, 39,6 % pour les RB
  série 2450, contre moins de 1 % pour les trains RB et RE des séries LOCOMOTIVE et DOSTO.
- 4 871 des 4 872 arrêts sans donnée ont `stationPassed = faux`.
- De plus, 706 terminus mesurés n'ont pas de montées / descentes.

Explications possibles, **à confirmer** avec l'exploitant : le comptage de certaines rames
démarre après le départ de l'origine et s'arrête avant l'arrivée au terminus ; le passage en
gare d'origine ou de terminus n'est pas détecté (`stationPassed = faux`) ; ou une partie de
ces arrêts n'est réellement pas desservie.

Conséquence pratique : les deux arrêts à imputer sont le plus souvent l'origine et le
terminus, c'est-à-dire les arrêts où le train est censé être vide (avant les montées à
l'origine, après les descentes au terminus). Ces manques rendent aussi non testables les
règles DQ-03, DQ-09, DQ-08 et DQ-10, ce qui explique leurs forts taux de NOT_TESTED.

---

## 7. Guide de lecture du dashboard

Dashboard : [Qualité du comptage passagers](https://claude.ai/artifact/VpBCQaECPCozXq7KCLk9m7)
(page privée, partageable depuis le menu Partager). Les chiffres de ce document ont été
recalculés depuis les fichiers `output/` ; sans filtre, le dashboard doit afficher les mêmes
valeurs (non vérifié à l'écran).

### 7.1 Phrase d'en-tête

« Sur N trains retenus, X ont au moins une règle en FAIL. À la maille …, la règle la plus
souvent en échec est … ». « Retenus » = trains qui passent les filtres. La maille est celle
choisie dans le graphique « Statut des 14 règles ».

### 7.2 Filtres

| Filtre | Effet |
|---|---|
| Date de circulation | Garde les trains du jour choisi |
| Ligne | Garde les trains de la ligne (code ligne ; « Non renseigné » pour les 82 trains sans ligne) |
| Type de train | RB, RE, HPV140, IC, Non renseigné |
| Série | Série du train (2400, 2450, TER2N, LOCOMOTIVE, DOSTO, Non renseigné) |
| **Capteurs extérieurs valides (DQ-06)** | Filtre prévu par le référentiel (DQ-06). Oui : aucun capteur extérieur invalide sur l'objet compté ; Non : au moins un capteur extérieur invalide ; Sans donnée : aucune donnée capteur |
| **Tous les capteurs au vert (DQ-06 en PASS)** | Oui, tous verts : DQ-06 en PASS (capteurs extérieurs **et** intérieurs à 100 %) ; Non, au moins un invalide : DQ-06 en WARNING ou FAIL ; Sans donnée capteur : DQ-06 NOT_TESTED |
| Verdict qualité | Bonne, À surveiller, Mauvaise, Non évaluable |
| Décision d'imputation | Rien à imputer, Imputer, Exclure |
| Réinitialiser | Efface tous les filtres |

Date, ligne, type, série, verdict et imputation filtrent les trains, puis leurs arrêts et
leurs véhicules. **Les deux filtres capteurs s'appliquent à l'objet compté dans chaque
graphique** : au train dans un graphique de trains, à l'arrêt dans un graphique d'arrêts, au
véhicule à un arrêt dans un graphique de véhicules. Ainsi, « Capteurs extérieurs valides =
Oui » sur un graphique d'arrêts garde les arrêts dont les capteurs extérieurs sont bons,
même si le train a un problème à un autre arrêt.

Différence entre les deux filtres capteurs : le premier ne regarde que les capteurs
extérieurs, le second tous les capteurs. Au niveau train, 2 383 trains ont tous leurs
capteurs extérieurs valides, mais seulement 2 074 ont tous leurs capteurs au vert. Un train
peut avoir ses capteurs extérieurs valides et être en FAIL DQ-06 (284 trains : capteurs
intérieurs en défaut).

### 7.3 Onglets

**Vue d'ensemble**
- Tuiles : nombre de trains, d'arrêts (maille Station), de véhicules × arrêts (maille EVN),
  de trains avec au moins un FAIL, d'arrêts sans aucune donnée, de trains aux capteurs
  extérieurs valides.
- « Statut des 14 règles » : part de chaque statut par règle, à la maille choisie avec les
  boutons Train / Station / EVN. Une règle non calculée à une maille est signalée « Non
  applicable ». La part de FAIL est calculée sur les cas testés.
- « FAIL par jour de circulation » et « FAIL par ligne » : cartes de chaleur, plus la case
  est foncée, plus la part de FAIL parmi les cas testés est forte ; gris clair : rien de
  testable. Utile pour repérer un jour ou une ligne anormale.

**Score de confiance**
- Phrase de synthèse : part des trains Bonne, À surveiller, Mauvaise, Non évaluable.
- Tuiles : score médian, couverture médiane, trains à imputer, trains à exclure.
- « Répartition des scores » : histogramme par tranche de score.
- « Verdict par ligne » : nombre de trains par verdict pour chaque ligne.
- « Décision d'imputation » : Rien à imputer / Imputer / Exclure.
- « Trains à imputer : position des arrêts manquants » : début, fin, trou et combinaisons.
- « Ce qui fait chuter les trains en Mauvaise » : pour les trains Mauvaise, part où chaque
  règle est en FAIL (voir section 5.4).
- « Paramètres du score » : poids, points, seuils, règle d'imputation, tels que lus dans
  `score_config.json` (provisoires).

**Complétude et imputation**
- Phrase : part des trains complets (DQ-07 en PASS) et part des arrêts sans donnée qui sont
  une origine ou un terminus.
- « Où manquent les arrêts dans le trajet » : nombre de trains par position des manques.
- « Arrêts sans donnée selon leur rôle » : taux de manque des origines, arrêts
  intermédiaires et terminus.
- « Gares les plus souvent sans donnée » : nombre d'arrêts sans donnée par gare, et part
  des passages de la gare concernés.
- « Taux de valeurs exploitables par train (DQ-12) » : un train juste sous le seuil a des
  trous isolés ; un train très bas a des arrêts entiers manquants.
- « Règles non testables faute de données » : part des trains en NOT_TESTED par règle. Une
  part élevée signale une donnée qui bloque le contrôle (DQ-03, DQ-08, DQ-09, DQ-10).

**Capteurs (DQ-06)**
- Phrase : part des trains aux capteurs extérieurs valides et part des trains aux capteurs
  tous au vert.
- « DQ-06 à chaque maille » : statuts pour trains, arrêts et véhicules (WARNING = 1 capteur
  invalide, FAIL = plus de 1).
- « Capteurs extérieurs valides à chaque maille » : Oui / Non / Sans donnée.
- « DQ-06 par série de véhicule » : statut des passages de véhicule par série.
- « Trains aux capteurs extérieurs valides, par jour ».
- « Véhicules les plus souvent en défaut capteur » : nombre de passages en WARNING ou FAIL
  et part des passages du véhicule ; c'est la liste à transmettre à la maintenance.

**Trains**
- Tableau d'un train par ligne : identifiants, date, ligne, origine, destination, arrêts
  mesurés / attendus, capteurs extérieurs valides, statut des 14 règles, nombre de FAIL,
  score, couverture, verdict, décision d'imputation.
- Recherche libre (train, gare, statut) ; tri en cliquant sur un en-tête. Le nombre de
  lignes affichées est plafonné (indiqué au-dessus du tableau).

**Règles appliquées**
- Pour chaque règle : nom, granularité, calcul, choix validés et hypothèses (contenu de
  `output/dashboard/dq_rules.csv`), repris du référentiel « Règles DQ - Métier ».

---

## 8. Questions ouvertes à trancher par le métier

**Score et imputation (hors référentiel, provisoires)**
1. Poids métier des 14 règles (aujourd'hui égaux).
2. Seuils de verdict (80 / 60) et couverture minimale (50 %).
3. Part minimale d'arrêts mesurés pour imputer (50 %) et verdicts imputables ; méthode de
   calcul des valeurs imputées.
4. Les trains complets mais Mauvaise (1 124) doivent-ils rester « Rien à imputer » ?

**Hypothèses du code (5 à 8 validées le 2026-11-05 : le code reste inchangé)**
5. DQ-08 : tronçon intermédiaire = tous les arrêts sauf le premier et le dernier ?
6. DQ-08 et DQ-10 : un seul arrêt sans flux rend la règle NOT_TESTED ; faut-il plutôt
   calculer sur les arrêts mesurés ?
7. DQ-09 : à quoi rapporter les 2 % (capacité à l'origine aujourd'hui, ou montées) ? Que
   faire d'une capacité nulle à l'origine (NOT_TESTED aujourd'hui, 742 trains) ?
8. DQ-12 : liste des valeurs contrôlées à chaque maille.
9. DQ-06 : un capteur sans valeur doit-il compter invalide (au niveau véhicule quand l'autre
   capteur a une valeur, et au niveau train) ?

**Points laissés ouverts par le référentiel**
10. DQ-04 : traitement d'une occupation absente (« à confirmer selon le traitement métier » ;
    NOT_TESTED appliqué). _Capacité nulle avec occupation 0 : NOT_TESTED, tranché le 2026-11-11._
11. DQ-01 : le cas « ordre des arrêts inexploitable » doit-il être contrôlé, et comment ?
    _La reconstruction cumulée (validée le 2026-11-11) est-elle trop sévère (45 % de FAIL par arrêt) ? Variante ré-ancrée sur l'occupation mesurée : non validée._
12. DQ-02 : faut-il aussi comparer l'identité des véhicules (29 trains PASS avec des
    véhicules hors liste) ?
13. DQ-10 : point de départ du cumul pour les trajets partiels.
14. DQ-11 : la comparaison Train / Station étant impossible faute de montées Train, faut-il
    une autre grandeur (`TotalOccupancy` ?) ou un poids nul, puisque l'écart Station / EVN
    vaut toujours 0 ?

**Sens des données (à demander à l'exploitant)**
15. Sens de `isDegraded` (49,8 % des trains, 100 % des LOCOMOTIVE).
16. Sens de `stationPassed = faux` : arrêt non desservi ou passage non enregistré ?
17. Rôle des capteurs extérieur / intérieur ; capteur extérieur à 0 % sur une partie des
    séries 2450 / 2400 : capteur absent ou en panne ?
18. Les valeurs d'arrêt sont-elles calculées comme somme des véhicules ?
19. `occupancy.allClasses` inclut-il les vélos ? _L'occupation au terminus est mesurée avant
    les descentes : confirmé le 2026-11-11 (C30)._
20. Compositions « 6 attendus, 3 observés » : une rame entière muette ?
21. Les 82 trains sans ligne ni origine / terminus sont-ils des trajets partiels ?
22. Période exacte de l'extraction (dates présentes : 4 au 26 août, sans le 24).

**DQ-13 et DQ-14 (ajoutées le 2026-11-06)**
23. DQ-13 : confirmer la valeur de comptage (occupation), la définition d'une répétition
    (arrêts identiques consécutifs), les cas NOT_TESTED (séquence incomplète, moins de 5 arrêts)
    et le traitement des zéros répétés (C28).
24. DQ-14 : point Dosto du référentiel : un même fichier couvre-t-il les descentes au terminus
    d'une circulation et les montées à l'origine de la suivante (C27) ? _Un flux absent à un arrêt
    intermédiaire ne rend plus la règle NOT_TESTED (validé le 2026-11-11)._

**Modifications proposées le 2026-11-11, en attente de validation**
25. DQ-06 : ne contrôler que les capteurs extérieurs ? un capteur sans valeur → NOT_TESTED ?
26. DQ-08 : tronçon intermédiaire seulement quand les extrémités n'ont pas de flux (biais
    structurel signalé : la règle serait mécaniquement biaisée).
27. DQ-13 : suspicion de répétition seulement avec mouvement net des EVN.
28. DQ-02 (PO SIV sur l'origine de `EuropeanVehicleNumbersJson`, comparaison d'identités),
    DQ-07 et DQ-11 : sans réponse après l'atelier.

---

## 9. Écarts entre le référentiel et l'application

Comparaison de `src/dq_engine.py` avec [referentiel/regles_dq_metier.md](referentiel/regles_dq_metier.md).
Sont conformes au référentiel, sans écart : DQ-01 (plancher de 5 voyageurs et 2 %),
DQ-03 (seuil 2 %, NOT_TESTED), DQ-04 (seuils 200 / 250 %, synthèse Train ; la capacité
nulle avec occupation 0 est NOT_TESTED depuis le 2026-11-11, précision que le référentiel ne
fait pas), DQ-05, DQ-06 (compte de capteurs invalides, filtre « Capteurs
extérieurs valides »), DQ-07, DQ-08 (règle du ET, détail global et intermédiaire), DQ-10
(seuils et premier arrêt négatif), DQ-12 (formule et seuils).

| Règle | Point | Nature |
|---|---|---|
| DQ-01 | Reconstruction cumulée depuis l'origine (Σ montées − Σ descentes des arrêts 1..n) ; premier arrêt testé ; NOT_TESTED si un flux de 1..n manque (remplace la reconstruction locale du 2026-11-05) | Choix validé le 2026-11-11 |
| DQ-01 | « Ordre des arrêts inexploitable » non contrôlé : l'ordre de `StopsJson` est pris tel quel | Point ouvert |
| DQ-02 | Maximum attendu = `EuropeanVehicleNumbersJson` ; arrêt sans donnée NOT_TESTED alors que le référentiel ne prévoit pas NOT_TESTED | Choix validé |
| DQ-02 | Comparaison de nombres et non d'identités : 29 trains PASS avec des véhicules hors de la liste attendue, dont 28 sans aucun véhicule commun | Constat (conforme au texte) |
| DQ-03 | Terminus = `End` ; capacité nulle au terminus → NOT_TESTED (aucun cas) ; `End` non contrôlé comme dernier arrêt ; occupation mesurée avant les descentes (confirmé le 2026-11-11, C30) | Choix validé / précision |
| DQ-04 | Occupation absente → NOT_TESTED, testée avant la capacité (1 cas : capacité nulle et occupation absente donne NOT_TESTED) | Point ouvert du référentiel |
| DQ-04 | Capacité nulle ou absente avec occupation 0 → NOT_TESTED (le référentiel dit FAIL pour toute capacité nulle ou inconnue) ; FAIL si occupation > 0 | Écart validé le 2026-11-11 |
| DQ-05 | EVN hérite de son arrêt | Choix validé |
| DQ-06 | Capteur sans valeur compté invalide quand l'autre capteur a une valeur (629 passages de véhicule) ; au niveau train, capteur valide seulement s'il est à 100 % à chaque arrêt mesuré | Hypothèse à valider |
| DQ-06 | Conditions « données de comptage disponibles » (PASS) et « données encore exploitables » (WARNING) non testées | Point ouvert |
| DQ-07 | Rang maximal = nombre d'arrêts de `StopsJson` ; arrêt non desservi compté manquant | Choix validé |
| DQ-08 | Tronçon intermédiaire = arrêts hors premier et dernier | Choix validé |
| DQ-08 / DQ-10 | Un arrêt sans flux sur le trajet → NOT_TESTED (DQ-10 Station : jusqu'à l'arrêt n) | Choix validé |
| DQ-09 | Seuil de 2 % rapporté à la capacité à l'origine ; capacité nulle → NOT_TESTED (742 trains), cas non prévu par le référentiel | Choix validé |
| DQ-10 | Cumul démarré à 0 au premier arrêt listé, y compris pour les trajets partiels | Point ouvert |
| DQ-11 | Pas de comparaison « montées Train et somme Station » (pas de montées Train dans l'extraction) | Choix validé |
| DQ-11 | Montées et descentes ajoutées à la comparaison Station / Σ EVN ; pas de statut à la maille EVN | Écart |
| DQ-12 | Liste des valeurs contrôlées | Choix validé |
| DQ-12 | Au niveau Train, seuls les arrêts avec donnée sont contrôlés (le référentiel ne dit rien des arrêts muets) | Choix validé le 2026-11-11 |
| DQ-13 | Valeur = occupation ; répétitions = arrêts identiques consécutifs ; constance = même valeur à tous les arrêts (≥ 5) ; NOT_TESTED si séquence incomplète ou < 5 arrêts ; zéros répétés comptés | Hypothèse à valider |
| DQ-14 | Origine / terminus = `Start` / `End` ; total des flux = Σ montées + Σ descentes ; point Dosto non intégré, formule inchangée comme le référentiel le demande | Choix par défaut à valider (point Dosto) |
| DQ-14 | NOT_TESTED seulement si une extrémité ou son flux manque ; total des flux sur les arrêts qui ont leurs deux flux | Choix validé le 2026-11-11 |
| Score | Absent du référentiel ; poids égaux (provisoires, à revoir plus tard), seuils 80 / 60 et couverture minimale 50 % validés | Poids provisoires, seuils validés |
| Imputation | Absente du référentiel ; 50 % d'arrêts mesurés, verdict Bonne ou À surveiller | Choix validé |
