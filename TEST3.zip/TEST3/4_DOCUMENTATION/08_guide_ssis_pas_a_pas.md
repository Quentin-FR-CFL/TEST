# 08 – Guide pas à pas : packages SSIS STA et DWH

> **TEST3** : il n'y a plus que **2 packages** (`SIV_MasterPackage_OdsToSta`, `SIV_MasterPackage_StaToDwh`). Les 5 packages enfants (`SIV_Dq_Counting_*`, `SIV_Dwh_Counting_*`) sont remplacés par des tâches « Exécuter SQL » dans les masters ; les paragraphes 5 et 6 ci-dessous décrivent les enfants supprimés et valent comme description des tâches. Procédure à jour : guide du pack TEST3.


Objectif : ajouter à votre solution `SSIS_COMPTAGE` les packages des projets
**CFL_STA_COMPTAGE** et **CFL_DWH_COMPTAGE**, dans le même style que
**CFL_ODS_COMPTAGE** (que ce guide ne touche pas), et en suivant votre guide des bonnes
pratiques SSIS.

> **Limites à connaître avant de commencer**
> - Les fichiers `.dtsx` fournis dans [`ssis/`](../../ssis/) ont été **écrits sans Visual Studio ni SQL
>   Server** : seule leur validité XML a été vérifiée. Ils n'ont jamais été ouverts dans SSDT. Si l'un
>   d'eux refuse de s'ouvrir, reconstruisez-le à la main avec les tableaux des sections 5 et 6 (chaque
>   tâche y est décrite avec son SQL, ses paramètres et ses contraintes).
> - Les procédures d'audit de batch (`audit.usp_StartNewBatchStep`, `audit.usp_FinalizeBatchStep`)
>   sont **des suppositions** tirées de votre guide : leur code n'a pas été fourni. À comparer avec les
>   tâches « Initialiser batch Ods » et « Finaliser batch … » de votre master ODS (section 4).
> - Les scripts SQL (dossier [`sql/`](../../sql/)) n'ont jamais été exécutés non plus.

## 1. Ce que j'ai repris de votre ODS (d'après vos captures)

| Constat sur vos captures | Ce que j'en ai fait |
|---|---|
| Trois projets dans la solution : `CFL_ODS_COMPTAGE`, `CFL_STA_COMPTAGE`, `CFL_DWH_COMPTAGE`, avec les connexions projet `CM_API`, `CM_ODS`, `CM_STA` | Mêmes noms de projets, connexions `CM_STA` utilisée pour STA et DWH (en DEV, `DbNameSta` = `DbNameOds` = `CFL_GOV`) |
| Nommage `SIV_MasterPackage_SourceToOds`, `SIV_api_Counting` ; côté STA : `SIV_MasterPackage_OdsToSta`, `SIV_Split_Counting_Station_EVN` | `SIV_MasterPackage_OdsToSta`, `SIV_MasterPackage_StaToDwh` ; enfants `SIV_Dq_Counting_*` et `SIV_Dwh_Counting_*` |
| Master ODS : *Initialiser batch Ods* → conteneur *Traitements Ods* → *Finaliser batch Succeeded* / *Failed* (branche rouge « Failure ») | Même forme : *Initialiser batch Sta* → conteneur *Traitements Sta* → *Finaliser batch …* ; idem pour Dwh |
| Package enfant ODS avec un conteneur *Load API dates* et une tâche d'expression « Calculer la date de circulation », puis *04 - Controler la staging* et *05 - Publier J-10 a J-1* | Les masters STA et DWH calculent la **même fenêtre J-10 à J-1** (paramètre `NbJoursFenetre` = 10, à confirmer) dans un conteneur *Fenêtre de dates* |
| Paramètres de projet `DbNameOds`, `DbNameSta`, `DbServerOds`, `DbServerSta`, `ExecEnvironment`, `SourceName` = `SIV_APC`, `SplitProcedure` (« procédure existante, contrat dates conservé ») | Aucun nom de base ni de serveur écrit en dur dans les packages : tout passe par les connexions `CM_*` déjà paramétrées. Le split existant n'est **pas modifié** |
| Schéma `comptage_API` | Schéma commun des trois couches ; les objets des couches STA et DWH sont préfixés `DQ_` pour ne rien écraser |

## 2. Vue d'ensemble de ce que vous obtenez

```mermaid
flowchart LR
    O["SIV_MasterPackage_SourceToOds<br/>(ODS, existant, inchangé)"] --> S
    subgraph S["CFL_STA_COMPTAGE : SIV_MasterPackage_OdsToSta"]
        S0["Initialiser batch Sta"] --> S1["Fenêtre de dates J-10 à J-1"]
        S1 --> S2["Ouvrir l'exécution DQ"]
        S2 --> S3["Traitements Sta"]
        S3 -->|succès| S4["Clore exécution DQ Succeeded<br/>Finaliser batch Succeeded"]
        S3 -->|échec| S5["Clore exécution DQ Failed<br/>Finaliser batch Failed<br/>Propager l'échec"]
    end
    S --> D
    subgraph D["CFL_DWH_COMPTAGE : SIV_MasterPackage_StaToDwh"]
        D0["Initialiser batch Dwh"] --> D1["Fenêtre de dates"]
        D1 --> D2["Traitements Dwh"]
        D2 -->|succès| D3["Finaliser batch Succeeded"]
        D2 -->|échec| D4["Finaliser batch Failed<br/>Propager l'échec"]
    end
```

Contenu des conteneurs :

| Master | Conteneur | Enfants appelés dans l'ordre |
|---|---|---|
| `SIV_MasterPackage_OdsToSta` | *Traitements Sta* | `SIV_Split_Counting_Station_EVN` (**existant**) → `SIV_Dq_Counting_Parsing` → `SIV_Dq_Counting_Regles` → `SIV_Dq_Counting_Score` |
| `SIV_MasterPackage_StaToDwh` | *Traitements Dwh* | `SIV_Dwh_Counting_Modele` → `SIV_Dwh_Counting_Controle` |

Qui fait quoi :

- **STA = les transformations et les règles** : éclatement du JSON en trains, arrêts, véhicules ; 14 règles DQ ; score, verdict, imputation. Les procédures sont dans le schéma `audit` (catalogue, journal, orchestrateur, règles : noms de votre V1) et `comptage_API` (objets `DQ_*`).
- **DWH = la mise en forme pour Power BI** : dimensions, faits en columnstore, agrégats et vues `comptage_API.vw_DQ_*`, puis un contrôle de cohérence (« Sanity Check DWH »).

## 3. Étape A : installer le SQL dans CFL_GOV (DEV)

Avant les packages, les procédures appelées doivent exister. Dans SSMS, base `CFL_GOV`
(mode SQLCMD, depuis le dossier `sql/`) : ouvrir [`sql/install.sql`](../../sql/install.sql) et l'exécuter,
ou lancer les fichiers dans l'ordre de ce script. Il crée :

| Script | Objets |
|---|---|
| `00_schemas.sql` | Schémas `audit` et `comptage_API` (s'il n'existe pas), rôles |
| `01` à `05` | `comptage_API.vw_DQ_SourceTrain` (lit `comptage_API.Counting`), `DQ_StgTrain`, `DQ_Train`, `DQ_Arret`, `DQ_ArretEVN`, `DQ_EVNAttendu`, fonctions `fn_DQ_*`, procédures `usp_DQ_ChargerStaging`, `usp_DQ_ControlerStaging`, `usp_DQ_ParserStaging` |
| `03_audit_catalogue_logs.sql` | `audit.ReglesDQ`, `LogsDQ`, `ScoresDQ`, `ExecutionsDQ`, etc. |
| `07`, `regles/DQ01…DQ14`, `08` | Orchestrateur, 14 règles, score |
| `09`, `10` | Tables `comptage_API.DQ_Dim*` et `DQ_Fait*`, procédures `usp_DQ_RafraichirModele` et `usp_DQ_ControlerModele`, vues `vw_DQ_*` |
| `12_seed_catalogue.sql` | Catalogue des 14 règles et paramètres du score |

Vérifications :

```sql
USE CFL_GOV;
SELECT TOP (5) * FROM comptage_API.Counting;                      -- la source ODS
SELECT TOP (5) * FROM comptage_API.vw_DQ_SourceTrain;             -- sa lecture typée (échoue si les colonnes diffèrent)
SELECT RuleCode, IsActive FROM audit.ReglesDQ ORDER BY SequenceOrder;   -- 14 règles
SELECT name FROM sys.procedures WHERE name LIKE N'usp[_]DQ[_]%' ORDER BY name;
```

Si `vw_DQ_SourceTrain` échoue (colonne inconnue), adaptez la vue dans `01_source_et_staging.sql`
(hypothèse : mêmes colonnes que le CSV d'origine).

**Test SQL seul avant SSIS** (recommandé), sur vos dates réelles :

```sql
DECLARE @e bigint;
EXEC audit.usp_DQ_Pipeline_SIV_APC @DateDebut = '2026-08-04', @DateFin = '2026-08-26', @ExecutionId = @e OUTPUT;
SELECT * FROM audit.ExecutionsDQ WHERE ExecutionId = @e;      -- Statut = Succes
```

## 4. Étape B : préparer le projet CFL_STA_COMPTAGE

1. **Connexion** : `CM_STA.conmgr` existe déjà dans le projet (visible sur votre capture) et doit
   pointer vers la base qui contient les objets de l'étape A (`CFL_GOV` en DEV, via `DbNameSta`).
2. **Récupérer le DTSID de la connexion** : ouvrez `CM_STA.conmgr` avec un éditeur de texte
   (Bloc-notes) ; repérez `DTS:DTSID="{…}"` et copiez la valeur avec ses accolades. Faites de même dans
   `CFL_DWH_COMPTAGE` (son `CM_STA.conmgr` a son propre identifiant).
3. **Générer les packages avec vos identifiants** (Python 3, depuis le dossier `ssis/` du dépôt) :
   ```
   python generer_packages.py --sta-cm-sta "{DTSID de CM_STA du projet STA}" --dwh-cm-sta "{DTSID de CM_STA du projet DWH}"
   ```
   Sans Python : ouvrez chaque `.dtsx` fourni dans un éditeur de texte et remplacez
   `{00000000-0000-0000-0000-000000000000}` par le DTSID du `CM_STA` du projet concerné
   (rechercher / remplacer dans le fichier).
4. **Comparer avec votre master ODS** (point de vigilance n° 1) : ouvrez `SIV_MasterPackage_SourceToOds`
   et regardez le SQL de *Initialiser batch Ods* et de *Finaliser batch Succeeded / Failed*
   (double-clic, propriété `SQLStatement`, et onglet *Parameter Mapping*).
   Les packages fournis utilisent :
   ```sql
   EXEC audit.usp_StartNewBatchStep @SourceName = ?, @StepName = ?
   EXEC audit.usp_FinalizeBatchStep @SourceName = ?, @StepName = ?, @Status = 0   -- succès ; 1 pour l'échec
   ```
   Si votre ODS utilise d'autres noms, d'autres paramètres, ou si `StepName` vaut autre chose que
   `STA` / `DWH`, **recopiez le SQL de l'ODS dans les trois tâches des masters STA et DWH** en ne changeant
   que `StepName`. Le guide des bonnes pratiques précise aussi que les codes `0` et `1` de `@Status` sont à
   vérifier dans les procédures.
5. **Importer les quatre packages** : dans l'Explorateur de solutions, clic droit sur le dossier
   *SSIS Packages* du projet `CFL_STA_COMPTAGE` > *Add > Existing Package*, ou copiez les fichiers dans
   le dossier du projet puis *Add > Existing Item*. Remplacez le master existant
   `SIV_MasterPackage_OdsToSta.dtsx` : faites d'abord une copie de sauvegarde de l'ancien.
   **Ne touchez pas à `SIV_Split_Counting_Station_EVN.dtsx`**.
6. Dans chaque package, menu *Format > Auto Layout > Diagram* pour ranger les tâches (les fichiers générés
   ne contiennent pas de mise en page).
7. Ouvrez un package, onglet *Control Flow* : la fenêtre *Error List* doit afficher 0 erreur. Une erreur de
   connexion (`CM_STA` introuvable) vient d'un DTSID mal copié (étape 2).

## 5. Les packages de CFL_STA_COMPTAGE, tâche par tâche

Toutes les tâches SQL utilisent la connexion `CM_STA`, mode de résultat *None* sauf mention contraire, et
une valeur `?` correspond au paramètre n° 0, 1, 2… de l'onglet *Parameter Mapping* (type de donnée
indiqué ; direction *Input*).

### 5.1 `SIV_MasterPackage_OdsToSta.dtsx` (master)

**Paramètres de package** : `SourceName` (String, `SIV_APC`), `NbJoursFenetre` (Int32, `10`).
**Variables** : `StepName` (String, `STA`), `PreviousStepsStatus` (Int32, `0`), `DateDebut` et `DateFin`
(String, `1900-01-01`), `ExecutionId` (Int64, `0`).

| # | Tâche | Type | Contenu |
|---|---|---|---|
| 1 | Initialiser batch Sta | Execute SQL | `EXEC audit.usp_StartNewBatchStep @SourceName = ?, @StepName = ?` ; paramètres : `$Package::SourceName` (String), `User::StepName` (String) |
| 2 | Fenêtre de dates (conteneur) | Sequence | Contient deux tâches d'expression, dans cet ordre : |
| 2a | Calculer la date de fin (J-1) | Expression | `@[User::DateFin] = (DT_WSTR, 10)(DT_DBDATE)DATEADD("day", -1, GETDATE())` |
| 2b | Calculer la date de début (J-n) | Expression | `@[User::DateDebut] = (DT_WSTR, 10)(DT_DBDATE)DATEADD("day", -@[$Package::NbJoursFenetre], GETDATE())` |
| 3 | Ouvrir l'exécution DQ | Execute SQL, résultat *Single row* | `SET NOCOUNT ON; DECLARE @e bigint = NULL; EXEC audit.usp_DQ_OuvrirExecution @SourceName = ?, @DateDebut = ?, @DateFin = ?, @ExecutionId = @e OUTPUT, @SsisExecutionId = ?; SELECT ExecutionId = @e;` ; paramètres : `$Package::SourceName`, `User::DateDebut`, `User::DateFin` (String), `System::ServerExecutionID` (Int64) ; *Result Set* : `ExecutionId` → `User::ExecutionId` |
| 4 | Traitements Sta (conteneur) | Sequence | 4 tâches *Execute Package*, détaillées ci-dessous |
| 5a | Clore exécution DQ Succeeded | Execute SQL | `EXEC audit.usp_DQ_CloreExecution @ExecutionId = ?, @Statut = 'Succes'` ; paramètre : `User::ExecutionId` (Int64) |
| 5b | Clore exécution DQ Failed | Execute SQL | `EXEC audit.usp_DQ_CloreExecution @ExecutionId = ?, @Statut = 'Echec', @Message = N'Échec du master package SSIS : voir audit.ExecutionsRegleDQ et le journal SSISDB'` ; même paramètre |
| 6a | Finaliser batch Succeeded | Execute SQL | `EXEC audit.usp_FinalizeBatchStep @SourceName = ?, @StepName = ?, @Status = 0` |
| 6b | Finaliser batch Failed | Execute SQL | idem avec `@Status = 1` |
| 7 | Propager l'échec technique | Execute SQL | `THROW 50099, N'Échec du master package : voir le journal SSISDB et audit.', 1;` |

Contenu du conteneur *Traitements Sta* (chaque tâche est une *Execute Package Task*, référence de projet, enchaînées en *Success*) :

| Ordre | Tâche | Package appelé | Affectation des paramètres |
|---|---|---|---|
| 1 | Exécuter SIV_Split_Counting_Station_EVN | `SIV_Split_Counting_Station_EVN.dtsx` (existant) | **aucune** : si ce package attend des paramètres, reprenez ceux de votre master actuel |
| 2 | Exécuter SIV_Dq_Counting_Parsing | `SIV_Dq_Counting_Parsing.dtsx` | `SourceName` ← `$Package::SourceName` ; `ExecutionId` ← `User::ExecutionId` ; `DateDebut` ← `User::DateDebut` ; `DateFin` ← `User::DateFin` |
| 3 | Exécuter SIV_Dq_Counting_Regles | `SIV_Dq_Counting_Regles.dtsx` | mêmes quatre affectations |
| 4 | Exécuter SIV_Dq_Counting_Score | `SIV_Dq_Counting_Score.dtsx` | mêmes quatre affectations |

Contraintes de précédence du master :

| De | Vers | Type |
|---|---|---|
| Initialiser batch Sta | Fenêtre de dates | Success **et** expression `@[User::PreviousStepsStatus]==0` |
| Fenêtre de dates | Ouvrir l'exécution DQ | Success |
| Ouvrir l'exécution DQ | Traitements Sta | Success |
| Traitements Sta | Clore exécution DQ Succeeded | Success |
| Clore exécution DQ Succeeded | Finaliser batch Succeeded | Success |
| Traitements Sta | Clore exécution DQ Failed | **Failure** |
| Clore exécution DQ Failed | Finaliser batch Failed | Completion |
| Fenêtre de dates, Ouvrir l'exécution DQ | Finaliser batch Failed | Failure (les trois contraintes vers cette tâche en **OU**, propriété *Multiple constraints : Logical OR*) |
| Finaliser batch Failed | Propager l'échec technique | Completion |

Pourquoi *Propager l'échec technique* : une tâche en échec dont l'erreur est traitée par une branche
*Failure* laisse le package réussir. Votre guide demande de **conserver l'échec technique** même si la
journalisation d'erreur réussit : cette dernière tâche relance une erreur pour que le package, donc le job,
échoue vraiment.

`PreviousStepsStatus` vaut `0` en dur : la contrainte est en place mais n'a pas d'effet. Pour contrôler le
résultat de l'étape ODS, remplacez cette valeur par le résultat de la procédure de vérification que vos
autres masters STA/DWH utilisent (son nom n'est pas dans les documents reçus : **à confirmer**).

### 5.2 `SIV_Dq_Counting_Parsing.dtsx`

**Paramètres** : `SourceName` (String), `ExecutionId` (Int64), `DateDebut` et `DateFin` (String). Aucune variable.

| Ordre | Tâche | SQL | Paramètres |
|---|---|---|---|
| 1 | Charger staging DQ | `EXEC comptage_API.usp_DQ_ChargerStaging @DateDebut = ?, @DateFin = ?` | `$Package::DateDebut`, `$Package::DateFin` (String) |
| 2 | Contrôler staging DQ | `EXEC comptage_API.usp_DQ_ControlerStaging @ExecutionId = ?` | `$Package::ExecutionId` (Int64) |
| 3 | Parser JSON DQ | `EXEC comptage_API.usp_DQ_ParserStaging @DateDebut = ?, @DateFin = ?, @ExecutionId = ?` | dates (String) puis `$Package::ExecutionId` (Int64) |

Enchaînement en *Success*. L'étape 1 vide et recharge `comptage_API.DQ_StgTrain` pour la fenêtre (c'est
votre schéma « Vider STG … » de l'ODS, côté DQ). L'étape 2 est **bloquante** : staging vide ou doublon
`(TrainNumber, date)` = erreur, donc échec du package. Elle journalise aussi des avertissements (JSON invalide,
clé absente) dans `audit.ControlesTechniquesDQ`, sans bloquer.

### 5.3 `SIV_Dq_Counting_Regles.dtsx`

**Paramètres** : `SourceName`, `ExecutionId`, `DateDebut`, `DateFin`.

| Tâche | SQL | Paramètres |
|---|---|---|
| Exécuter les règles DQ | `EXEC audit.usp_DQ_ExecuterRegles @SourceName = ?, @DateDebut = ?, @DateFin = ?, @ExecutionId = ?, @Cloturer = 0` | `$Package::SourceName` (String), dates (String), `$Package::ExecutionId` (Int64) |

C'est **la commande unique de votre V1** : elle lit le catalogue `audit.ReglesDQ`, lance chaque règle
active (`audit.usp_DQ_BR_*`) et écrit dans `audit.LogsDQ`. Ajouter une règle ne demande aucun changement de
package. `@Cloturer = 0` : c'est le master qui clôt l'exécution. Une règle qui échoue techniquement
n'arrête pas les autres ; à la fin, l'orchestrateur relance une erreur (la tâche échoue). Une non-conformité
métier (FAIL) ne fait **jamais** échouer la tâche.

### 5.4 `SIV_Dq_Counting_Score.dtsx`

**Paramètres** : `SourceName`, `ExecutionId`, `DateDebut`, `DateFin`.

| Tâche | SQL | Paramètres |
|---|---|---|
| Calculer le score DQ | `EXEC audit.usp_DQ_CalculerScore @SourceName = ?, @ExecutionId = ?, @DateDebut = ?, @DateFin = ?` | `$Package::SourceName` (String), `$Package::ExecutionId` (Int64), dates (String) |

## 6. Étape C : le projet CFL_DWH_COMPTAGE

Même méthode que l'étape B (DTSID de `CM_STA` du projet DWH, import des trois packages, *Auto Layout*).
La connexion utilisée est `CM_STA` (le projet DWH ne contient que `CM_ODS` et `CM_STA` sur votre capture).
Quand les tables du DWH seront dans une autre base, ajoutez une connexion `CM_DWH` dans ce projet
(paramètres `DbServerDwh` et `DbNameDwh`, sur le modèle de `DbServerSta` / `DbNameSta`) et changez la
connexion des tâches SQL : voir la section 9.

### 6.1 `SIV_MasterPackage_StaToDwh.dtsx` (master)

Mêmes paramètres et variables que le master STA, avec `StepName` = `DWH` ; pas de variable `ExecutionId`
utilisée (elle est présente sans effet).

| # | Tâche | Contenu |
|---|---|---|
| 1 | Initialiser batch Dwh | `EXEC audit.usp_StartNewBatchStep @SourceName = ?, @StepName = ?` |
| 2 | Fenêtre de dates (conteneur) | Mêmes deux tâches d'expression que le master STA |
| 3 | Traitements Dwh (conteneur) | *Exécuter SIV_Dwh_Counting_Modele* → *Exécuter SIV_Dwh_Counting_Controle* ; affectations : `SourceName` ← `$Package::SourceName`, `DateDebut` ← `User::DateDebut`, `DateFin` ← `User::DateFin` |
| 4a | Finaliser batch Succeeded | `EXEC audit.usp_FinalizeBatchStep @SourceName = ?, @StepName = ?, @Status = 0` |
| 4b | Finaliser batch Failed | idem avec `@Status = 1` |
| 5 | Propager l'échec technique | `THROW 50099, …` |

Contraintes : Init → Fenêtre (Success et `PreviousStepsStatus==0`) → Traitements Dwh ; Traitements Dwh →
*Finaliser batch Succeeded* (Success) et → *Finaliser batch Failed* (Failure) ; Fenêtre → *Finaliser batch Failed*
(Failure, en OU) ; *Finaliser batch Failed* → *Propager l'échec technique* (Completion).

### 6.2 `SIV_Dwh_Counting_Modele.dtsx`

**Paramètres** : `SourceName`, `DateDebut`, `DateFin` (String).

| Tâche | SQL | Paramètres |
|---|---|---|
| Rafraîchir le modèle DWH | `EXEC comptage_API.usp_DQ_RafraichirModele @SourceName = ?, @DateDebut = ?, @DateFin = ?` | `$Package::SourceName`, dates (String) |

La procédure reconstruit, **dans une seule transaction**, les dimensions (par `MERGE`), les faits et
l'agrégat de la fenêtre à partir des résultats courants (`IsCurrent = 1`). Pendant ce temps, Power BI voit
l'ancien état ou le nouveau, jamais un état mélangé (isolation par snapshot conseillée sur la base).

### 6.3 `SIV_Dwh_Counting_Controle.dtsx` (Sanity Check DWH)

| Tâche | SQL | Paramètres |
|---|---|---|
| Contrôler le modèle DWH | `EXEC comptage_API.usp_DQ_ControlerModele @SourceName = ?, @DateDebut = ?, @DateFin = ?` | idem |

Compare le nombre de trains du modèle à celui du parsing, et le nombre de résultats du modèle à celui du
journal courant, sur la fenêtre. Un écart lève l'erreur 50060 ou 50061 : la tâche, le master et le job échouent.

## 7. Étape D : tester dans Visual Studio

1. Vérifiez que `ExecEnvironment` = `DEV` et que `DbNameSta` / `DbServerSta` pointent vers votre base DEV.
2. **Lancer d'abord les enfants un par un** (clic droit sur le package > *Execute Package*), en saisissant
   les paramètres : par exemple `SIV_Dq_Counting_Parsing` ne fonctionne qu'avec un `ExecutionId` existant ;
   le plus simple est de lancer directement le master.
3. **Lancer le master STA** : `SIV_MasterPackage_OdsToSta`, bouton *Start* (le split existant tourne en premier).
4. Contrôles côté SQL :
   ```sql
   SELECT TOP (3) ExecutionId, Statut, DateDebut, DateFin, NbReglesLancees, NbReglesEnErreur, NbTrains
   FROM audit.ExecutionsDQ ORDER BY ExecutionId DESC;                     -- Statut = Succes
   SELECT RegleDQID, Statut, DureeMs, NbResultats, ErrorMessage
   FROM audit.ExecutionsRegleDQ WHERE ExecutionId = (SELECT MAX(ExecutionId) FROM audit.ExecutionsDQ);   -- 14 lignes
   SELECT RuleCode, [Status], COUNT_BIG(*) AS N FROM audit.vw_DQ_LogsEnrichis
   WHERE ExecutionId = (SELECT MAX(ExecutionId) FROM audit.ExecutionsDQ) AND GrainLevel = 1
   GROUP BY RuleCode, [Status] ORDER BY RuleCode, [Status];
   ```
5. **Recette** : si la source contient l'extraction d'août 2026 sur toute la période (donc avec une fenêtre qui la
   couvre), exécutez [`sql/tests/recette_chiffres_cles.sql`](../../sql/tests/recette_chiffres_cles.sql). Avec la fenêtre
   J-10 à J-1, la recette ne s'applique pas (elle vaut pour la période complète d'août) : pour la jouer, lancez
   la procédure `audit.usp_DQ_Pipeline_SIV_APC` en SQL sur les dates d'août (section 3).
6. **Lancer le master DWH** : `SIV_MasterPackage_StaToDwh`, puis :
   ```sql
   SELECT COUNT(*) FROM comptage_API.DQ_DimTrain;
   SELECT TOP (10) TrainNumber, Score, Verdict, Imputation FROM comptage_API.DQ_DimTrain;
   ```
7. **Tests d'erreur et de reprise** (votre checklist les exige) :
   - **Relance** : relancer le master STA puis DWH sur la même fenêtre : mêmes comptes courants, l'ancienne
     exécution reste dans `audit.LogsDQ` avec `IsCurrent = 0`, aucun doublon.
   - **Échec technique** : renommez temporairement `audit.usp_DQ_CalculerScore` (ou utilisez un `SourceName`
     inexistant) : le master doit finir **en échec**, l'exécution DQ passe en `Echec`, le batch est finalisé en échec.
   - **Échec métier** : un train en FAIL ne doit **pas** faire échouer le package.
   - **Absence de données** : fenêtre sans train : le contrôle du staging (bloquant) doit le signaler.

## 8. Étape E : enchaîner les trois masters

Les trois masters s'exécutent dans cet ordre : `SIV_MasterPackage_SourceToOds` (inchangé) → `SIV_MasterPackage_OdsToSta`
→ `SIV_MasterPackage_StaToDwh`. Deux façons, à choisir selon vos habitudes (exemple de votre schéma :
« Job: BusAll - Load data in DWH ») :

| Option | Principe |
|---|---|
| **Un job, trois étapes** (recommandé, proche de votre exemple) | Job SQL Server Agent avec trois étapes « SSIS Package » : ODS, STA, DWH, chacune « en cas d'échec : quitter le job en échec » |
| Un master général | Un package qui appelle les trois masters ; à créer seulement si vous avez déjà ce modèle ailleurs |

Les packages sont déployés avec les projets (`Deploy` vers le catalogue SSISDB), comme pour l'ODS.

## 9. Étape F : passage en QUAL

1. Geler la version : packages et scripts SQL (un tag ou une branche).
2. Déployer le **SQL** dans la base de QUAL (mêmes scripts, rejouables) : `00`, `01` à `05`, `03`, `07`, `regles/`, `08`,
   `09`, `10`, `12`. La recette chiffrée n'est valable que si QUAL contient l'extraction d'août 2026.
3. Déployer les **projets SSIS** vers le SSISDB de QUAL (Deploy).
4. Dans l'environnement SSISDB de QUAL, renseigner les paramètres de projet : `DbServerSta`, `DbNameSta`
   (et `DbServerOds`, `DbNameOds` existants), `ExecEnvironment`. **Aucun package ne contient de nom de base
   en dur.**
5. Si en QUAL les couches sont dans **des bases différentes** (`DbNameOds` ≠ `DbNameSta`), les procédures de
   STA ne voient plus `comptage_API.Counting` ni les tables du DWH : il faut des synonymes entre bases
   (un synonyme `comptage_API.Counting` dans la base STA vers la base ODS, et symétriquement pour le catalogue
   `audit.*`). Ce cas n'est **pas couvert par les scripts** : à décider avec l'équipe DWH (voir
   [07](07_choix_a_trancher.md)).
6. Créer le job SQL Server Agent (section 8), exécuter une première fois sur une fenêtre réelle, puis refaire
   les contrôles de la section 7.
7. Planifier la maintenance hebdomadaire : `audit.usp_DQ_Purger @SourceName = N'SIV_APC'` et `audit.usp_DQ_Maintenance`.

Votre circuit de livraison (outil, tickets, validations) n'est pas décrit dans les documents reçus : **à confirmer**.

## 10. Conformité à votre guide des bonnes pratiques

| Point de la checklist | État |
|---|---|
| Modèle maître / enfant | Oui : un master par couche, enfants à responsabilité limitée |
| Couches séparées | Oui : projets ODS, STA, DWH |
| Noms explicites et cohérents | Oui : verbe + objet pour chaque tâche ; fichier, nom interne et objet alignés |
| Serveurs, chemins, périmètres configurables | Oui : paramètres de projet existants ; fenêtre = `NbJoursFenetre` |
| Aucun secret en clair | Oui : aucun secret dans les packages ; les secrets de l'API restent dans le projet ODS |
| Dépendances explicites, finalisations succès et échec distinctes | Oui |
| Échec technique non masqué | Oui : *Propager l'échec technique* |
| Mode de chargement et reprise documentés | Oui : fenêtre glissante recalculée, relance sans doublon (`IsCurrent`) |
| Comptages sur périmètres comparables | **Partiel** : contrôle du modèle DWH oui ; les procédures `audit.usp_InitializeTableCount` / `usp_HistorizeTableCounts` ne sont **pas** appelées (leur contrat n'est pas connu) |
| Rejets et anomalies traçables | Oui : `audit.ControlesTechniquesDQ`, `audit.LogsDQ` |
| Contrôles métier distincts des contrôles techniques | Oui : le FAIL métier n'échoue pas le package, le contrôle technique le fait |
| Procédures SQL et dépendances disponibles | Oui : dossier `sql/` complet |
| Tests d'erreur et de reprise réalisés | **À faire** (section 7) |
| Version cible compatible | **À confirmer** (SQL Server 2019 ou plus supposé, projets SSIS 2022 ou 2019) |

## 11. Points à confirmer

| # | Point | Où |
|---|---|---|
| 1 | Procédures et paramètres de `audit.usp_StartNewBatchStep` / `usp_FinalizeBatchStep` (codes `@Status`), valeur de `StepName` | Section 4, étape 4 |
| 2 | Paramètres du split existant `SIV_Split_Counting_Station_EVN` et ce qu'il produit : ce split ne sert pas aux règles DQ (elles lisent `comptage_API.Counting` et éclatent le JSON elles-mêmes) ; réutiliser ses tables à la place du parsing DQ suppose d'en connaître le schéma | 5.1 |
| 3 | Fenêtre J-10 à J-1 identique à la publication ODS | 5.1 |
| 4 | Contrôle des étapes précédentes (`PreviousStepsStatus`) | 5.1 |
| 5 | Version de SQL Server, version des projets SSIS | 10 |
| 6 | Colonnes réelles de `comptage_API.Counting` | 3 |
| 7 | Séparation des couches en bases distinctes en QUAL | 9 |
| 8 | Reprise des comptages d'audit (`TableCounts`) | 10 |

## 12. En cas d'erreur

| Symptôme | Cause probable | Remède |
|---|---|---|
| Un `.dtsx` ne s'ouvre pas ou affiche une erreur de chargement | Fichier généré sans Visual Studio | Le reconstruire à la main avec les tableaux des sections 5 et 6 ; signaler l'erreur exacte pour corriger le générateur |
| `The connection manager … is not found` | DTSID de `CM_STA` mal copié | Section 4, étapes 2 et 3 |
| `Could not find stored procedure 'audit.usp_StartNewBatchStep'` | Nom ou schéma différent dans votre base | Section 4, étape 4 |
| `Invalid object name 'comptage_API.…'` ou `Could not find stored procedure` | Scripts SQL non installés dans la base de `CM_STA` | Section 3 |
| Le package échoue au contrôle du staging | Staging vide ou doublon `(TrainNumber, date)` | `SELECT * FROM audit.ControlesTechniquesDQ ORDER BY ControleId DESC` |
| Erreur 50020 en fin d'étape règles | Au moins une règle a échoué techniquement | `audit.ExecutionsRegleDQ` (colonne `ErrorMessage`) |
| Erreur 50060 / 50061 au contrôle DWH | Le modèle ne correspond pas au parsing / au journal | Relancer `SIV_Dwh_Counting_Modele` puis le contrôle ; si l'écart persiste, comparer les comptes |
