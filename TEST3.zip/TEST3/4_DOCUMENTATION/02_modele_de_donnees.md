# 02 – Modèle de données

> **TEST3** : les vues Power BI (`vw_DQ_Dim*`, `vw_DQ_Fait*`, `…Recent`, `vw_DQ_ParametresScore`, `vw_DQ_AggStatutRegle`) et la table `DQ_AggStatutRegle` sont supprimées ; Power BI lit les tables `DQ_*`. Restent 3 vues (`vw_DQ_SourceTrain`, `vw_DQ_TrainMotif`, `audit.vw_DQ_LogsEnrichis`). Les passages ci-dessous qui les citent sont antérieurs : voir [09_lineage_et_pages.md](09_lineage_et_pages.md).


Les DDL complets sont dans [`sql/`](../../sql/) ; ce document en donne le dictionnaire et
les raisons de conception. `[EXT]` marque ce qui s'ajoute à la structure V1.

## 1. Source et staging (schéma `comptage_API`, préfixe `DQ_`)

| Objet | Rôle |
|---|---|
| `comptage_API.Counting` | Table source « comptage API », alimentée par le package ODS `SIV_api_Counting` (non modifiée). |
| `comptage_API.vw_DQ_SourceTrain` | Vue typée de la source : `NULLIF(…, 'NULL')`, `TRY_CONVERT` sur les nombres et dates. Une valeur illisible devient `NULL`, jamais une erreur de chargement. |
| `comptage_API.DQ_StgTrain` | Copie de la fenêtre traitée (une ligne par train), colonnes JSON conservées en `nvarchar(max)`. Vidée et rechargée à chaque exécution. |

## 2. Parsing (schéma `comptage_API`, préfixe `DQ_`)

Le JSON (`StopsJson`, `EuropeanVehicleNumbersJson`) est éclaté **une seule fois** par
`comptage_API.usp_DQ_ParserStaging`. Chaque valeur numérique garde deux informations : la valeur et un
**état de lecture** (`St`) : `0` lue, `1` absente, `2` illisible (fonction `comptage_API.fn_DQ_Val`).
Cela permet de distinguer « valeur absente » de « zéro » (un vrai zéro est exploitable).

| Table | Clé | Contenu |
|---|---|---|
| `comptage_API.DQ_Train` | `CountingId` | Un train : identité (`TrainNumber`, date, variante, ligne, type, série, gares de départ et d'arrivée), totaux (`TotalCapacity`, `TotalOccupancy`) et leurs états, `NbStops`, `NbStopsObs`, `NbEvnExpected`. Unicité `(CirculationDate, TrainNumber)`. |
| `comptage_API.DQ_Arret` | `(CountingId, Rang)` | Un arrêt listé dans `StopsJson` : gare, type (Start / Stop / End), occupation, montées, descentes, capacité (avec états), `HasData`, `NbEvnObs`, `Heure`, `CumulFlux`. |
| `comptage_API.DQ_ArretEVN` | `(CountingId, Rang, VehIdx)` | Un véhicule à un arrêt : EVN, série, occupation, capacité capteur, montées et descentes (1re + 2e classe), pourcentages et **états des capteurs** extérieur et intérieur (0 sans donnée, 1 valide, 2 invalide). |
| `comptage_API.DQ_EVNAttendu` | `(CountingId, EVN)` | EVN de la composition attendue (`EuropeanVehicleNumbersJson`), pour DQ-02 et DQ-06 (véhicule attendu mais jamais observé). |
| `comptage_API.vw_DQ_TrainMotif` | — | Motif des arrêts sans donnée par train : aucun, début, fin, trou, tout (et combinaisons). Alimente DQ-07, le score et l'imputation. |

Colonnes calculées au parsing pour éviter de les recalculer dans chaque règle :

- `Arret.CumulFlux` : somme cumulée (fonction de fenêtre) de `montées - descentes` de
  l'arrêt 1 à l'arrêt n ; `NULL` si un flux manque entre 1 et n (DQ-01 et DQ-10) ;
- `Arret.HasData` : occupation lue ;
- `Train.NbStops`, `NbStopsObs`, `NbEvnExpected`.

## 3. Contrôle (`audit`)

| Table | Rôle |
|---|---|
| `ReglesDQ` | Catalogue : une ligne par règle et par source. Code stable `DQ-nn`, procédure, ordre, seuils (`ThresholdLow / Medium / High`, unité), activation, version. `[EXT]` : `DetailGrainsJson`, `ParamsJson` (variante, paramètres hors seuils), `ScoreWeight`, `StatutValidation` (VALIDEE, A_TRANCHER, ATTEND_PO_SIV, PARTIELLE), `ChoixValides`. |
| `ReglesDQ_Historique` | Historique des modifications du catalogue (trigger), pour la gouvernance et DataGalaxy. |
| `ParametresDQ` | Paramètres du score et de l'exploitation : points par statut, traitement de NOT_TESTED, seuils de verdict, couverture minimale, règle d'imputation, fenêtre par défaut, rétention. Valeurs provisoires. |
| `ExecutionsDQ` | Une ligne par lancement : `ExecutionId`, fenêtre de dates, statut (EnCours, Succes, SuccesPartiel, Echec), corrélation SSIS facultative, nombre de règles lancées et en erreur. |
| `ExecutionsRegleDQ` | Une ligne par règle et par exécution : durée, nombre de résultats, erreur technique. |
| `ControlesTechniquesDQ` | Résultat des contrôles du staging (BLOQUANT, AVERTISSEMENT, INFO). |
| `LogsDQ` | **Journal central** : une ligne = le résultat d'une règle sur un objet pour une exécution. Colonnes V1 : `ExecutionId`, `RunId`, `RegleDQID`, `Status`, `FailureReason`, `ObservedValue` (JSON), `ExpectedValue`, `AbsoluteGap`, `RelativeGap`, `GrainValuesJson`, `ErrorDescription`. `[EXT]` : `GrainLevel`, `SourceKey`, `WindowDate`, `IsCurrent`. |
| `ScoresDQ` | Score, couverture, verdict et imputation par train (niveau 1) et par arrêt (niveau 2). |

### Identifiant d'objet et grain

`RunId` est l'identifiant métier lisible, construit par `audit.fn_BuildRunId` à partir des
composants de `GrainDefinitionJson` :

| Maille | Composants | Exemple |
|---|---|---|
| Train | `TrainNumber`, `CirculationDate` | `IC 1234|2026-08-04` (forme exacte à confirmer) |
| Arrêt | + `StopRank` | `…|2026-08-04|3` |
| Véhicule | + `EVN` | `…|3|936XXXXXXXXX` |

`GrainValuesJson` conserve les mêmes composants sous la forme `[{"name":…, "value":…}]`,
pour que Power BI ou un autre outil retrouve l'objet sans analyser le `RunId`.
`[EXT] SourceKey = CountingId` permet la jointure rapide avec `comptage_API.DQ_*`.
Rang d'arrêt ou code gare dans le `RunId` : voir 07, choix 8.

### Courant et historique

Chaque ré-exécution d'une fenêtre passe les lignes précédentes de la même règle à
`IsCurrent = 0` (puis insère les nouvelles à `IsCurrent = 1`). Les rapports lisent
`IsCurrent = 1` ; l'historique permet de comparer deux exécutions et d'auditer un rejeu.

### Index

- `LogsDQ` et `ScoresDQ` : index **columnstore clusterisé** (compression, lectures
  analytiques), clé primaire non clusterisée sur l'identifiant de ligne, index filtré
  `IsCurrent = 1` sur `(RegleDQID, WindowDate)`.
- `comptage_API.DQ_*` : clés clusterisées sur `(CountingId, Rang, …)`, compression `PAGE` sur
  `ArretEVN`, index d'unicité sur `RunId`.

## 4. Restitution (schéma `comptage_API`, préfixe `DQ_`)

Modèle en étoile reconstruit par `comptage_API.usp_DQ_RafraichirModele`, lu par Power BI via les vues
`comptage_API.vw_DQ_*`.

```mermaid
erDiagram
    DimDate ||--o{ DimTrain : "DateKey"
    DimTrain ||--o{ FaitResultat : "CountingId"
    DimTrain ||--o{ FaitArret : "CountingId"
    DimRegle ||--o{ FaitResultat : "RegleKey"
    DimStatut ||--o{ FaitResultat : "StatutKey"
    DimGrain ||--o{ FaitResultat : "GrainKey"
    DimGare ||--o{ FaitArret : "StationCode"
    DimGare ||--o{ FaitResultat : "StationCode"
    DimRegle ||--o{ AggStatutRegle : "RegleKey"
    DimStatut ||--o{ AggStatutRegle : "StatutKey"
    DimGrain ||--o{ AggStatutRegle : "GrainKey"
    DimDate ||--o{ AggStatutRegle : "DateKey"
```

| Table | Type | Grain | Colonnes clés |
|---|---|---|---|
| `DimDate` | Dimension | un jour | `DateKey` (AAAAMMJJ), année, mois, jour de semaine, week-end |
| `DimStatut` | Dimension | un statut | `Statut`, `Ordre`, `EstTeste` (dénominateur des taux « parmi les testés »), `EstEchec`, `CouleurHex` |
| `DimGrain` | Dimension | une maille | 1 Train, 2 Arrêt, 3 Véhicule |
| `DimRegle` | Dimension | une règle | libellé « DQ-03 Remise à zéro au terminus », calcul, choix validés, statut de validation, poids |
| `DimGare` | Dimension | un code gare | nom le plus fréquent du code (le nom n'est pas fiable, constat [C03](../05_constats_qualite.md)), coordonnées, canton, commune (facultatifs, open data) |
| `DimTrain` | Dimension large | un train | attributs du train, **les 14 statuts en colonnes** (`DQ01`…`DQ14`), `NbFail`, `NbNotTested`, `Score`, `Couverture`, `TrancheScore`, `Verdict`, `Imputation`, `ExtValides`, `ToutVert`, motif et liste des arrêts à imputer |
| `FaitResultat` | Fait (columnstore) | objet x règle | clés vers dimensions, `Rang`, `EVN`, `StationCode`, écarts, motif d'échec, `LogDQID` |
| `FaitArret` | Fait (columnstore) | un arrêt | occupation, montées, descentes, capacité, cumul, score et verdict de l'arrêt, `ArretMesure` |
| `AggStatutRegle` | Agrégat (columnstore) | date x ligne x type x série x verdict x imputation x extérieur valide x tout vert x maille x règle x statut | `NbObjets` |

Pourquoi `DimTrain` large : le dashboard actuel affiche une ligne de train avec ses 14
statuts, des filtres par statut de règle et des tris. Les 14 colonnes évitent 14
jointures et se compressent très bien. `FaitResultat` sert au détail (drill-down vers
l'arrêt et le véhicule) et à la liste des enregistrements en échec.

Le détail de la reconstruction, des index et des choix de performance est dans
[05_performance_et_restitution.md](05_performance_et_restitution.md).

## 5. Vues exposées

| Vue | Usage |
|---|---|
| `audit.vw_DQ_LogsEnrichis` | Journal joint au catalogue et à l'exécution (base des autres vues et de la recette) |
| `audit.vw_DQ_FailedRecords` | Enregistrements en échec (FAIL, CRITICAL) |
| `audit.vw_DQ_RuleReport` | Rapport par règle (V1) |
| `audit.vw_DQ_HighLevelReport` | Rapport synthétique (V1) |
| `audit.vw_ReglesDQ_DataGalaxy` | Catalogue au format DataGalaxy (hors flux V1) |
| `comptage_API.vw_DQ_DimDate`, `vw_DimStatut`, `vw_DimGrain`, `vw_DimRegle`, `vw_DimGare`, `vw_DimTrain` | Dimensions Power BI |
| `comptage_API.vw_DQ_FaitResultat`, `vw_FaitArret`, `vw_AggStatutRegle` | Faits Power BI |
| `comptage_API.vw_DQ_FaitResultatRecent`, `vw_DQ_FaitArretRecent` | Mêmes faits limités aux N derniers jours (paramètre `detail_jours_import`, 30 par défaut) : détail importé léger pour Power BI Report Server sans modèle composite |
| `comptage_API.vw_DQ_FaitExecution` | Suivi des exécutions (durées, erreurs) |
| `comptage_API.vw_DQ_ParametresScore` | Paramètres du score affichés dans la page « Règles appliquées » |
