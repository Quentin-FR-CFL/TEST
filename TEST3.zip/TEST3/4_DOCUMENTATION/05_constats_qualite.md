# Constats de qualité de données

Document unique et central des **problèmes de qualité constatés** dans l'extraction de
comptage passagers. Le projet **qualifie** les problèmes : il ne corrige ni n'enrichit la
donnée. Chaque constat peut devenir plus tard une règle ou un indicateur du dashboard.

Dernière mise à jour : 2026-11-06 (ajout de C27 et C28, issus des règles DQ-13 et DQ-14 ; C30 et C31, issus de la validation des règles par cas concrets). Chiffres calculés sur `output/dashboard/` et sur les fichiers
`output/phase3_*.csv` (5 000 trains, 44 949 arrêts, août 2026), sauf mention « repris de ».

Vue d'ensemble du projet : [00_vue_ensemble.md](00_vue_ensemble.md). Règles DQ :
[02_documentation_metier_regles.md](02_documentation_metier_regles.md). Dataset :
[03_dataset_et_maille.md](03_dataset_et_maille.md).

## Comment ajouter un constat

À chaque nouvelle problématique de qualité repérée (en analysant, en discutant avec
l'utilisateur ou en relançant la chaîne), l'ajouter **ici et nulle part ailleurs** :

1. prendre le prochain numéro `Cnn` et reprendre le modèle ci-dessous ;
2. donner un chiffre calculé sur `output/` ou sur le CSV brut, avec sa méthode ; sinon
   écrire **à confirmer** ;
3. dire si une règle DQ le détecte déjà, et noter l'indicateur possible (sans le créer) ;
4. ajouter une ligne au tableau de synthèse et une entrée au `CHANGELOG.md` ;
5. ne pas dupliquer le constat dans les autres docs : y mettre un lien vers ce fichier.

Modèle :

```
### Cnn – Titre court
- **Constat** : ce qu'on observe, en une ou deux phrases.
- **Chiffres** : valeurs et méthode.
- **Détecté par** : règle DQ existante, ou « aucune règle ».
- **Indicateur possible** : idée, non implémentée.
- **Statut** : Constaté / À confirmer. Cause : …
```

## Synthèse

| N° | Constat | Mesure clé | Détecté par | Statut |
|---|---|---|---|---|
| C01 | Arrêts sans aucune donnée | 4 872 arrêts (10,8 %) | DQ-07 (train), NOT_TESTED (arrêt) | Constaté |
| C02 | Trains aux arrêts manquants | 2 406 trains sur 5 000 (48,1 %) | DQ-07 | Constaté |
| C03 | Capteurs extérieurs invalides | 2 617 trains sur 5 000 (52,3 %) sans tous leurs capteurs extérieurs valides | DQ-06 | Constaté |
| C04 | Matériel dégradé très fréquent | 2 489 trains (49,8 %) | DQ-05 | À confirmer (sens) |
| C05 | Capacité nulle ou inconnue | 829 trains avec une capacité capteur nulle (16,6 %), NOT_TESTED en DQ-04 depuis le 2026-11-11 | DQ-04 | Constaté |
| C06 | Composition vide | 106 trains | DQ-02 (FAIL d'office) | Constaté |
| C07 | Trajets coupés à la frontière | 0 occurrence de Nancy, Metz, Thionville, Trèves, Bastogne | aucune règle | À confirmer |
| C08 | Noms de gares en double par la casse | 3 gares en double (101 noms, 98 gares) | aucune règle | Constaté |
| C09 | Catégories de flux jamais renseignées | pas de 1re classe ni de PMR dans les montées et descentes | aucune règle | Constaté (repris de) |
| C10 | DQ-11 ne détecte aucun écart | 0 WARNING, 0 FAIL, 175 NOT_TESTED au niveau train | DQ-11 | À confirmer (cause) |
| C11 | Période annoncée différente des dates présentes | voir section 1 de la vue d'ensemble | aucune règle | À confirmer |
| C12 | Trains comptés absents du plan GTFS | 174 trains sur 5 000 (3,5 %) | aucune règle | À confirmer (cause) |
| C13 | Arrêts du plan jamais réalisés dans les données | 4 871 arrêts planifiés sans heure réelle ni comptage | DQ-07 (en partie) | À confirmer (cause) |
| C14 | Arrêts réalisés mais non planifiés | 400 arrêts (`isPlanned` faux) | aucune règle | À confirmer |
| C15 | Trains prévus sans comptage | 10 175 voyages prévus sur 14 997 (67,8 %) du 4 au 23 août | aucune règle | Constaté (cause : extraction de 5 000 trains) |
| C16 | Types de train du plan presque absents du comptage | IC : 9 comptés pour 1 380 prévus ; TER et TGV : 0 compté | aucune règle | À confirmer (cause) |
| C17 | Annulations non observables | 0 changement entre les fichiers GTFS successifs ; statut toujours `Completed` | aucune règle | À confirmer |
| C18 | Arrêts du plan jamais présents dans le comptage | 20 arrêts du plan sur 91, tous frontaliers ou étrangers | aucune règle | À confirmer (cause) |
| C19 | Matériel roulant inconnu pour les trains non comptés | 102 524 passages prévus sur 148 189 (69,2 %) sans série connue | aucune règle | Constaté (limite de la donnée) |
| C20 | Cantons sans aucune gare dans le comptage | 4 cantons sur 12 sans gare (Redange, Vianden, Echternach, Remich) ; 16 gares hors canton | aucune règle | Constaté (limite de la donnée) |
| C21 | Capacité capteur nulle intermittente | 3 513 passages de véhicule sur 167 553 (2,1 %) ; 82 EVN sur 162 touchés, aucun en permanence | DQ-04 | Constaté (cause à confirmer) |
| C22 | Heures réelles incohérentes | 58 arrêts arrivée après départ, 242 reculs entre arrêts, 348 écarts d'au moins 60 min | aucune règle | Constaté |
| C23 | Heures prévues absentes | 82 trains sans heure prévue (1,6 %), 421 arrêts réels sans heure prévue | aucune règle | Constaté |
| C24 | Heure du premier événement décalée de 2 h | 3 008 trains sur 3 015 testables (99,8 %) | aucune règle | À confirmer (fuseau) |
| C25 | Capteurs 1re classe et vélo absents alors que la capacité théorique existe | 1re classe : série 2400 à 50,3 % ; vélo : 0 % sur 2400, 2450 et TER2N | aucune règle | À confirmer (cause) |
| C26 | Catégorie PMR presque absente | 1 363 passages de véhicule sur 167 553 (0,8 %), jamais en capacité ni en flux | aucune règle | À confirmer (sens) |
| C27 | Flux Dosto aux extrémités : rattachement aux deux circulations à vérifier | 6 trains sur 1 913 testés avec un flux aux extrémités (4 FAIL, 2 WARNING) ; 3 087 non testables | DQ-14 | À confirmer (rattachement Dosto) |
| C28 | Zéros répétés comptés comme capteur figé | 82 % des 3 101 séquences EVN en FAIL DQ-13 portent sur un zéro (2 535) ; 1 448 EVN à zéro sur tout le trajet | DQ-13 | À confirmer (traitement des zéros) |
| C29 | Arrêts sans heure réelle : pas de découpage horaire possible | 4 889 arrêts sur 44 949 (10,9 %), dont 18 avec une occupation mesurée | aucune règle | Constaté |
| C30 | Occupation au terminus inférieure aux descentes | 792 trains sur 2 356 testables (33,6 %) ; 546 (23,2 %) changent de statut DQ-03 selon que l'occupation est lue avant ou après les descentes | DQ-03 (indirectement) | Constaté (occupation mesurée avant les descentes, confirmé le 2026-11-11) |
| C31 | Plus de véhicules observés que dans la composition | 22 arrêts sur 12 trains | DQ-02 (FAIL, sans distinction) | À confirmer (cause) |

## Détail

### C01 – Arrêts sans aucune donnée
- **Constat** : un arrêt attendu n'a aucune occupation mesurée. Le manque est surtout aux extrémités du trajet.
- **Chiffres** : 4 872 arrêts sur 44 949 (10,8 %) ; origine 1 903, terminus 1 856, intermédiaire 1 113. Origine et terminus font 77,2 % des arrêts sans donnée. Calcul : `has_data = 0` dans `dq_stations.csv`.
- **Détecté par** : DQ-07 à la maille Train ; ces arrêts sont NOT_TESTED pour la plupart des règles Station.
- **Indicateur possible** : part d'arrêts sans donnée par gare, par ligne, par jour (déjà visible dans l'onglet « Complétude et imputation » et sur la carte).
- **Statut** : Constaté. Cause (capteur, transmission, arrêt non desservi) : à confirmer.

### C02 – Trains aux arrêts manquants
- **Constat** : un train sur deux a au moins un arrêt non mesuré.
- **Chiffres** : DQ-07 en PASS pour 2 594 trains sur 5 000 (51,9 %), donc 2 406 en FAIL (48,1 %).
- **Détecté par** : DQ-07.
- **Indicateur possible** : motif de manque (début, fin, trou) déjà calculé dans `missing_pattern`.
- **Statut** : Constaté.

### C03 – Capteurs extérieurs invalides
- **Constat** : plus d'un train sur deux a au moins un capteur extérieur invalide.
- **Chiffres** : `ext_valides = Oui` pour 2 383 trains sur 5 000 (47,7 %) ; 7 trains sans donnée.
- **Détecté par** : DQ-06.
- **Indicateur possible** : taux de capteurs invalides par véhicule ou par série (voir l'onglet « Capteurs »).
- **Statut** : Constaté.

### C04 – Matériel dégradé très fréquent
- **Constat** : `IsDegraded` vaut vrai sur environ la moitié des trains.
- **Chiffres** : DQ-05 en FAIL pour 2 489 trains sur 5 000 (49,8 %).
- **Détecté par** : DQ-05.
- **Indicateur possible** : part de trains dégradés par série de véhicule.
- **Statut** : À confirmer. Le sens métier de `isDegraded` n'est pas établi (voir [02_documentation_metier_regles.md](02_documentation_metier_regles.md)).

### C05 – Capacité nulle ou inconnue
- **Constat** : des trains ont une capacité nulle, ce qui rend le taux de charge incalculable.
- **Chiffres** : 829 trains (16,6 %) étaient en FAIL DQ-04 avant le 2026-11-11 ; tous venaient d'une capacité capteur à 0 avec une occupation de 0 (voir C21). Ils sont maintenant NOT_TESTED au niveau du détail (DQ-04 Train : 4 996 PASS, 3 WARNING, 0 FAIL, 1 NOT_TESTED). Repris de [04_roadmap.md](04_roadmap.md), non recalculé ici : 742 trains ont une capacité nulle à l'origine.
- **Détecté par** : DQ-04.
- **Indicateur possible** : part de trains à capacité nulle par série.
- **Statut** : Constaté (le chiffre des 742 est à recalculer). Traitement par la règle validé le 2026-11-11 : une capacité nulle avec occupation 0 est NOT_TESTED (rien à juger), FAIL seulement avec des voyageurs (aucun cas).

### C06 – Composition vide
- **Constat** : des trains n'ont aucune liste d'EVN (`HasComposition` = 0).
- **Chiffres** : 106 trains, repris de [00_vue_ensemble.md](00_vue_ensemble.md) (section 9). Ils sont FAIL d'office à DQ-02.
- **Détecté par** : DQ-02.
- **Indicateur possible** : part de trains sans composition par ligne et par jour.
- **Statut** : Constaté.

### C07 – Trajets coupés à la frontière
- **Constat** : Nancy, Metz, Thionville, Trèves et Bastogne, qui sont des destinations réelles, n'apparaissent nulle part dans l'extraction. Les trains vers ces villes y finissent à une gare frontière.
- **Chiffres** : 0 occurrence de ces cinq noms dans le CSV brut. Liaisons les plus fréquentes : Athus↔Luxembourg 1 129 trains, Bettembourg↔Volmerange-les-Mines 353, Luxembourg↔Wasserbillig 268 (somme des deux sens, `DepartureStation`/`ArrivalStation`). Longwy et Diekirch sont bien présentes.
- **Détecté par** : aucune règle.
- **Indicateur possible** : part de trains dont le terminus compté est une gare frontière (liste des gares frontière à valider).
- **Statut** : À confirmer avec le plan de transport. On mesure la couverture, on ne la complète pas.

### C08 – Noms de gares en double par la casse
- **Constat** : une même gare existe sous deux écritures et est comptée deux fois.
- **Chiffres** : `Longwy`/`LONGWY`, `Marbehan`/`MARBEHAN`, `Libramont`/`LIBRAMONT` : 101 noms pour 98 gares. Longwy compte 147 et 181 arrêts selon l'écriture, avec les mêmes coordonnées.
- **Détecté par** : aucune règle.
- **Indicateur possible** : nombre de noms de gares identiques à la casse près.
- **Statut** : Constaté.

### C09 – Catégories de flux jamais renseignées
- **Constat** : les montées et descentes n'ont jamais de 1re classe ni de PMR ; le vélo n'apparaît que sur 16 voitures DOSTO.
- **Chiffres** : repris de [04_roadmap.md](04_roadmap.md) et [03_dataset_et_maille.md](03_dataset_et_maille.md), non recalculé ici.
- **Détecté par** : aucune règle.
- **Indicateur possible** : taux de catégories toujours à zéro.
- **Statut** : Constaté (chiffre à recalculer).

### C10 – DQ-11 ne détecte aucun écart
- **Constat** : la règle de cohérence entre mailles ne produit ni WARNING ni FAIL.
- **Chiffres** : DQ-11 au niveau train : 4 825 PASS, 175 NOT_TESTED.
- **Détecté par** : DQ-11 elle-même.
- **Indicateur possible** : à voir si la Station est calculée par l'API comme somme des EVN.
- **Statut** : À confirmer (cause).

### C11 – Période annoncée différente des dates présentes
- **Constat** : la période annoncée (4 au 25 août) ne correspond pas exactement aux dates de circulation présentes.
- **Chiffres** : voir la section 1 de [00_vue_ensemble.md](00_vue_ensemble.md).
- **Détecté par** : aucune règle.
- **Indicateur possible** : jours attendus contre jours présents.
- **Statut** : À confirmer.

### C12 – Trains comptés absents du plan GTFS
- **Constat** : certains trains de l'extraction n'ont pas de voyage correspondant (même numéro, même date, service actif) dans le GTFS ferroviaire de data.public.lu (`gtfs-20260729-20260823` pour le 4 août, `gtfs-20260805-20261011` ensuite).
- **Chiffres** : 174 trains sur 5 000 (3,5 %), 4 826 retrouvés. 116 ont un numéro à 6 chiffres et aucun de ces 116 n'est dans le plan (trains hors offre commerciale ? **à confirmer**) ; 58 ont 4 ou 5 chiffres (par exemple 5956, 5960, 19444). Méthode : numéro sans zéros de tête, calendrier du GTFS (`calendar` et `calendar_dates`).
- **Détecté par** : aucune règle.
- **Indicateur possible** : train compté présent dans le plan, oui / non.
- **Statut** : À confirmer. Cause : trains non commerciaux, numéros différents entre systèmes, ou suppressions.

### C13 – Arrêts du plan jamais réalisés dans les données
- **Constat** : le GTFS ne donne que le prévu. Le « réalisé » se lit dans l'extraction elle-même (`actualArrivalTime`, `actualDepartureTime`, `stationPassed`). 4 871 arrêts planifiés n'ont ni heure réelle, ni comptage, ni passage (`stationPassed` faux) ; ils recoupent les arrêts sans donnée de C01 (4 872). Les données ne permettent pas de distinguer un train qui n'a pas desservi l'arrêt (suppression partielle, terminus anticipé) d'un événement non reçu.
- **Chiffres** : sur 44 949 arrêts, 39 659 sont planifiés et réalisés avec comptage ; 4 871 planifiés sans rien ; 18 comptés sans heure réelle. Comparaison au GTFS sur les 4 826 trains retrouvés, restreinte aux gares localisées de façon exacte dans `config/stations_geoloc.csv` : séquence d'arrêts identique pour 4 734 trains (98,1 %), 92 trains différents. 81 arrêts du GTFS manquent dans le comptage et 26 arrêts du comptage manquent dans le GTFS ; une part vient des noms de gares non appariés (par exemple Bertrange-Strassen contre Bertrange, Gare) : **à confirmer**.
- **Détecté par** : DQ-07 en partie (arrêts attendus selon `StopsJson`, pas selon le plan GTFS).
- **Indicateur possible** : arrêts du plan GTFS présents dans le comptage, en %.
- **Statut** : À confirmer. Cause : à confirmer avec l'exploitant. Aucun GTFS temps réel historique n'est publié sur data.public.lu d'après la recherche du 2026-11-05 (**à confirmer**).

### C14 – Arrêts réalisés mais non planifiés
- **Constat** : 400 arrêts ont `isPlanned` faux alors qu'ils sont comptés et ont une heure réelle (desserte ajoutée ou déviation).
- **Chiffres** : 400 arrêts sur 44 949 (0,9 %). Méthode : champ `isPlanned` de `StopsJson`. Pour mémoire, quand l'arrêt est planifié, les heures prévues de l'extraction concordent avec le GTFS à une minute près pour 39 242 arrêts sur 39 274 comparés à l'arrivée (99,9 %) et 39 237 sur 39 275 au départ ; le retard médian au départ (réel moins prévu) est de 17 s, avec 1 823 départs de plus de 5 minutes sur 36 470.
- **Détecté par** : aucune règle.
- **Indicateur possible** : part d'arrêts hors plan par train.
- **Statut** : À confirmer (sens de `isPlanned` à valider avec l'exploitant).

### C15 – Trains prévus sans comptage
- **Constat** : beaucoup de trains du plan n'apparaissent pas dans l'extraction. L'utilisateur a confirmé (2026-11-06) que l'extraction est limitée à 5 000 trains sur plusieurs jours : des trains comptés n'ont donc pas été pris dans l'extraction. Les données ne permettent pas de séparer un train non extrait d'un train sans comptage.
- **Chiffres** : du 4 au 23 août, 14 997 voyages prévus (numéros de train distincts par jour, GTFS), 4 822 trains comptés retrouvés dans le plan, soit 10 175 prévus sans comptage (67,8 %). Du 24 au 26 août, presque rien n'est extrait (5 trains) alors que le plan continue : l'extraction s'arrête vers le 23. Méthode : `output/dashboard/dq_gtfs_jours.csv`.
- **Détecté par** : aucune règle.
- **Indicateur possible** : trains avec comptage utilisable sur trains prévus, par jour et par type (onglet « GTFS vs comptage »).
- **Statut** : Constaté. Cause principale : extraction limitée à 5 000 trains (confirmé) ; part des trains sans capteurs ou sans comptage remonté : à confirmer.

### C16 – Types de train du plan presque absents du comptage
- **Constat** : l'extraction ne contient presque que des RB et des RE. Les IC sont quasi absents, les TER et TGV du plan (24 au 26 août seulement) ne sont pas comptés.
- **Chiffres** : 5 000 trains : 3 603 RB, 1 214 RE, 9 IC, 174 hors plan, 0 TER, 0 TGV. Prévus du 4 au 23 août : 9 511 RB, 4 106 RE, 1 380 IC. Méthode : type du voyage GTFS retrouvé (`type_plan` de `dq_gtfs_trains.csv`).
- **Détecté par** : aucune règle.
- **Indicateur possible** : trains comptés sur prévus par type.
- **Statut** : À confirmer. Cause : matériel sans capteurs (trains internationaux), ou périmètre de l'extraction.

### C17 – Annulations non observables
- **Constat** : les annulations de train ne sont pas visibles dans les données disponibles. Le GTFS publié est statique, le statut du train est toujours `Completed` et aucun train compté n'est sans arrêt réalisé.
- **Chiffres** : sur 7 dates d'août (12 au 23), les fichiers GTFS hebdomadaires publiés avant chaque date (29 juillet, 5, 12 et 19 août, jusqu'à quatre selon la date) donnent exactement les mêmes voyages (0 retiré, 0 ajouté) ; `TrainStatus` vaut `Completed` pour 5 000 trains sur 5 000 ; 0 train compté sans aucun arrêt réalisé. Voir aussi C13 pour les arrêts du plan non réalisés.
- **Détecté par** : aucune règle.
- **Indicateur possible** : trains prévus sans comptage, à rapprocher d'une source d'annulations (GTFS temps réel ou données de l'exploitant, **à confirmer** : aucune n'est publiée sur data.public.lu d'après la recherche du 2026-11-05).
- **Statut** : À confirmer.

### C18 – Arrêts du plan jamais présents dans le comptage
- **Constat** : 20 des 91 arrêts ferroviaires du plan GTFS n'ont aucun arrêt correspondant dans le comptage. Ce sont les arrêts frontaliers ou à l'étranger : Trèves (7 arrêts), Igel, Kreuz-Konz, Konz-Karthaus, Wasserbillig-Frontière, Thionville, Metz-Ville, Hettange-Grande, Bettembourg-frontière, Gouvy, Troisvierges-Frontière, Arlon-Sterpenich-Frontière, Rodange-Frontière (Athus) et Rodange-Gr. Pour 17 d'entre eux, aucun passage prévu n'a de comptage utilisable ; les 3 autres (Arlon-Sterpenich-Frontière, Rodange-Frontière (Athus), Rodange-Gr.) ont des trains comptés, apparemment sous un autre nom de gare (**à confirmer**). Même cause probable que C07 (trajets coupés à la frontière).
- **Chiffres** : appariement par nom entre les gares localisées « exacte » depuis le GTFS (`config/stations_geoloc.csv`) et les gares de `dq_stations.csv`, calculé le 2026-11-06 ; 17 arrêts du plan n'ont aucun passage utilisable. Voir `output/dashboard/dq_gtfs_gares.csv` et la carte de l'onglet « Couverture du plan ».
- **Détecté par** : aucune règle.
- **Indicateur possible** : part des arrêts du plan ayant au moins un passage compté, par gare.
- **Statut** : À confirmer. Cause : capteurs absents hors du réseau luxembourgeois, ou périmètre de l'extraction. L'appariement par nom peut aussi manquer des arrêts (noms différents) : à confirmer.

### C19 – Matériel roulant inconnu pour les trains non comptés
- **Constat** : la série du matériel roulant (DOSTO, 2400, 2450, TER2N, LOCOMOTIVE) n'existe que dans le comptage. Le GTFS ne la donne pas : seul le type commercial (RB, RE, IC, TER, TGV) est connu. Pour un train prévu sans comptage, le matériel est donc inconnu et la couverture par série du matériel ne se mesure pas sur le plan, seulement sur les trains comptés. Sur les trains comptés, le taux de passages utilisables varie beaucoup selon la série.
- **Chiffres** : 102 524 passages prévus sur 148 189 (69,2 %) sans série connue ; parmi les passages comptés, utilisables : DOSTO 99,4 %, LOCOMOTIVE 98,9 %, TER2N 86,5 %, 2400 77,7 %, 2450 77,1 %, « Non renseigné » 2,9 % (210 passages, voir C06). Méthode : `serie` de `dq_gtfs_gares.csv`.
- **Détecté par** : aucune règle (DQ-02 pour la composition vide, voir C06).
- **Indicateur possible** : part de passages utilisables par série, sur les trains comptés (onglet « Couverture du plan »).
- **Statut** : Constaté. Lecture à prudence : l'écart entre séries porte sur des trains comptés seulement, et l'extraction est limitée à 5 000 trains (C15).

### C20 – Cantons sans aucune gare dans le comptage
- **Constat** : la couche des cantons de la carte ne peut colorer que les cantons où le comptage contient au moins une gare. Quatre cantons luxembourgeois n'en ont aucune dans l'extraction et restent vides sur la carte : l'absence d'indicateur n'y veut pas dire absence de problème. De plus, 16 gares localisées sont hors du Luxembourg (Belgique, France) et n'appartiennent à aucun canton ; leurs arrêts (2 527) sont les moins bien mesurés (48,1 % sans donnée, à rapprocher de C07).
- **Chiffres** : canton de chaque gare par point dans polygone (`config/cantons_lux_2026.geojson`, « Cantons in Luxembourg 2026 »), calculé le 2026-11-06 sur `output/dashboard/dq_stations_geo.csv`. 85 gares sur 101 dans un canton, réparties sur 8 cantons sur 12 : Esch-sur-Alzette 33, Luxembourg 18, Capellen 8, Diekirch 7, Wiltz 6, Grevenmacher 6, Mersch 4, Clervaux 3. Aucune gare dans Redange, Vianden, Echternach ni Remich. Que ces cantons n'aient pas de gare ferroviaire sur le réseau couvert : **à confirmer** (non vérifié ici).
- **Détecté par** : aucune règle.
- **Indicateur possible** : nombre de gares et d'arrêts par canton (indicateur de couverture géographique), à lire à côté de chaque indicateur de la couche des cantons.
- **Statut** : Constaté (limite de la donnée). Cause probable : pas de gare ferroviaire dans ces cantons (**à confirmer**).
### C21 – Capacité capteur nulle intermittente
- **Constat** : la capacité mesurée par le capteur d'un véhicule (`sensorCapacity.allClasses`) vaut 0 à certains passages seulement, ce qui rend le taux de charge incalculable (DQ-04 NOT_TESTED depuis le 2026-11-11 quand l'occupation vaut aussi 0, FAIL sinon). Aucun EVN n'est à 0 à tous ses passages : le véhicule est donc physiquement capable de mesurer. Plusieurs EVN ont exactement les mêmes passages nuls (par exemple 190 passages sur 1 450 pour 948200240612, 948200240620 et 948200240638), ce qui laisse penser à une panne de la rame entière (**à confirmer**).
- **Chiffres** : 3 513 passages de véhicule à capacité nulle sur 167 553 (2,1 %) ; 829 trains en ont au moins un, soit le même nombre que les anciens FAIL de DQ-04 (C05). EVN : 162, dont 80 jamais nuls et 82 intermittents (maximum 19,1 % de leurs passages). Par série de véhicule : 2400 3,55 % (1 278 sur 36 024), 2450 3,10 % (1 962 sur 63 312), « Non renseigné » 1,16 % (24 sur 2 073), DOSTO 0,61 % (243 sur 40 098), TER2N 0,02 % (6 sur 26 046). Méthode : `python src/indicateurs_phase3.py`, fichiers `output/phase3_capacite_serie.csv` et `output/phase3_capacite_evn.csv`. Les 3 513 passages à capacité nulle ont tous une occupation de 0 (aucun véhicule chargé n'est en cause). Le chiffre des 742 trains « à l'origine » de C05 n'est pas recalculé ici.
- **Détecté par** : DQ-04 (NOT_TESTED au niveau train, station et EVN depuis le 2026-11-11 ; FAIL auparavant).
- **Indicateur possible** : taux de capacité nulle par série et par EVN (livré en fichiers), puis suivi dans le temps de la persistance par EVN (phase 3 de la roadmap, nécessite plus d'historique).
- **Statut** : Constaté. Cause (panne de capteur, configuration, remontée) : à confirmer.

### C22 – Heures réelles incohérentes
- **Constat** : certains arrêts ont une arrivée réelle après le départ réel, ou une heure réelle plus petite que celle de l'arrêt précédent. Quelques écarts entre heure réelle et heure prévue dépassent une heure. À l'inverse, les heures prévues sont cohérentes entre elles : aucune arrivée prévue après le départ prévu, aucun recul entre arrêts, et l'heure prévue du train égale celle de ses arrêts Start et End (0 écart sur 4 918 trains).
- **Chiffres** : arrivée réelle après le départ réel : 58 arrêts sur 39 337 (0,15 %), 44 trains. Heure réelle qui recule entre deux arrêts consécutifs : 242 paires sur 35 060 (0,69 %), 120 trains. Écart réel - prévu d'au moins 60 min (arrivée ou départ) : 348 mesures sur 73 191 (0,48 %), 104 trains ; la majorité des écarts sont proches de +2 h, ce qui fait penser à un décalage d'horloge plutôt qu'à des retards réels (**à confirmer**, voir aussi C24). Les heures sont comparées modulo 24 h (passage de minuit géré) ; le seuil de 60 min est provisoire. Méthode : `output/phase3_horaires.csv` (contrôles H1 à H5, H8, H9) et `output/phase3_horaires_train.csv`.
- **Détecté par** : aucune règle.
- **Indicateur possible** : part de trains avec au moins une incohérence d'horaire (colonnes H1, H3, H5 de `phase3_horaires_train.csv`).
- **Statut** : Constaté. Cause : à confirmer.

### C23 – Heures prévues absentes
- **Constat** : 82 trains n'ont ni heure prévue de départ ni heure prévue d'arrivée (`PlannedDepartureTime`, `PlannedArrivalTime`). Des arrêts ont une heure réelle mais aucune heure prévue : ce sont surtout les arrêts non planifiés de C14.
- **Chiffres** : 82 trains sur 5 000 (1,6 %) ; 421 arrêts avec heure réelle sur 40 060 sans heure prévue (1,05 %), dont 400 non planifiés (`isPlanned` faux, C14) et 21 planifiés, 134 trains. Aucun arrêt passé (`stationPassed` vrai) n'est sans heure réelle. Méthode : `output/phase3_horaires.csv` (H6, H7, H10, H11).
- **Détecté par** : aucune règle.
- **Indicateur possible** : part de trains sans heure prévue ; il n'est pas établi que ce sont les 82 trains sans `TrainType` ni `LineCode` (**à confirmer**).
- **Statut** : Constaté.

### C24 – Heure du premier événement décalée de 2 h
- **Constat** : `FirstEventTime` précède de 2 heures le départ réel de l'arrêt Start pour presque tous les trains, alors que `LastEventTime` correspond à la dernière heure réelle de `StopsJson`. Les deux colonnes ne semblent donc pas dans le même fuseau (UTC contre heure locale, **à confirmer**), ce qui fausserait toute durée calculée entre elles.
- **Chiffres** : sur 3 015 trains ayant un départ réel à l'arrêt Start, 3 008 (99,8 %) ont un écart de plus de 30 min, dont 2 830 à −2 h (arrondi à l'heure). `LastEventTime` : 4 775 trains sur 5 000 sont à 0 h de la dernière heure réelle ; 225 (4,5 %) s'en écartent de plus de 30 min. Méthode : `output/phase3_horaires.csv` (H12 et H13).
- **Détecté par** : aucune règle.
- **Indicateur possible** : écart entre `FirstEventTime` et le premier départ réel.
- **Statut** : À confirmer (fuseau horaire ou sens de la colonne).

### C25 – Capteurs 1re classe et vélo absents alors que la capacité théorique existe
- **Constat** : pour des véhicules dont la capacité théorique prévoit de la 1re classe ou des places vélo, le capteur ne renvoie pas toujours la catégorie. En 1re classe, la série 2400 n'est renseignée qu'à moitié. Pour le vélo, seule la série DOSTO renvoie la clé : les séries 2400, 2450 et TER2N ne la renvoient jamais. Voir aussi C09 pour les montées et descentes. Une clé absente peut signifier « pas de capteur » ou « zéro » : à confirmer avec le fournisseur.
- **Chiffres** : passages de véhicule dont la capacité théorique de la catégorie est supérieure à 0, avec la clé présente dans la capacité capteur. 1re classe : 2400 6 040 sur 12 008 (50,3 %), 2450 96,9 %, DOSTO 98,8 %, TER2N 99,98 %. Vélo : 2400 0 sur 12 008, 2450 0 sur 21 104, TER2N 0 sur 17 364, DOSTO 10 198 sur 10 393 (98,1 %). Au niveau de l'arrêt, la capacité 1re classe est présente à 98,1 %, celle du vélo à 65,0 %. Méthode : `output/phase3_categories_evn.csv` et `output/phase3_categories.csv`.
- **Détecté par** : aucune règle.
- **Indicateur possible** : couverture capteur / théorique par catégorie et par série.
- **Statut** : À confirmer (capteur absent ou clé non remontée).

### C26 – Catégorie PMR presque absente
- **Constat** : la catégorie PMR (clé `wheelchair`) n'existe que dans l'occupation, jamais dans la capacité, la capacité théorique, ni les montées et descentes. On ne peut donc pas dire quelle couverture PMR est attendue.
- **Chiffres** : occupation PMR présente sur 1 363 passages de véhicule sur 167 553 (0,8 %) et sur 1 248 arrêts sur 40 077 (3,1 %), toujours supérieure à 0 quand la clé est présente. Méthode : `output/phase3_categories.csv`.
- **Détecté par** : aucune règle.
- **Indicateur possible** : présence de la clé PMR par série, une fois l'attendu défini par le métier.
- **Statut** : À confirmer (sens de la clé et véhicules concernés).

### C27 – Flux Dosto aux extrémités : rattachement aux deux circulations à vérifier
- **Constat** : le référentiel (DQ-14) signale que, pour les Dosto, un même fichier peut couvrir les descentes au terminus d'une circulation et les montées à l'origine de la suivante, pour le même train physique mais sous des numéros de train différents (exemple cité : Luxembourg). Les montées au terminus ou les descentes à l'origine d'un train pourraient alors appartenir à la circulation voisine, ce qui fausserait DQ-14 et les flux de ces deux circulations. Le rattachement n'est pas vérifiable avec les colonnes disponibles : l'extraction ne donne pas la rame par circulation de façon fiable (les EVN servent à plusieurs circulations par jour).
- **Chiffres** : DQ-14 est PASS sur 1 907 trains, WARNING sur 2, FAIL sur 4 et NOT_TESTED sur 3 087 (3 005 trains dont l'origine ou le terminus n'a pas le flux attendu, 82 sans `Start` ni `End`) ; chiffres du 2026-11-11 après assouplissement du NOT_TESTED (avant : PASS 1 752, WARNING 1, FAIL 3, NOT_TESTED 3 244). Les 6 trains en écart : 26339 (train 5060, Luxembourg > Athus, 45 montées au terminus, part 33,09 %), 29850 (3630, Diekirch > Luxembourg, 7 montées, 8,05 %), 30095 (504854, Luxembourg > Wasserbillig, 1 montée sur 2 arrêts, 25,0 %), 26456 (6844, Pétange > Bettembourg-V, 4 descentes à l'origine, 2,06 %), 26510 (6721, Bettembourg-V > Rodange, 1 descente, 0,4 %) et 28196 (10459, Troisvierges > Luxembourg, 1 montée, 0,35 %). Test indicatif : pour 26339, 29850 et 26510 il existe, le même jour, une circulation avec les mêmes EVN partant du terminus 7, 56 et 21 minutes après l'arrivée (5086 pour 5060 : 2 descentes à son origine), compatible avec l'hypothèse mais pas une preuve ; 30095 n'a pas de suivante. Les 4 premiers trains ne sont pas de série DOSTO (2450, TER2N, 2400, TER2N) ; la série des 2 nouveaux (26456, 28196) **n'a pas été vérifiée** : à confirmer avant de conclure sur l'hypothèse Dosto. Méthode : `output/train_dq.csv` (`DQ14`, `dq14_part`) et croisement date, EVN et horaires sur le CSV brut.
- **Détecté par** : DQ-14 (formule et seuils inchangés dans l'attente de confirmation, comme le demande le référentiel).
- **Indicateur possible** : DQ-14 recalculée après rattachement des flux au train physique (même rame, terminus = origine suivante) ; part de trains Dosto concernés.
- **Statut** : À confirmer (fournisseur ou métier : comment les flux Dosto sont-ils découpés entre circulations ?).

### C28 – Zéros répétés comptés comme capteur figé
- **Constat** : DQ-13 compte une occupation répétée sans distinguer le zéro. Un véhicule vide sur tout le trajet, ou dont le capteur ne renvoie que des zéros, est FAIL (constance sur au moins 5 arrêts), alors que le référentiel rappelle qu'une suspicion ne prouve pas une panne. Le chiffre de DQ-13 mesure donc surtout des zéros répétés, pas des capteurs figés démontrés ; vide et muet ne se distinguent pas avec ces seules valeurs.
- **Chiffres** : 20 097 séquences (train × EVN) ; 9 380 non testables (9 086 incomplètes, 294 de moins de 5 arrêts), 4 900 PASS, 2 716 WARNING, 3 101 FAIL. Parmi les 3 101 FAIL, 2 535 (82 %) ont leur plus longue suite sur un zéro et 566 sur une valeur non nulle ; 1 496 ont une occupation constante sur tout le trajet, dont 1 448 constamment à zéro. Parmi les 2 716 WARNING, 1 042 sont des suites de zéros. Au niveau train : 473 PASS, 507 WARNING, 1 516 FAIL, 2 504 NOT_TESTED ; DQ-13 est en FAIL sur 45,0 % des trains « Mauvaise ». Méthode : `output/evn_dq.csv` (`DQ13`, `dq13_repetitions`) et occupations de `StopsJson`.
- **Détecté par** : DQ-13.
- **Indicateur possible** : part de séquences figées sur une valeur non nulle ; croisement avec DQ-06 (capteurs à 100 %) et `dq12_zeros` pour séparer véhicule vide et capteur muet.
- **Statut** : À confirmer (décision métier sur les zéros ; aucune modification de la règle tant qu'elle n'est pas prise).

### C29 – Arrêts sans heure réelle : pas de découpage horaire possible
- **Constat** : la carte du dashboard filtre par heure de passage (heure réelle d'arrivée à l'arrêt, à défaut de départ). Un arrêt sans heure réelle ne peut être placé dans aucune tranche horaire ; il sort de la carte dès qu'un filtre horaire est posé. Ces arrêts sont presque tous des arrêts sans donnée de comptage (voir C01 et C13), de sorte que le filtre horaire retire surtout les arrêts manquants et fait baisser la part d'arrêts sans donnée (1 arrêt sans donnée sur 40 060 arrêts avec heure, contre 10,8 % sur l'ensemble). Les arrêts manquants ne se lisent donc pas par heure, seulement sur l'ensemble de la journée ; pour localiser l'heure d'un manque, il faut passer par l'heure prévue du GTFS (**à confirmer** : non fait).
- **Chiffres** : 4 889 arrêts sur 44 949 (10,9 %) sans `actualArrivalTime` ni `actualDepartureTime` : origine 1 903, terminus 1 856, intermédiaire 1 130. 4 871 sont sans donnée de comptage, 18 ont une occupation mesurée mais aucune heure réelle (anomalie à part). Calcul : colonne `heure` vide de `dq_stations.csv` (issue de `StopsJson`), croisée avec `has_data` et `stopType`.
- **Détecté par** : aucune règle (DQ-07 voit l'arrêt non mesuré, pas l'absence d'heure).
- **Indicateur possible** : part d'arrêts mesurés sans heure réelle (18 ici) ; heure prévue de repli pour les arrêts non réalisés.
- **Statut** : Constaté. Cause des 18 arrêts mesurés sans heure : à confirmer.
### C30 – Occupation au terminus inférieure aux descentes
- **Constat** : au terminus, DQ-03 suppose que l'occupation est mesurée AVANT les descentes (écart = |occupation − descentes|). Or dans un tiers des cas testables, l'occupation est inférieure aux descentes, ce qui est impossible si elle est mesurée avant. Le cas parfait « occupation = descentes » est rare. Si l'occupation est au contraire mesurée APRÈS les descentes (elle devrait alors être proche de 0), le verdict de DQ-03 change pour près d'un train testable sur quatre. Le sens de la mesure décide donc du résultat de la règle. **Confirmé par l'utilisateur le 2026-11-11 : l'occupation est mesurée avant les descentes** (hypothèse H3 de DQ-03). La lecture « après les descentes » est écartée ; l'occupation inférieure aux descentes reste donc une anomalie de la donnée, à la source.
- **Chiffres** : 2 356 trains ont un terminus testable par DQ-03 (1 173 PASS, 1 183 FAIL). Occupation inférieure aux descentes : 792 (33,6 %), dont 609 des 1 183 FAIL. Occupation égale aux descentes avec descentes > 0 : 34. Lecture alternative (occupation après descentes, PASS si occupation ≤ 2 % de la capacité) : 546 trains changent de statut (385 FAIL deviennent PASS, 161 PASS deviennent FAIL). Méthode : `output/train_dq.csv` et `output/station_dq.csv` (arrêt `End`), cas d'illustration dans `output/validation/cas_validation.json` (règle DQ-03).
- **Détecté par** : DQ-03 (FAIL, sans distinguer les deux lectures). Question 19 de `docs/02_documentation_metier_regles.md` (tranchée).
- **Indicateur possible** : part de terminus dont l'occupation est inférieure aux descentes ; DQ-03 calculée selon les deux lectures.
- **Statut** : Constaté (2026-11-11). La règle DQ-03 reste inchangée. Cause de l'occupation inférieure aux descentes (descentes surestimées, ou occupation sous-estimée) : à confirmer.

### C31 – Plus de véhicules observés que dans la composition
- **Constat** : à certains arrêts, le nombre de véhicules (EVN) observés dépasse celui de la composition annoncée (`EuropeanVehicleNumbersJson`). Cela peut venir d'une composition mise à jour en route (accrochage) ou d'une composition incomplète ; DQ-02 classe ces arrêts en FAIL comme les arrêts où il manque des véhicules, sans les distinguer.
- **Chiffres** : 22 arrêts avec donnée, composition non vide et plus de véhicules observés qu'attendus, sur 12 trains (exemple : train 5069 du 2026-08-08, 11 véhicules à Luxembourg pour 6 attendus). Méthode : `output/station_dq.csv` (`nb_evn_obs`) et `output/train_dq.csv` (`nb_evn_expected`).
- **Détecté par** : DQ-02 (FAIL, sans distinction du sens de l'écart).
- **Indicateur possible** : part d'arrêts avec plus de véhicules que prévu, à séparer des arrêts avec moins.
- **Statut** : À confirmer (cause).
