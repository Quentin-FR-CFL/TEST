# 01 – Architecture cible

## 1. Vue d'ensemble

```mermaid
flowchart LR
    SSIS["Job SSIS existant<br/>(géré par FRANKS)"] --> SRC["comptage API<br/>1 ligne = 1 train + JSON"]
    SRC -->|vue vw_DQ_SourceTrain| STG["comptage_API.DQ_StgTrain<br/>staging de la fenêtre"]
    STG --> CT["Contrôles techniques<br/>(bloquants / avertissements)"]
    CT --> PRS["Parsing JSON<br/>comptage_API.DQ_Train · Arret · ArretEVN · EVNAttendu"]
    PRS --> RULES["14 procédures audit.usp_DQ_BR_*<br/>appelées par l'orchestrateur"]
    CAT["audit.ReglesDQ<br/>catalogue + seuils"] --> RULES
    RULES --> LOGS["audit.LogsDQ<br/>1 ligne = 1 objet x 1 règle"]
    LOGS --> SCORE["audit.usp_DQ_CalculerScore"]
    PAR["audit.ParametresDQ"] --> SCORE
    SCORE --> SC["audit.ScoresDQ"]
    LOGS --> RPT["comptage_API.DQ_* modèle en étoile<br/>columnstore"]
    SC --> RPT
    PRS --> RPT
    RPT --> PBI["Power BI<br/>import + actualisation incrémentale"]
    LOGS --> V1["Vues V1<br/>vw_DQ_RuleReport, vw_DQ_HighLevelReport, DataGalaxy"]
```

Cinq couches, un schéma par couche :

| Couche | Schéma | Contenu | Conservation |
|---|---|---|---|
| Source | (existant) | Table « comptage API », intacte | Gérée par FRANKS |
| Staging et parsing | `comptage_API` (préfixe `DQ_`) | Copie typée de la fenêtre, tables éclatées (train, arrêt, véhicule) | Reconstruite à chaque exécution pour la fenêtre traitée |
| Contrôle | `audit` | Catalogue, paramètres, exécutions, journal des résultats, scores | Historique (voir 04, rétention) |
| Restitution | `comptage_API` (préfixe `DQ_`) | Dimensions, faits en columnstore, agrégats | Reconstruite sur la fenêtre à chaque exécution |
| Consommation | `comptage_API.vw_DQ_*`, `audit.vw_*` | Vues lues par Power BI et par DataGalaxy | — |

## 2. Principes

1. **La table source n'est jamais modifiée.** `comptage_API.Counting` (alimentée par le package ODS
   `SIV_api_Counting`) est lue à travers une vue typée, `comptage_API.vw_DQ_SourceTrain`.
2. **Une exécution = une fenêtre de dates** (`@DateDebut`, `@DateFin`, par défaut J-3 à J-1).
   Les anciens résultats de la même fenêtre passent à `IsCurrent = 0` (historique conservé),
   ce qui rend le traitement **rejouable**.
3. **Ensembliste.** Chaque règle est une requête sur toute la fenêtre, pas une boucle par
   train. Le JSON est éclaté une seule fois, puis toutes les règles lisent les tables typées.
4. **Un catalogue pilote tout** : seuils, activation, variantes (`ParamsJson`), poids du
   score. Changer un seuil ne demande aucun redéploiement de procédure.
5. **Le projet qualifie, il ne corrige pas** : aucune valeur de la source n'est modifiée ni
   imputée ; l'imputation est une *recommandation* portée par le score.
6. **Structure V1 respectée** : tables `ReglesDQ`, `LogsDQ`, orchestrateur
   `usp_DQ_ExecuterRegles`, une procédure par règle `usp_DQ_BR_*`, `fn_BuildRunId`,
   `GrainDefinitionJson` / `GrainValuesJson`, statuts PASS / WARNING / FAIL / CRITICAL /
   NOT_TESTED / N/A / MEASURE. Les ajouts sont repérés `[EXT]` (voir 07).

## 3. Correspondance avec la proposition V1

| Élément V1 | Réalisation | Écart |
|---|---|---|
| `audit.ReglesDQ` | `03_audit_catalogue_logs.sql`, alimenté par `12_seed_catalogue.sql` | Colonnes `[EXT]` : `DetailGrainsJson`, `ParamsJson`, `ScoreWeight`, `StatutValidation`, `ChoixValides` |
| `audit.LogsDQ` | Idem, columnstore clusterisé | Colonnes `[EXT]` : `GrainLevel`, `SourceKey`, `WindowDate`, `IsCurrent` |
| Orchestrateur | `audit.usp_DQ_ExecuterRegles` | Liste blanche des procédures, TRY/CATCH par règle, `THROW 50020` si une règle échoue |
| Une procédure par règle | `audit.usp_DQ_BR_DQnn_*` | Écriture commune via `usp_DQ_EcrireResultats` |
| `fn_BuildRunId` | Idem | Variante avec rang d'arrêt (voir 07) |
| Vues de reporting | `vw_DQ_LogsEnrichis`, `vw_DQ_FailedRecords`, `vw_DQ_RuleReport`, `vw_DQ_HighLevelReport`, `vw_ReglesDQ_DataGalaxy` | Reconstituées à partir des diapositives, DDL exact V1 à rapprocher (voir 07) |
| Cube SSAS | Remplacé par le modèle `comptage_API.DQ_*` + Power BI | Voir 05 |

Le DDL de la V1 n'a pas été fourni sous forme de scripts : il a été reconstitué à partir
des schémas. Le rapprochement avec les tables réellement présentes en DEV est
décrit dans la section de delta idempotent, commentée, de `03_audit_catalogue_logs.sql`.

## 4. Grains des résultats

| GrainLevel | Maille | Identifiant de l'objet | Règles concernées |
|---|---|---|---|
| 1 | Train | `CountingId` | les 14 (synthèse ou règle propre) |
| 2 | Arrêt | `CountingId` + `Rang` | DQ-01, 02, 04, 05, 06, 10, 11, 12 |
| 3 | Véhicule (EVN) | `CountingId` + `Rang` + `VehIdx` (ou EVN) | DQ-04, 05, 06, 12, 13 |

Le niveau Train de chaque règle est la **synthèse** (pire statut) de ses niveaux fins, ou
le calcul propre de la règle (DQ-03, 07, 08, 09, 14). Le score s'appuie sur le niveau Train
et sur le niveau Arrêt.

## 5. Volumes

Jeu de référence (extraction d'août 2026, 5 000 trains, 22 jours de circulation), chiffres
issus des sorties du moteur Python et de la recette :

| Table | Lignes | Source du chiffre |
|---|---|---|
| `comptage_API.DQ_Train` | 5 000 | `output/train_dq.csv` |
| `comptage_API.DQ_Arret` | 44 949 (dont 40 077 avec donnée) | `output/station_dq.csv` |
| `comptage_API.DQ_ArretEVN` | 167 553 | `output/evn_dq.csv` |
| `audit.LogsDQ`, une exécution complète | 1 267 357 (Train 70 000, Arrêt 359 592, Véhicule 837 765) | somme des statuts attendus de la recette |

Volumes de **production** (trains par jour, historique à conserver) : **à confirmer**. À
volume égal par jour, 22 jours donnent 1,27 million de lignes de journal, soit de l'ordre
de 20 millions pour un an de la même densité de trains ; le columnstore et le
partitionnement mensuel (voir 05) absorbent cette volumétrie. Cette extrapolation est une
hypothèse de dimensionnement, pas une mesure.
