# Référentiel des règles DQ – « Règles DQ - Métier »

**Ce document est le référentiel des 14 règles DQ du projet.** Il transcrit deux captures
d'écran de l'onglet « Règles DQ - Métier » du classeur de l'utilisateur :
[regles_dq_metier.jpg](regles_dq_metier.jpg) (DQ-01 à DQ-12) et
[regles_dq13_dq14.png](regles_dq13_dq14.png) (DQ-13 et DQ-14, ajoutées le 2026-11-06, classeur
« REGLES_DQ_COMPTAGES »). Les captures font foi en cas de doute sur la transcription ; la seconde
est une photo d'écran de lecture difficile, à relire par l'utilisateur (**à confirmer**).

L'ancien fichier `OLD/Analyse des KPI's de Qualité de données.xlsx` ne contient pas cet
onglet et **n'est plus le référentiel** : il est conservé pour l'historique seulement.

Transcription faite le 2026-11-05 (DQ-01 à DQ-12) et le 2026-11-06 (DQ-13 et DQ-14). Les textes sont recopiés tels quels, sans reformulation.

## Vue d'ensemble

| N° | Règle | Granularité | PASS | WARNING | FAIL | NOT_TESTED |
|---|---|---|---|---|---|---|
| DQ-01 | Cohérence flux / occupation | Train / Station | Écart ≤ seuil | Non prévu | Écart > seuil | Occupation ou flux absent, ou ordre des arrêts inexploitable |
| DQ-02 | Complétude EVN | Train / Station | EVN observés = maximum attendu connu et maximum attendu ≤ 9 | Non prévu | Maximum attendu inconnu, > 9, ou EVN observés ≠ maximum attendu | Non prévu : un maximum inconnu reste FAIL |
| DQ-03 | Remise à zéro au terminus | Train | Terminus identifié, données disponibles et taux résiduel ≤ 2 % | Non prévu | Terminus identifié et taux résiduel > 2 % | Terminus non identifiable ou données nécessaires absentes |
| DQ-04 | Charge critique | Train (synthèse) + Train / Station / EVN (détail) | Capacité renseignée et > 0, et taux de charge ≤ 200 % | Capacité renseignée et > 0, et 200 % < taux de charge ≤ 250 %. Synthèse Train : au moins un WARNING et aucun FAIL | Taux de charge > 250 %, ou capacité nulle/inconnue. Synthèse Train : au moins un FAIL | Occupation absente ; à confirmer selon le traitement métier |
| DQ-05 | État du matériel | Train / Station / EVN | État = 0 | Non prévu | État = 1 | État absent |
| DQ-06 | Disponibilité des capteurs | Train / Station / EVN | 0 capteur invalide et données de comptage disponibles | Exactement 1 capteur invalide, avec données encore exploitables | Plus de 1 capteur invalide | Aucune donnée de capteur disponible |
| DQ-07 | Complétude des arrêts | Train | Rang maximal disponible et nombre d'arrêts observés = rang maximal | Non prévu | Rang maximal disponible et nombre d'arrêts observés ≠ rang maximal | Rang maximal attendu absent |
| DQ-08 | Équilibre des flux | Train | Les deux écarts ne dépassent pas simultanément 5 % | Non prévu | Écart global > 5 % ET écart intermédiaire > 5 % | Flux nécessaires absents ou dénominateur non calculable |
| DQ-09 | Remise à zéro à l'origine | Train | Origine identifiée, données disponibles, écart dans le seuil et absence de cas incohérent | Non prévu | Occupation = 0 avec montées > 0, ou écart hors seuil de 2 % | Origine non identifiable ou occupation/montées absentes |
| DQ-10 | Occupation reconstruite non négative | Train / Station | Minimum du cumul ≥ 0 | −3 ≤ minimum du cumul < 0 | Minimum du cumul < −3 | Au moins un flux nécessaire du parcours est absent |
| DQ-11 | Cohérence entre les mailles | Train / Station / EVN | Écart relatif ≤ 1 % | 1 % < écart relatif ≤ 5 % | Écart relatif > 5 % | Une des vues ou une des valeurs nécessaires est incomplète |
| DQ-12 | Valeurs exploitables | Tous grains | Taux exploitable = 100 % | 98 % ≤ taux exploitable < 100 % | Taux exploitable < 98 % | Périmètre vide, comptage indisponible ou taux non calculable |
| DQ-13 | Capteur figé | EVN / Séquence | Au plus 3 répétitions, sans occupation constante sur au moins 5 arrêts | 4 ou 5 répétitions, sans cas de constance classé FAIL | Au moins 6 répétitions, ou occupation constante sur au moins 5 arrêts | Séquence incomplète ou parcours trop court pour conclure |
| DQ-14 | Flux aux extrémités | Train | Descentes à l'origine = 0 ET montées au terminus = 0 | Flux non nuls aux extrémités et part ≤ 2 % | Part aux extrémités > 2 % | Extrémités ou flux absents, ou ratio non calculable |

## Détail par règle

### DQ-01 – Cohérence flux / occupation
- **Granularité** : Train / Station
- **Description** : Vérifie que l'occupation mesurée est cohérente avec l'occupation reconstruite à partir des montées et descentes.
- **Évolution de la règle** : Seuil rendu plus robuste avec un minimum de 5 voyageurs et 2 % de l'occupation théorique.
- **Formule complète** : Écart = |Occupation mesurée − Occupation reconstruite| ; seuil = MAX(5 voyageurs ; 2 % × Occupation reconstruite).

### DQ-02 – Complétude EVN
- **Granularité** : Train / Station
- **Description** : Vérifie que tous les EVN attendus sont présents à chaque arrêt.
- **Évolution de la règle** : Ajout de statuts explicites ; plafond métier maintenu à 9 EVN.
- **Formule complète** : Comparer le nombre d'EVN observés au maximum d'EVN attendu sur la circulation, avec un maximum autorisé de 9.

### DQ-03 – Remise à zéro au terminus
- **Granularité** : Train
- **Description** : Vérifie que l'occupation résiduelle au terminus reste négligeable.
- **Évolution de la règle** : Ajout de NOT_TESTED pour distinguer une donnée manquante d'un écart mesuré ; seuil de 2 % conservé.
- **Formule complète** : Taux résiduel = |Occupation au terminus − Descentes au terminus| / Capacité au terminus.

### DQ-04 – Charge critique
- **Granularité** : Train (synthèse) + Train / Station / EVN (détail)
- **Description** : Détecte une occupation physiquement aberrante par rapport à la capacité du matériel. Conserve le détail Train / Station / EVN et signale, à la maille Train, la présence d'au moins une anomalie.
- **Évolution de la règle** : Ajout d'une synthèse Train dès qu'au moins un détail est WARNING ou FAIL ; détail Train / Station / EVN conservé. WARNING au-delà de 200 % et jusqu'à 250 % ; FAIL au-delà de 250 %. Capacité nulle ou inconnue toujours traitée comme anomalie.
- **Formule complète** : Taux de charge = Occupation / Capacité. Synthèse Train : au moins une anomalie si au moins un détail Train / Station / EVN est WARNING ou FAIL ; retenir FAIL si au moins un FAIL, sinon WARNING si au moins un WARNING. Conserver le traitement des occupations absentes.

### DQ-05 – État du matériel
- **Granularité** : Train / Station / EVN
- **Description** : Identifie un matériel ou une composition signalé comme dégradé.
- **Évolution de la règle** : Ajout de NOT_TESTED lorsque l'état n'est pas fourni.
- **Formule complète** : Contrôle binaire : État matériel = 0 si conforme ; État matériel = 1 si dégradé.

### DQ-06 – Disponibilité des capteurs
- **Granularité** : Train / Station / EVN
- **Description** : Vérifie que les capteurs nécessaires au comptage sont disponibles.
- **Évolution de la règle** : Ajout des statuts ; distinction proposée pour le cas d'un seul capteur invalide. Ajout au dashboard d'un filtre « Capteurs extérieurs valides » fondé sur les données DQ-06 : Non si au moins un capteur extérieur est invalide, Oui sinon. Statuts DQ-06 inchangés.
- **Formule complète** : Nombre de capteurs invalides = total des capteurs attendus − capteurs valides. Filtre dashboard « Capteurs extérieurs valides » : si nombre de capteurs extérieurs invalides ≥ 1, alors Non ; sinon Oui. Ce filtre est distinct du statut DQ-06 et ne remplace pas NOT_TESTED en cas d'absence de données.

### DQ-07 – Complétude des arrêts
- **Granularité** : Train
- **Description** : Détecte les arrêts manquants dans la séquence d'un trajet.
- **Évolution de la règle** : Ajout de NOT_TESTED lorsque le rang maximal attendu est absent.
- **Formule complète** : Comparer le nombre d'arrêts observés au rang maximal attendu du trajet.

### DQ-08 – Équilibre des flux
- **Granularité** : Train
- **Description** : Vérifie l'équilibre entre montées et descentes sur le trajet complet et sur le tronçon intermédiaire.
- **Évolution de la règle** : Conservation du seuil de 5 % ; ajout du détail global et intermédiaire pour expliquer l'alerte.
- **Formule complète** : Écart global = |Total montées − Total descentes| / Total montées ; écart intermédiaire = |Montées intermédiaires − Descentes intermédiaires| / Montées intermédiaires.

### DQ-09 – Remise à zéro à l'origine
- **Granularité** : Train
- **Description** : Vérifie qu'aucune occupation incohérente n'est présente avant les premières montées.
- **Évolution de la règle** : Ajout du cas Occupation = 0 avec montées > 0, classé FAIL.
- **Formule complète** : Écart origine = |Occupation à l'origine − Montées à l'origine| ; comparer l'écart au seuil métier de 2 %.

### DQ-10 – Occupation reconstruite non négative
- **Granularité** : Train / Station
- **Description** : Vérifie que le cumul des montées moins les descentes ne devient pas négatif pendant le trajet.
- **Évolution de la règle** : Nouveau KPI : identification du premier arrêt où l'occupation reconstruite devient négative.
- **Formule complète** : Occupation reconstruite à l'arrêt n = somme cumulée des montées jusqu'à n − somme cumulée des descentes jusqu'à n ; retenir le minimum du trajet.

### DQ-11 – Cohérence entre les mailles
- **Granularité** : Train / Station / EVN
- **Description** : Vérifie que les résultats calculés aux mailles Train, Station et EVN se réconcilient.
- **Évolution de la règle** : Nouveau KPI de réconciliation entre les vues.
- **Formule complète** : Écart relatif = |Valeur maille A − valeur maille B| / MAX(|valeur A| ; |valeur B|) × 100 ; comparer occupation Station et somme EVN au même arrêt, puis montées Train et somme Station.

### DQ-12 – Valeurs exploitables
- **Granularité** : Tous grains
- **Description** : Mesure la part de valeurs réellement utilisables en distinguant absences, valeurs illisibles et vrais zéros.
- **Évolution de la règle** : Nouveau KPI de taux d'exploitabilité.
- **Formule complète** : Taux exploitable = 1 − (nombre de valeurs absentes + nombre de valeurs illisibles) / nombre total de valeurs.

### DQ-13 – Capteur figé
- **Granularité** : EVN / Séquence
- **Description** : Détecte une valeur identique répétée sur plusieurs arrêts, pouvant indiquer un capteur figé.
- **Évolution de la règle** : Nouveau KPI sur les répétitions consécutives : une suspicion seule ne prouve pas une panne.
- **Formule complète** : Compter, par EVN et par séquence ordonnée d'arrêts, le nombre maximal de répétitions consécutives d'une même valeur de comptage.

### DQ-14 – Flux aux extrémités
- **Granularité** : Train
- **Description** : Vérifie les descentes à l'origine et les montées au terminus.
- **Évolution de la règle** : Nouveau KPI sur les flux anormaux aux extrémités du trajet. Point à investiguer — Dosto : un même fichier couvre les descentes au terminus d'une circulation et les montées à l'origine de la suivante, pour le même train physique mais des numéros de train différents (ex. Luxembourg). Vérifier le rattachement des flux aux deux circulations et son impact sur le KPI avant toute évolution. Formule et seuils inchangés dans l'attente de confirmation.
- **Formule complète** : Part aux extrémités = (Descentes à l'origine + Montées au terminus) / Total des flux du trajet × 100.

## Précisions apportées par l'utilisateur pour ce jeu de données (2026-11-05)

Le référentiel ne dit pas comment lire certains champs du dataset. Ces points ont été tranchés avec l'utilisateur :

- **DQ-01** : occupation reconstruite = occupation mesurée à l'arrêt précédent + montées − descentes (*remplacé le 2026-11-11, voir la section suivante*).
- **DQ-02** : maximum attendu = `EuropeanVehicleNumbersJson` ; un arrêt sans donnée est NOT_TESTED.
- **DQ-03 / DQ-09** : origine = arrêt `Start` et terminus = arrêt `End` ; sans donnée, NOT_TESTED.
- **DQ-04** : capacité EVN = `sensorCapacity`.
- **DQ-05** : `isDegraded`, l'EVN hérite de son arrêt.
- **DQ-06** : 1 EVN = 2 capteurs (extérieur, intérieur), valide si fiabilité = 100 %.
- **DQ-07** : rang maximal = nombre d'arrêts de `StopsJson`.
- **DQ-11** : Station comparée à la somme de ses EVN seulement, car le dataset n'a pas de montées à la maille Train.

Les hypothèses encore à valider sont listées dans `docs/02_documentation_metier_regles.md`.

## Précisions retenues pour DQ-13 et DQ-14 (2026-11-06, hypothèses à confirmer)

Le référentiel ne définit pas tout ; choix faits par défaut, à valider par l'utilisateur :

- **DQ-13** : valeur de comptage = occupation de l'EVN à l'arrêt ; séquence = tous les arrêts du train dans l'ordre ; « répétitions » = plus longue suite d'arrêts consécutifs à valeur identique (4 arrêts identiques = 4 répétitions) ; « occupation constante » = même valeur à tous les arrêts de la séquence, sur au moins 5 arrêts ; NOT_TESTED si un arrêt de la séquence n'a pas la valeur de l'EVN (séquence incomplète) ou si le train a moins de 5 arrêts ; un zéro répété compte comme une valeur répétée ; synthèse Train = pire statut de ses EVN.
- **DQ-14** : origine / terminus = arrêts `Start` / `End` (comme DQ-03 et DQ-09) ; total des flux = Σ montées + Σ descentes de tous les arrêts ; un flux absent à un arrêt, une extrémité absente ou un total nul → NOT_TESTED (*lecture du flux absent assouplie le 2026-11-11, voir la section suivante*). Le point Dosto n'est pas intégré à la formule (voir [05_constats_qualite.md](../05_constats_qualite.md), C27).

## Précisions validées après l'atelier de validation par cas concrets (2026-11-11)

Le tableau et les textes ci-dessus restent la transcription de la capture (qui fait foi). Après examen des 84 cas de l'atelier, l'utilisateur a validé les lectures suivantes pour ce jeu de données (elles précisent le référentiel, elles ne le réécrivent pas) :

- **DQ-01** : l'occupation reconstruite est **cumulée depuis l'origine** : Σ (montées − descentes) des arrêts 1..n, et non plus partie de l'occupation mesurée de l'arrêt précédent. Tous les flux des arrêts 1..n et l'occupation de l'arrêt n doivent être présents, sinon NOT_TESTED. Le premier arrêt est donc testé. Seuil inchangé : MAX(5 ; 2 % × reconstruite).
- **DQ-03** : formule inchangée ; il est **confirmé** que l'occupation du terminus est mesurée avant les descentes (constat C30).
- **DQ-04** : capacité nulle ou absente **avec une occupation de 0** → NOT_TESTED (véhicule vide, rien à juger) ; avec une occupation > 0 → FAIL.
- **DQ-12** : au niveau Train, seuls les arrêts **avec donnée** sont contrôlés ; les arrêts sans aucune donnée relèvent de DQ-07.
- **DQ-14** : NOT_TESTED seulement si une extrémité ou son flux (descentes à l'origine, montées au terminus) manque ; le total des flux porte sur les arrêts qui ont leurs deux flux.

Restent à valider (proposés, **non appliqués**) : DQ-06, DQ-08, DQ-13 ; sans réponse : DQ-02, DQ-07, DQ-11.
