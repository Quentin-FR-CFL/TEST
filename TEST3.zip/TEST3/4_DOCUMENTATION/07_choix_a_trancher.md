# 07 – Choix à trancher et hypothèses à confirmer

Chaque ligne indique ce qui est fait par défaut dans les scripts, l'effet du choix et une
recommandation. Un choix tranché se traduit presque toujours par une modification du
catalogue (`audit.ReglesDQ`) ou d'un paramètre (`audit.ParametresDQ`), pas du code.

## A. Règles non tranchées

| # | Choix | Défaut dans les scripts | Éléments de décision | Recommandation |
|---|---|---|---|---|
| 1 | **DQ-06** : compter tous les capteurs (variante `ACTUELLE`) ou seulement les capteurs **extérieurs** (variante `EXTERIEUR_SEUL`) | `ACTUELLE` | `EXTERIEUR_SEUL` exclut les capteurs sans valeur (NOT_TESTED) et les EVN attendus jamais observés : à confirmer. Aujourd'hui 2 622 trains en FAIL sur 5 000 (DQ-06, maille Train). | Attendre la décision de FRANKS ; la variante est déjà codée |
| 2 | **DQ-08** : variante `ACTUELLE` ou `INTERMEDIAIRES_SI_EXTREMITE_VIDE` (n'examiner que l'écart intermédiaire si le 1er arrêt ou le dernier ne porte pas de flux) | `ACTUELLE` | 3 242 trains NOT_TESTED aujourd'hui sur 5 000 ; la variante en réduirait le nombre. Sens exact de « à 0 » (montées = 0 au 1er arrêt, descentes = 0 au dernier) à confirmer. | Idem |
| 3 | **DQ-13** : variante `ACTUELLE` ou `MOUVEMENT_NET` (répétition suspecte seulement avec mouvement net) | `ACTUELLE` | Constat [C28](../05_constats_qualite.md) : la plupart des FAIL actuels sont des zéros répétés. Seuils inchangés dans la variante, à confirmer. | Idem |
| 4 | **DQ-02** : en attente de la réponse du PO SIV sur l'origine de `EuropeanVehicleNumbersJson` (composition ARAMIS ?) | Calcul du moteur actuel | Si la composition n'est pas fiable, la règle mesure la qualité de la composition, pas celle du comptage. Comparaison des identités de véhicules prévue en V2 (`comptage_API.DQ_EVNAttendu` est déjà alimentée). | Garder `ATTEND_PO_SIV` ; ne pas exploiter la règle dans le score tant que la réponse manque (`ScoreWeight = 0`) |
| 5 | **DQ-07** et **DQ-11** : validées partiellement | Calcul actuel | DQ-11 n'a aucun FAIL ni WARNING sur le jeu de référence (Train : 4 825 PASS, 175 NOT_TESTED) ; elle ne peut rien détecter si l'arrêt est calculé comme la somme des véhicules. | Poser la question à l'exploitant ; poids 0 dans le score si confirmé |
| 6 | **DQ-01** : validée, mais sévère | Cumul depuis l'origine | 12 251 des 27 324 arrêts testés sont en FAIL (45 %). Une variante « ré-ancrée » a été proposée. | Garder la règle validée ; décider plus tard d'une variante si le métier juge le taux irréaliste |
| 7 | **DQ-14** : rattachement des trains Dosto (constat [C27](../05_constats_qualite.md)) | Calcul validé | Point de séparation des trains composés. | À confirmer |

## B. Structure V1 et extensions

| # | Choix | Défaut | Options | Recommandation |
|---|---|---|---|---|
| 8 | **Identifiant d'un arrêt dans `RunId`** : rang d'arrêt (`StopRank`) ou code gare (`StationCode`). Politique pour un doublon `(TrainNumber, date)` | Rang ; doublon = **contrôle bloquant** | Le code gare peut se répéter dans un trajet (aller-retour) ou être manquant ; le rang est toujours unique mais change si la séquence change. | Rang, avec `StationCode` en colonne de la ligne et dans `GrainValuesJson` |
| 9 | **Type d'`ExecutionId`** | `bigint` issu d'une séquence | `uniqueidentifier` si la V1 en DEV l'utilise déjà | S'aligner sur la V1 réelle en DEV |
| 10 | **Colonnes `[EXT]` de `LogsDQ`** : `GrainLevel`, `SourceKey`, `WindowDate`, `IsCurrent` | Ajoutées | Retirer et dériver du `RunId` : lectures plus lentes, purge et partition impossibles par date | Les garder ; elles sont nécessaires à la performance |
| 11 | **Catalogue** : une ligne par règle (maille principale + `DetailGrainsJson`) ou une ligne par couple règle x maille | Une ligne par règle | Une ligne par maille colle à la V1 mais multiplie les procédures ou les paramètres | Une ligne par règle |
| 12 | **Score** : table `ScoresDQ` ou statut `MEASURE` dans `LogsDQ` | `ScoresDQ` | `MEASURE` respecterait strictement la V1 mais mélange mesures et contrôles | `ScoresDQ` ; exposer aussi en `MEASURE` si la V1 l'exige |
| 13 | **`Severity` et `ScoreWeight`** | `Severity` vide ; poids égaux (1) | Poids métier non fournis ; pas de données internes supplémentaires à venir | Poids égaux tant que le métier ne les fournit pas |
| 14 | **Bloquer le flux sur `CRITICAL`** | Non implémenté | Le statut existe dans le journal mais aucune règle ne le produit aujourd'hui | Ne pas bloquer : le projet qualifie, il ne filtre pas |
| 15 | **Rapprochement du DDL V1** | DDL reconstitué à partir des schémas | Comparer avec les tables en DEV ; delta idempotent fourni (section 9 de `03_audit_catalogue_logs.sql`) | À faire avant installation |

## C. Exploitation et restitution

| # | Choix | Défaut | Recommandation |
|---|---|---|---|
| 16 | **Rétention de l'historique** non courant | 90 jours | À valider avec la gouvernance ; les résultats courants ne sont jamais purgés |
| 17 | **Page « Carte des gares »** dans Power BI | Facultative | Utile pour le ciblage ; moins riche que la carte actuelle. Décider après maquette. |
| 18 | **Option de restitution** (A import, B composite, C DirectQuery) | A | Voir 05 ; confirmer après mesure de la taille du modèle |
| 19 | **Partitionnement mensuel** | Non | À décider avec l'équipe DWH selon l'édition SQL Server et le volume |
| 20 | **Fenêtre par défaut** du pipeline | J-3 à J-1 | À adapter à la latence réelle du chargement SSIS |

## D. Hypothèses à confirmer (techniques)

| # | Hypothèse | Impact si fausse |
|---|---|---|
| 21 | SQL Server 2019 ou plus (`STRING_AGG`, `CONCAT_WS`, `OPENJSON`, columnstore, `THROW`) | `STRING_AGG` demande 2017 ; `CONCAT_WS` 2017 ; en dessous, réécriture à prévoir |
| 22 | Nom de la table source `comptage_API.Counting` et base `CFL_GOV` | Le nom de la base figure dans les `USE` des scripts |
| 23 | Colonnes de la table source identiques à l'extraction CSV du projet (`StopsJson`, `EuropeanVehicleNumbersJson`, totaux, etc.) | Adapter la vue `comptage_API.vw_DQ_SourceTrain` |
| 24 | Volumes de production (trains par jour, historique) : voir [01](01_architecture_cible.md) | Option de restitution et partitionnement |
| 25 | Capacité Power BI (Pro, Premium par utilisateur, capacité) : actualisation incrémentale et taille de modèle | Option A ou B |
| 26 | Passerelle de données si SQL Server n'est pas joignable depuis le service Power BI | Actualisation impossible sans elle |
| 27 | Signatures et codes de `audit.usp_StartNewBatchStep` / `usp_FinalizeBatchStep` (paramètres `@SourceName`, `@StepName`, `@Status` 0 succès / 1 échec) | Adapter les Exécuter SQL des packages (voir 08) |
| 28 | `PreviousStepsStatus` fixé à 0 dans les masters STA et DWH | Reprendre le calcul du master ODS si le statut précédent doit être propagé |
| 29 | Le parsing DQ éclate lui-même le JSON et ne réutilise pas `SIV_Split_Counting_Station_EVN` (schéma inconnu) | Doublon de traitement ; réutiliser le split si ses tables conviennent |
| 30 | Fenêtre J-10 à J-1 (`NbJoursFenetre` = 10) alignée sur celle d'ODS | Ajuster le paramètre de package |
| 31 | Une seule base `CFL_GOV` en DEV ; en QUAL avec des bases séparées, des synonymes sont à créer (non fournis) | Scripts à adapter |
| 32 | `.dtsx` générés sans Visual Studio, DTSID de `CM_STA` à substituer | Reconstruire à la main depuis les tableaux du guide 08 |

## E. Limites connues du dossier

- Les scripts SQL n'ont **jamais été exécutés** (aucun SQL Server disponible) : seule une
  vérification de syntaxe faible a été faite. La recette est prête mais non jouée.
- Le modèle Power BI n'a pas été construit.
- Le dossier dépend des règles et chiffres de la PR #12 ; une évolution du moteur Python
  doit être reportée dans `sql/` (et inversement), voir
  [../01_documentation_technique.md](../01_documentation_technique.md).
- Écarts attendus à la recette : arrondi du score (`ROUND` SQL arrondit la moitié vers le
  haut, Python arrondit au pair), égalités à exactement 2 % sur des flottants.
