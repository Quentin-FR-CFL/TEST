# 05 – Performance et alternative au cube SSAS

> **TEST3** : plus de vues minces ni d'agrégat `AggStatutRegle` ; import seul, détail limité par le paramètre `JoursDetail`. Voir [09_lineage_et_pages.md](09_lineage_et_pages.md).


Le cube SSAS n'est pas disponible. Il est retiré de la solution et remplacé par un
**modèle en étoile matérialisé dans SQL Server**, consommé par Power BI en **import**
avec actualisation incrémentale. Ce document justifie le choix et donne les seuils de
décision.

## 1. Ce que le cube apportait et son remplaçant

| Apport du cube | Remplaçant |
|---|---|
| Agrégats précalculés | Table `comptage_API.DQ_AggStatutRegle` (nombre d'objets par date, ligne, type, série, verdict, imputation, extérieur valide, maille, règle, statut), construite à chaque exécution |
| Stockage colonne compressé | Index **columnstore clusterisé** sur `LogsDQ`, `ScoresDQ`, `FaitResultat`, `FaitArret`, `AggStatutRegle` ; moteur VertiPaq de Power BI en import |
| Hiérarchies et relations | Modèle sémantique Power BI : relations et hiérarchies (06) |
| Mesures partagées | Mesures DAX dans le modèle Power BI (06) |
| Sécurité | Rôles SQL (`db_dq_lecteur`) et, si besoin, sécurité au niveau des lignes dans Power BI |

## 2. Principes de performance

1. **Parser une seule fois.** Le JSON est éclaté en tables typées ; aucune règle ne
   relit le JSON.
2. **Ensembliste.** Chaque règle = quelques requêtes sur toute la fenêtre. Pas de curseur,
   pas de boucle par train.
3. **Fenêtre glissante.** Seule la fenêtre (J-3 à J-1 par défaut) est recalculée ; le
   modèle `comptage_API.DQ_*` est reconstruit sur cette fenêtre dans **une transaction** (suppression de
   la fenêtre puis insertion), sans reconstruire l'historique.
4. **Columnstore** pour les tables de faits : compression de l'ordre de 5 à 10 fois
   (ordre de grandeur usuel, à mesurer sur ce jeu), lecture par groupes de lignes,
   `AggStatutRegle` pour les pages de synthèse.
5. **Dimension large `DimTrain`** (14 statuts en colonnes) : filtres et listes de trains
   sans jointure sur les faits.
6. **Vues minces** `comptage_API.vw_DQ_*` : `SELECT *` sur les tables, pour que Power BI reçoive le
   *query folding* complet et que le schéma physique puisse évoluer.
7. **Isolation par snapshot** pour lire pendant le rafraîchissement.

## 3. Trois options de restitution

| Option | Principe | Avantages | Limites | Quand la choisir |
|---|---|---|---|---|
| **A. Import + actualisation incrémentale** (recommandée) | Power BI importe `comptage_API.vw_DQ_*`, partition par date de circulation (`RangeStart`, `RangeEnd`) | Interactions les plus rapides, hors ligne côté base, pas de charge sur SQL à chaque clic | Latence = fréquence d'actualisation ; taille du modèle limitée par la licence | Volume de l'ordre du jeu actuel et quelques années d'historique |
| **B. Composite avec agrégats** | Table de détail (`FaitResultat`) en DirectQuery, `AggStatutRegle` en import et déclarée comme agrégat | Pages de synthèse en import, drill-down jusqu'au détail à la demande | Plus complexe, charge sur SQL pour le détail ; le DirectQuery exige de bons index columnstore | Historique long, détail trop volumineux pour l'import |
| **C. DirectQuery complet** | Tout en direct sur `comptage_API.DQ_*` | Donnée à la minute | Le plus lent, charge SQL à chaque interaction | Seulement si l'exigence de fraîcheur l'impose |

**Recommandation** : option A. Le jeu de référence (1,27 million de lignes de journal par
exécution complète, voir 01) tient largement dans un modèle importé ; passer à B si
l'historique conservé dépasse plusieurs dizaines de millions de lignes de faits
(seuil indicatif, à confirmer par mesure sur la capacité Power BI disponible).

## 4. Partitionnement et rétention côté SQL

- Aujourd'hui : pas de partitionnement. La purge par lots (`usp_DQ_Purger`) suffit tant
  que le journal reste de l'ordre de quelques dizaines de millions de lignes.
- Au-delà, partitionner `LogsDQ` et `comptage_API.DQ_Fait*` **par mois** sur `WindowDate` /
  `DateCirculation` (fonction et schéma de partition), ce qui permet de purger et de
  reconstruire par partition (`TRUNCATE … WITH (PARTITIONS …)`). À décider avec l'équipe
  DWH (édition SQL Server et groupes de fichiers, voir 07).

## 5. Mesures à faire avant mise en service

| Mesure | Comment | Objectif |
|---|---|---|
| Durée du pipeline sur la fenêtre complète d'août 2026 | `audit.ExecutionsRegleDQ.DureeMs` par règle | Repérer les règles lentes (probablement DQ-13 et DQ-01) |
| Taille du modèle importé | Power BI Desktop, analyseur de performances | Valider l'option A |
| Taux de compression des columnstores | `sys.dm_db_column_store_row_group_physical_stats` | Vérifier l'hypothèse de compression |
| Temps d'actualisation incrémentale d'un jour | Service Power BI | Dimensionner la planification |

Aucune de ces mesures n'a été faite : les ordres de grandeur ci-dessus sont des
hypothèses de conception.
