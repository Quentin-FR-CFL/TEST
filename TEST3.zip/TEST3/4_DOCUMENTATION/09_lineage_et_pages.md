> **Version TEST3 (structure réduite)** : 3 vues SQL seulement (`vw_DQ_SourceTrain`, `vw_DQ_TrainMotif`, `audit.vw_DQ_LogsEnrichis`), 2 packages SSIS (les étapes ci-dessous sont des tâches des deux masters), Power BI lit directement les tables `DQ_*`, `DQ_AggStatutRegle` supprimée. `FaitExecution` et `ParametresScore` sont construites dans Power Query depuis `audit.ExecutionsDQ`, `ExecutionsRegleDQ`, `ReglesDQ`, `ParametresDQ`.

# 09 – Lineage : qui alimente quoi, quand, et ce que lit chaque page Power BI

Ce document répond à : « quelle table sert à quoi, par quelle procédure et quel package SSIS elle est remplie, et quelles pages Power BI la lisent ». Il est relevé dans les scripts `sql/`, les packages `ssis/` (guide 08) et le projet `powerbi_dwh/`. **Rien n'a été exécuté sur un serveur** : le lineage est lu dans le code, pas observé.

## 1. Vue d'ensemble

```mermaid
flowchart LR
    subgraph ODS["ODS (existant, non modifié)"]
      C["comptage_API.Counting"]
    end
    subgraph STA["STA : SIV_MasterPackage_OdsToSta"]
      V["vw_DQ_SourceTrain"] --> G["DQ_StgTrain"]
      G --> P["DQ_Train · DQ_Arret · DQ_ArretEVN · DQ_EVNAttendu"]
      CAT["audit.ReglesDQ + ParametresDQ<br/>(chargés par 12_seed_catalogue.sql)"] --> R
      P --> R["14 règles → audit.LogsDQ"]
      R --> S["audit.ScoresDQ"]
      CAT --> S
    end
    subgraph DWH["DWH : SIV_MasterPackage_StaToDwh"]
      M["DQ_Dim* · DQ_FaitArret · DQ_FaitResultat"]
    end
    C --> V
    P --> M
    R --> M
    S --> M
    CAT --> M
    M --> PBI["Power BI : 8 pages + infobulles<br/>(lit les tables DQ_* directement)"]
```

## 2. Une exécution, dans l'ordre

| # | Où dans SSIS | Procédure SQL | Remplit |
|---|---|---|---|
| 0 | master STA : *Ouvrir l'exécution DQ* | `audit.usp_DQ_OuvrirExecution` | `audit.ExecutionsDQ` (une ligne par lancement) |
| 1 | master STA, tâche *Charger staging DQ* | `comptage_API.usp_DQ_ChargerStaging` | `DQ_StgTrain` (copie de la fenêtre) |
| 2 | master STA, tâche *Contrôler staging DQ* | `comptage_API.usp_DQ_ControlerStaging` (bloquant) | `audit.ControlesTechniquesDQ` |
| 3 | master STA, tâche *Parser JSON DQ* | `comptage_API.usp_DQ_ParserStaging` | `DQ_Train`, `DQ_Arret`, `DQ_ArretEVN`, `DQ_EVNAttendu` |
| 4 | master STA, tâche *Exécuter les règles DQ* | `audit.usp_DQ_ExecuterRegles` → 14 × `audit.usp_DQ_BR_DQnn_*` | `audit.LogsDQ`, `audit.ExecutionsRegleDQ` |
| 5 | master STA, tâche *Calculer le score DQ* | `audit.usp_DQ_CalculerScore` | `audit.ScoresDQ` |
| 6 | master STA : *Clore exécution DQ* | `audit.usp_DQ_CloreExecution` | statut de `audit.ExecutionsDQ` |
| 7 | master DWH, tâche *Rafraîchir le modèle DWH* | `comptage_API.usp_DQ_RafraichirModele` | `DQ_Dim*`, `DQ_FaitArret`, `DQ_FaitResultat` |
| 8 | master DWH, tâche *Contrôler le modèle DWH* | `comptage_API.usp_DQ_ControlerModele` | rien (contrôle : erreur 50060 / 50061 si écart) |

Hors SSIS, une seule fois à l'installation (puis à chaque changement de catalogue) : `sql/12_seed_catalogue.sql` remplit `audit.ReglesDQ` et `audit.ParametresDQ`. En SQL seul, `audit.usp_DQ_Pipeline_SIV_APC` enchaîne les étapes 0 à 7.

## 3. Lineage table par table

| Table ou vue | À quoi elle sert | Remplie par | Dans quel flux | Lit | Lue par |
|---|---|---|---|---|---|
| `comptage_API.Counting` | La donnée brute : une ligne par train, colonnes JSON | package ODS `SIV_api_Counting` | master ODS (existant, non modifié) | API de comptage | `vw_DQ_SourceTrain` |
| `comptage_API.vw_DQ_SourceTrain` | Lecture typée de la source (valeur illisible = NULL, jamais d'erreur) | vue | — | `Counting` | `usp_DQ_ChargerStaging` |
| `comptage_API.DQ_StgTrain` | Copie de la fenêtre traitée, JSON conservé ; vidée et rechargée à chaque exécution | `usp_DQ_ChargerStaging` | STA, tâche 1 (staging/parsing) | `vw_DQ_SourceTrain` | `usp_DQ_ControlerStaging`, `usp_DQ_ParserStaging` |
| `audit.ControlesTechniquesDQ` | Contrôles du staging (vide, doublon = bloquant ; JSON invalide = avertissement) | `usp_DQ_ControlerStaging` | STA, tâche 2 (staging/parsing) | `DQ_StgTrain` | diagnostic (pas Power BI) |
| `comptage_API.DQ_Train` | Un train : identité, totaux, nombre d'arrêts | `usp_DQ_ParserStaging` | STA, tâche 3 (staging/parsing) | `DQ_StgTrain` | règles, score, `DimTrain`, `DimGare` |
| `comptage_API.DQ_Arret` | Un arrêt listé dans `StopsJson` : gare, occupation, montées, descentes, flux cumulé | `usp_DQ_ParserStaging` | idem | `DQ_StgTrain` | règles, `FaitArret`, `FaitResultat`, `DimGare` |
| `comptage_API.DQ_ArretEVN` | Un véhicule à un arrêt : capteurs, états de lecture | `usp_DQ_ParserStaging` | idem | `DQ_StgTrain` | règles DQ-04, 05, 06, 12, 13 ; `FaitResultat` |
| `comptage_API.DQ_EVNAttendu` | Composition attendue du train (DQ-02, DQ-06) | `usp_DQ_ParserStaging` | idem | `DQ_StgTrain` | DQ-02, DQ-06 |
| `audit.ReglesDQ` | **Catalogue des 14 règles** : code, libellé, description, seuils, variante, choix validés, poids du score, activation | `sql/12_seed_catalogue.sql` (MERGE) | installation, hors SSIS | texte du fichier | `usp_DQ_ExecuterRegles`, `usp_DQ_CalculerScore`, `usp_DQ_RafraichirModele` (→ `DimRegle`) |
| `audit.ParametresDQ` | Paramètres : points par statut, seuils de verdict, règle d'imputation, fenêtre, rétention | `sql/12_seed_catalogue.sql` (n'écrase pas l'existant) | installation | texte du fichier | `usp_DQ_CalculerScore`, `usp_DQ_Pipeline_SIV_APC`, vues `…Recent`, `usp_DQ_Purger` |
| `audit.ExecutionsDQ` | Un lancement : fenêtre, statut, nombre de règles | `usp_DQ_OuvrirExecution` / `usp_DQ_CloreExecution` | master STA | — | `DQ_FaitExecution` |
| `audit.ExecutionsRegleDQ` | Une règle par exécution : durée, erreur technique | `usp_DQ_ExecuterRegles` | STA, tâche règles | `ReglesDQ` | `DQ_FaitExecution` |
| `audit.LogsDQ` | **Journal central** : une ligne = une règle sur un objet (train, arrêt, véhicule) | les 14 `usp_DQ_BR_*` via `usp_DQ_EcrireResultats` | STA, tâche règles | `DQ_Train`, `DQ_Arret`, `DQ_ArretEVN`, `ReglesDQ` | `usp_DQ_CalculerScore`, `usp_DQ_RafraichirModele` |
| `audit.ScoresDQ` | Score, couverture, verdict, imputation par train et par arrêt | `usp_DQ_CalculerScore` | STA, tâche score | `LogsDQ`, `ReglesDQ.ScoreWeight`, `ParametresDQ`, `DQ_Train` | `usp_DQ_RafraichirModele` |
| `comptage_API.DQ_DimDate` | Calendrier de la fenêtre | `usp_DQ_RafraichirModele` | DWH, tâche modèle | — | `DQ_DimDate` |
| `comptage_API.DQ_DimStatut`, `DQ_DimGrain` | Statuts (ordre, couleur) et mailles (Train, Arrêt, Véhicule) : données de référence fixes | `sql/09_tables_restitution.sql` (MERGE) | installation | texte du fichier | `DQ_DimStatut`, `DQ_DimGrain` |
| `comptage_API.DQ_DimRegle` | Les règles telles qu'affichées (libellé, description « Calcul », choix validés, poids) | `usp_DQ_RafraichirModele` | DWH | `audit.ReglesDQ` | `DQ_DimRegle` |
| `comptage_API.DQ_DimGare` | Un code gare et son nom le plus fréquent | `usp_DQ_RafraichirModele` | DWH | `DQ_Arret` | `DQ_DimGare` |
| `comptage_API.DQ_DimTrain` | Un train avec ses 14 statuts en colonnes, score, verdict, imputation | `usp_DQ_RafraichirModele` | DWH | `DQ_Train`, `audit.LogsDQ` (niveau train), `audit.ScoresDQ` | `DQ_DimTrain` |
| `comptage_API.DQ_FaitArret` | Un arrêt : occupation, flux, score de l'arrêt | `usp_DQ_RafraichirModele` | DWH | `DQ_Arret`, `audit.ScoresDQ` (niveau arrêt), `audit.LogsDQ` | `DQ_FaitArret`, `DQ_FaitArretRecent` |
| `comptage_API.DQ_FaitResultat` | Une règle sur un objet, format long (détail d'un train, statuts par règle) | `usp_DQ_RafraichirModele` | DWH | `audit.LogsDQ`, `DQ_DimStatut`, `DQ_Arret`, `DQ_ArretEVN` | `DQ_FaitResultat`, `DQ_FaitResultatRecent` |

## 4. Le chemin de la description des règles

Tu demandais d'où vient la description affichée pour chaque règle :

1. Le **texte métier** est dans le référentiel (`docs/referentiel/regles_dq_metier.md`, transcription de la capture).
2. `sql/12_seed_catalogue.sql` contient, pour chaque règle, `RuleName`, `Description`, `ChoixValides`, les seuils et `StatutValidation`. Il les charge dans **`audit.ReglesDQ`** par un `MERGE` : relancé, il **met à jour** libellé, description et choix validés, mais **n'écrase jamais** `ParamsJson` (la variante choisie par le métier).
3. `usp_DQ_RafraichirModele` recopie ces colonnes dans **`DQ_DimRegle`** (`Description` devient `Calcul`) à chaque exécution du tâche *Rafraîchir le modèle DWH*.
4. Power BI lit `DQ_DimRegle` : la page « Règles appliquées » et l'infobulle « Infobulle - règle » affichent `Calcul` (« Ce qui est contrôlé ») et `ChoixValides` (« Choix retenu »).

Pour changer un texte : modifier `12_seed_catalogue.sql` (ou faire un `UPDATE audit.ReglesDQ`), puis lancer le master DWH et actualiser Power BI. Que le texte du fichier reprenne **mot pour mot** le référentiel : **à confirmer**.

## 5. Les pages Power BI

Sources et contenu relevés dans les visuels de `powerbi_dwh/` (jamais ouvert dans Power BI Desktop).

| Page | Tables lues | Ce qu'on y prend |
|---|---|---|
| Vue d'ensemble | `DimTrain`, `FaitResultat`, `DimRegle`, `DimStatut`, `DimGrain`, `DimDate` | nombre de trains, score moyen, % Bonne ; nombre d'objets et % FAIL par règle, statut et maille (segmenteur Train / Arrêt / Véhicule) |
| Score de confiance | `DimTrain`, `ParametresScore`, `DimDate` | score moyen, % Bonne / À surveiller / Mauvaise, histogramme par tranche de score, motif des arrêts manquants, paramètres du score |
| Complétude et imputation | `DimTrain`, `FaitArret`, `DimDate` | trains à imputer, taux DQ-12, part d'arrêts mesurés, % d'arrêts sans donnée par gare et par type d'arrêt |
| Capteurs DQ-06 | `DimTrain`, `FaitResultat`, `DimDate` | trains DQ-06 en FAIL, capteurs extérieurs valides, véhicules (EVN, série) en FAIL |
| Trains | `DimTrain`, `DimDate` | la liste des trains : numéro, date, origine, destination, arrêts, score, couverture, verdict, imputation ; point de départ du clic droit « Détail du train » |
| Détail du train (drill-through, masquée) | `DimTrain`, `FaitResultat`, `FaitArret`, `DimRegle`, `DimGrain` | pour le train choisi : statut, écart et motif d'échec par règle ; arrêts avec occupation / capacité et statuts DQ-01, 02, 04, 05, 06, 10, 11, 12 |
| Règles appliquées | `DimRegle`, `FaitResultat`, `DimTrain` | les 14 règles : calcul, choix retenus, statut de validation, poids ; % FAIL, % NOT_TESTED, couverture |
| Suivi des exécutions | `FaitExecution`, `DimTrain`, `DimDate` | exécutions, statut, durée par règle, règles en erreur, messages d'erreur |
| Infobulles (4, masquées) | `FaitArret`, `DimRegle`, `FaitResultat`, `DimTrain` | détail d'un arrêt, texte de la règle, répartition des statuts, résumé d'un groupe de trains |

**Attention à la fenêtre de détail.** `FaitResultat` et `FaitArret` sont chargées avec le paramètre Power Query `JoursDetail` (N derniers jours, 30 par défaut, filtre exécuté par SQL Server). Les pages **Vue d'ensemble** et **Règles appliquées** calculent leurs % FAIL sur `FaitResultat` alors que le nombre de trains vient de `DimTrain` (historique complet) : au-delà de N jours de données, ces deux pages ne portent plus sur la même période. Le jeu d'août 2026 (22 jours) tient dans les 30 jours. Pour éviter l'écart, soit monter `detail_jours_import`, soit faire lire ces mesures par `AggStatutRegle` (non fait, à décider).

## 6. À confirmer

- Ce lineage est lu dans le code : aucune exécution réelle.
- Concordance mot pour mot de `Description` avec le référentiel.
- Appels SSIS réels : les `.dtsx` n'ont jamais été ouverts dans SSDT.
