# 03 – Les 14 règles en T-SQL

Chaque règle est une procédure `audit.usp_DQ_BR_DQnn_*` (dossier
[`sql/regles/`](../../sql/regles/)), appelée par l'orchestrateur avec les mêmes
paramètres : `@SourceName`, `@RegleDQID`, `@ExecutionId`, `@DateDebut`, `@DateFin`.
La définition métier de référence reste
[../02_documentation_metier_regles.md](../02_documentation_metier_regles.md) et le
référentiel [../referentiel/regles_dq_metier.md](../referentiel/regles_dq_metier.md) ; ce
document décrit la traduction SQL.

## 1. Gabarit commun d'une procédure

1. Lire les seuils et paramètres dans `audit.ReglesDQ` (aucun seuil en dur).
2. Créer la table temporaire `#R` (structure commune : `GrainLevel`, `CountingId`,
   `Rang`, `VehIdx`, `Status`, `FailureReason`, `ObservedValue`, `ExpectedValue`,
   `AbsoluteGap`, `RelativeGap`).
3. Remplir `#R` par des requêtes ensemblistes sur `comptage_API.DQ_*`, une par maille.
4. Appeler `audit.usp_DQ_EcrireResultats`, qui :
   supprime les lignes de la même exécution et règle (rejeu dans l'exécution), passe les
   précédentes de la fenêtre à `IsCurrent = 0`, insère les trois mailles avec `RunId` et
   `GrainValuesJson`.
5. Pour les règles à synthèse, `audit.usp_DQ_SyntheseTrain` calcule le niveau Train =
   **pire statut** de ses détails (ordre : FAIL > WARNING > PASS > NOT_TESTED, voir
   ci-dessous), sans écrire deux fois la même logique.

Règle de synthèse : un train est `FAIL` si un détail est `FAIL`, sinon `WARNING` s'il
en existe un, sinon `PASS` si au moins un détail est `PASS`, sinon `NOT_TESTED`.

Extrait réel (DQ-03, maille Train, une seule requête pour toute la fenêtre ; le
terminus de chaque train est obtenu par `OUTER APPLY TOP (1)`, sans curseur) :

```sql
;WITH e AS (
    SELECT t.CountingId, x.Rang, x.HasData, x.Occ, x.Alighting, x.Capacity,
           Teste = CASE WHEN x.HasData = 1 AND x.Alighting IS NOT NULL AND x.Capacity > 0 THEN 1 ELSE 0 END,
           Taux  = CASE WHEN x.HasData = 1 AND x.Alighting IS NOT NULL AND x.Capacity > 0
                        THEN CAST(ABS(CAST(x.Occ AS bigint) - x.Alighting) AS decimal(19,6)) / x.Capacity END
    FROM comptage_API.DQ_Train AS t
    OUTER APPLY (SELECT TOP (1) a.Rang, a.HasData, a.Occ, a.Alighting, a.Capacity
                 FROM comptage_API.DQ_Arret AS a
                 WHERE a.CountingId = t.CountingId AND a.StopType = 'End'
                 ORDER BY a.Rang DESC) AS x
    WHERE t.CirculationDate BETWEEN @DateDebut AND @DateFin
)
INSERT #R (GrainLevel, CountingId, Rang, VehIdx, [Status], FailureReason, ObservedValue, ExpectedValue, AbsoluteGap, RelativeGap)
SELECT 1, e.CountingId, NULL, NULL,
       CASE WHEN e.Teste = 0 THEN 'NOT_TESTED' WHEN e.Taux <= @seuil THEN 'PASS' ELSE 'FAIL' END,
       CASE WHEN e.Rang IS NULL THEN 'PAS_DE_TERMINUS'
            WHEN e.HasData = 0 THEN 'TERMINUS_SANS_DONNEE'
            WHEN e.Alighting IS NULL THEN 'DESCENTES_ABSENTES'
            WHEN e.Capacity IS NULL OR e.Capacity <= 0 THEN 'CAPACITE_ABSENTE_OU_NULLE'
            WHEN e.Taux > @seuil THEN 'OCCUPATION_RESIDUELLE_AU_TERMINUS' END,
       (SELECT e.Occ AS occupation, e.Alighting AS descentes, e.Capacity AS capacite,
               CASE WHEN e.Teste = 1 THEN CAST(e.Taux * 100 AS decimal(9,2)) END AS taux_pct
        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
       CASE WHEN e.Teste = 1 THEN CAST(@seuil AS nvarchar(100)) END,
       CASE WHEN e.Teste = 1 THEN ABS(CAST(e.Occ AS decimal(19,6)) - e.Alighting) END,
       e.Taux
FROM e;

EXEC audit.usp_DQ_EcrireResultats @RegleDQID, @ExecutionId, @DateDebut, @DateFin;
```

## 2. Règles, décisions appliquées et procédures

| Règle | Procédure | Mailles | Décision appliquée (état au 2026-11-11) | Statut de validation |
|---|---|---|---|---|
| DQ-01 Cohérence flux / occupation | `usp_DQ_BR_DQ01_CoherenceFluxOccupation` | Arrêt + Train | Reconstruction **cumulée depuis l'origine** (`CumulFlux`) ; seuil = MAX(5 voyageurs ; 2 % de la reconstruite) ; NOT_TESTED si un flux manque sur 1..n | VALIDEE |
| DQ-02 Complétude EVN | `usp_DQ_BR_DQ02_CompletudeEVN` | Arrêt + Train | Calcul du moteur actuel (nombre d'EVN observés = attendus, attendu entre 1 et 9) ; identité des véhicules prévue en V2 | ATTEND_PO_SIV |
| DQ-03 Remise à zéro au terminus | `usp_DQ_BR_DQ03_RemiseZeroTerminus` | Train | Occupation du terminus mesurée **avant les descentes** (constat [C30](../05_constats_qualite.md)) ; seuil 2 % de la capacité | VALIDEE |
| DQ-04 Charge critique | `usp_DQ_BR_DQ04_ChargeCritiqueEVN` | Véhicule, Arrêt, Train | **Capacité 0 et occupation 0 → NOT_TESTED** (option A) ; capacité 0 et occupation > 0 → FAIL ; PASS ≤ 200 %, WARNING ≤ 250 % | VALIDEE |
| DQ-05 État du matériel | `usp_DQ_BR_DQ05_EtatMateriel` | Train, Arrêt, Véhicule | `IsDegraded` = 1 → FAIL ; le véhicule hérite de l'arrêt | VALIDEE (sens de « dégradé » à demander à l'exploitant) |
| DQ-06 Disponibilité des capteurs | `usp_DQ_BR_DQ06_DisponibiliteCapteurs` | Véhicule, Arrêt, Train | Variante `ACTUELLE` par défaut ; variante `EXTERIEUR_SEUL` codée | **A_TRANCHER** |
| DQ-07 Complétude de la séquence d'arrêts | `usp_DQ_BR_DQ07_SequenceArrets` | Train | Arrêts mesurés = arrêts attendus ; motif des arrêts manquants dans `ObservedValue` | PARTIELLE |
| DQ-08 Équilibre des flux | `usp_DQ_BR_DQ08_EquilibreFlux` | Train | Variante `ACTUELLE` par défaut ; variante `INTERMEDIAIRES_SI_EXTREMITE_VIDE` codée | **A_TRANCHER** |
| DQ-09 Remise à zéro à l'origine | `usp_DQ_BR_DQ09_RemiseZeroOrigine` | Train | Écart / capacité ≤ 2 % ; occupation 0 avec montées → FAIL | VALIDEE |
| DQ-10 Occupation reconstruite non négative | `usp_DQ_BR_DQ10_OccupationNonNegative` | Arrêt + Train | Même cumul que DQ-01 ; PASS ≥ 0, WARNING ≥ -3, FAIL en dessous | VALIDEE |
| DQ-11 Cohérence entre les mailles | `usp_DQ_BR_DQ11_CoherenceMailles` | Arrêt + Train | Arrêt vs somme des véhicules (occupation, montées, descentes) ; PASS ≤ 1 %, WARNING ≤ 5 % | PARTIELLE (règle possiblement sans effet si l'arrêt est la somme des véhicules, à discuter avec l'exploitant) |
| DQ-12 Valeurs exploitables | `usp_DQ_BR_DQ12_ValeursExploitables` | Véhicule, Arrêt, Train | Taux calculé sur les **arrêts avec donnée seulement** ; PASS 100 %, WARNING ≥ 98 % | VALIDEE |
| DQ-13 Capteur figé | `usp_DQ_BR_DQ13_CapteurFige` | Véhicule + Train | Variante `ACTUELLE` par défaut ; variante `MOUVEMENT_NET` codée ; `min_arrets` = 5 | **A_TRANCHER** |
| DQ-14 Flux aux extrémités | `usp_DQ_BR_DQ14_FluxExtremites` | Train | **NOT_TESTED seulement si une extrémité ou son flux est absent** ; total = arrêts ayant leurs deux flux ; WARNING ≤ 2 % | VALIDEE (rattachement des trains Dosto, constat [C27](../05_constats_qualite.md), à confirmer) |

### Traductions SQL notables

| Besoin | Technique T-SQL |
|---|---|
| Éclater le JSON une seule fois | `OPENJSON … WITH (…)` dans `comptage_API.usp_DQ_ParserStaging`, avec `comptage_API.fn_DQ_Val` (valeur + état de lecture) |
| Cumul flux depuis l'origine (DQ-01, DQ-10) | `SUM(Boarding - Alighting) OVER (PARTITION BY CountingId ORDER BY Rang ROWS UNBOUNDED PRECEDING)`, `NULL` si un flux manque (comptage des états d'absence sur la même fenêtre) |
| Origine et terminus | `OUTER APPLY (SELECT TOP (1) … ORDER BY Rang)` : premier `Start`, dernier `End` |
| Pire statut d'un train | Agrégat avec `MAX` d'un rang numérique de statut (`usp_DQ_SyntheseTrain`) |
| Plus longue suite d'occupations identiques (DQ-13) | Technique « gaps and islands » : `ROW_NUMBER` moins `ROW_NUMBER` par valeur, puis `COUNT` par île |
| Statut de capteur | `comptage_API.fn_DQ_EtatCapteur` (0 sans donnée, 1 valide à 100 %, 2 invalide) |
| Motif des arrêts manquants | Chaîne de motif par train (`D` mesuré, `.` sans donnée) via `STRING_AGG`, puis `CHARINDEX` (vue `comptage_API.vw_DQ_TrainMotif`) |
| Variantes de règles | `JSON_VALUE(ParamsJson, '$.variante')`, procédure inchangée, bascule par `UPDATE` du catalogue |

## 3. Variantes non tranchées (DQ-06, DQ-08, DQ-13)

Les trois règles sont codées avec **les deux calculs**. Par défaut c'est le calcul du
moteur actuel (`ACTUELLE`), pour que la recette soit comparable aux chiffres de
référence. Pour basculer après décision :

```sql
UPDATE audit.ReglesDQ
SET ParamsJson = JSON_MODIFY(ParamsJson, '$.variante', N'MOUVEMENT_NET'),
    StatutValidation = N'VALIDEE', RuleVersion = N'1.1'
WHERE SourceName = N'SIV_APC' AND RuleCode = N'DQ-13';
```

Le trigger du catalogue conserve l'ancienne ligne dans `ReglesDQ_Historique`. Le détail
des variantes et la recommandation sont dans [07_choix_a_trancher.md](07_choix_a_trancher.md).

## 4. Chiffres attendus (recette)

Statuts attendus par règle et par maille avec les décisions ci-dessus et les variantes
`ACTUELLE`, sur l'extraction d'août 2026 (5 000 trains). Ce sont les sorties du moteur
Python de la PR #12, reprises dans
[`sql/tests/recette_chiffres_cles.sql`](../../sql/tests/recette_chiffres_cles.sql) :
la recette SQL les compare aux résultats du journal. Un écart est à expliquer avant la
mise en service.

| Règle | Maille | PASS | WARNING | FAIL | NOT_TESTED |
|---|---|---:|---:|---:|---:|
| DQ-01 | Train | 1 029 | 0 | 2 047 | 1 924 |
| DQ-01 | Arrêt | 15 073 | 0 | 12 251 | 17 625 |
| DQ-02 | Train | 4 517 | 0 | 483 | 0 |
| DQ-02 | Arrêt | 36 905 | 0 | 3 172 | 4 872 |
| DQ-03 | Train | 1 173 | 0 | 1 183 | 2 644 |
| DQ-04 | Train | 4 996 | 3 | 0 | 1 |
| DQ-04 | Arrêt | 39 319 | 0 | 0 | 5 630 |
| DQ-04 | Véhicule | 164 021 | 19 | 0 | 3 513 |
| DQ-05 | Train | 2 511 | 0 | 2 489 | 0 |
| DQ-05 | Arrêt | 33 872 | 0 | 11 077 | 0 |
| DQ-05 | Véhicule | 120 764 | 0 | 46 789 | 0 |
| DQ-06 | Train | 2 074 | 297 | 2 622 | 7 |
| DQ-06 | Arrêt | 25 347 | 2 997 | 10 984 | 5 621 |
| DQ-06 | Véhicule | 122 098 | 39 290 | 483 | 5 682 |
| DQ-07 | Train | 2 594 | 0 | 2 406 | 0 |
| DQ-08 | Train | 390 | 0 | 1 368 | 3 242 |
| DQ-09 | Train | 1 934 | 0 | 324 | 2 742 |
| DQ-10 | Train | 948 | 242 | 679 | 3 131 |
| DQ-10 | Arrêt | 23 915 | 1 004 | 2 405 | 17 625 |
| DQ-11 | Train | 4 825 | 0 | 0 | 175 |
| DQ-11 | Arrêt | 37 257 | 0 | 0 | 7 692 |
| DQ-12 | Train | 4 248 | 0 | 752 | 0 |
| DQ-12 | Arrêt | 39 314 | 0 | 5 635 | 0 |
| DQ-12 | Véhicule | 161 829 | 0 | 5 724 | 0 |
| DQ-13 | Train | 473 | 507 | 1 516 | 2 504 |
| DQ-13 | Véhicule | 50 042 | 28 849 | 32 539 | 56 123 |
| DQ-14 | Train | 1 907 | 2 | 4 | 3 087 |

Écarts possibles et connus : arrondi du score (`ROUND` SQL arrondit la moitié vers le haut,
Python arrondit au pair : écart d'au plus 0,1 point, non testé) ; égalités à exactement 2 %
sur des flottants (à surveiller à la recette).
