# TEST3 : mise en place pas à pas (SQL Server, SSIS STA et DWH, Power BI)

> **Rien n'a été testé** : ni SQL Server, ni SSIS (SSDT), ni Power BI Desktop. Le SQL et les `.dtsx` ont été écrits et vérifiés à la lecture seulement, les packages sont du XML valide mais jamais ouverts dans Visual Studio. Fais tout en **DEV** d'abord. Chaque étape a un **« Je crée »** et un **« Je vérifie »** : si la vérification échoue, ne passe pas à l'étape suivante.

**Ce que TEST3 change par rapport à l'ancien pack** : 3 vues SQL au lieu de 20, 2 packages SSIS au lieu de 7, plus de table `DQ_AggStatutRegle`, Power BI lit directement les tables `DQ_*`. Les 14 règles, le score, les poids (`ReglesDQ.ScoreWeight`), l'imputation (`ParametresDQ`), le rejeu sans doublon et les 8 pages ne changent pas.

```
Counting (ODS, intouché)
   └─ SSIS STA : SIV_MasterPackage_OdsToSta   → staging, JSON, 14 règles, score   (tables audit.* et DQ_*)
        └─ SSIS DWH : SIV_MasterPackage_StaToDwh → modèle en étoile DQ_Dim* / DQ_Fait*, contrôle
             └─ Power BI (.pbix, import) : lit les tables DQ_* directement
```

Contenu du dossier : `1_SQL` (script unique + recette), `2_SSIS` (les 2 masters à mettre à la place des existants), `3_POWER_BI` (projet `.pbip` + kit texte), `4_DOCUMENTATION`.

---

## PARTIE 1 : SQL Server

### 1.1 Prérequis
- Base `CFL_GOV` existante, avec `comptage_API.Counting` alimentée par le flux ODS (ne jamais la modifier).
- Un compte qui peut créer schémas, tables, procédures, vues et rôles dans `CFL_GOV`.

**Je vérifie** (SSMS) :
```sql
USE CFL_GOV;
SELECT COUNT(*) AS NbLignesCounting FROM comptage_API.Counting;   -- > 0
```

### 1.2 Installer : une seule page
Fichier : `1_SQL/DQ_script_unique.sql`.
1. Ouvre-le dans SSMS, connecté à `CFL_GOV`.
2. Exécute-le **en entier** (F5). Il est rejouable (`CREATE OR ALTER`, `IF NOT EXISTS`, `MERGE`) : en cas d'erreur, corrige et relance.
3. Il supprime aussi les anciens objets du pack précédent (`DROP … IF EXISTS` : les vues `vw_DQ_Dim*`, `vw_DQ_Fait*`, `…Recent`, `vw_DQ_ParametresScore`, `vw_DQ_AggStatutRegle`, et la table `DQ_AggStatutRegle`). Les tables `audit.*` existantes et leurs données sont conservées.

**Je crée** (rien à la main : le script crée tout) : schémas `audit` et `comptage_API`, rôles `db_dq_executeur` et `db_dq_lecteur`, tables de staging et de parsing, catalogue (`ReglesDQ`, `ParametresDQ`), journal (`LogsDQ`, `ScoresDQ`, `ExecutionsDQ`, `ExecutionsRegleDQ`, `ControlesTechniquesDQ`), les 14 procédures de règles, l'orchestrateur, le score, le modèle `DQ_Dim*` / `DQ_Fait*`, 3 vues, la maintenance.

**Je vérifie** :
```sql
SELECT type_desc, COUNT(*) AS N
FROM sys.objects
WHERE schema_id IN (SCHEMA_ID('audit'), SCHEMA_ID('comptage_API'))
  AND type IN ('U','V','P','FN','IF','TF')
GROUP BY type_desc ORDER BY type_desc;
-- Comptés dans le script : 21 tables (+ Counting, existante), 3 vues, 28 procédures, 3 fonctions.
-- Écart de 1-2 sur les procédures possible (comptage fait dans le fichier, pas sur un serveur) : à confirmer.

SELECT name FROM sys.views WHERE schema_id IN (SCHEMA_ID('audit'), SCHEMA_ID('comptage_API'));
-- Attendu exactement : vw_DQ_SourceTrain, vw_DQ_TrainMotif, vw_DQ_LogsEnrichis

SELECT COUNT(*) AS Regles FROM audit.ReglesDQ;                          -- 14
SELECT RuleCode, ScoreWeight FROM audit.ReglesDQ ORDER BY RuleCode;      -- poids égaux
SELECT * FROM audit.ParametresDQ;                                        -- points par statut, seuils, imputation, fenêtre
SELECT TOP (5) * FROM comptage_API.vw_DQ_SourceTrain;                    -- lecture typée de Counting
```
Si `vw_DQ_SourceTrain` échoue (colonne inconnue) : la source n'a pas les colonnes attendues. Adapte la vue (`sql/01_source_et_staging.sql`, vue en tête) puis relance le script.

### 1.3 Premier passage en SQL seul (avant SSIS)
```sql
EXEC audit.usp_DQ_Pipeline_SIV_APC @DateDebut = '2026-08-04', @DateFin = '2026-08-26';  -- adapte la fenêtre à tes données
```
**Je vérifie** :
```sql
SELECT TOP (3) ExecutionId, Statut, DateDebut, DateFin, NbReglesEnErreur, Message FROM audit.ExecutionsDQ ORDER BY ExecutionId DESC;  -- Succes
SELECT COUNT(*) FROM comptage_API.DQ_Train;                -- = nombre de trains de la fenêtre
SELECT RuleCode, [Status], COUNT_BIG(*) N FROM audit.vw_DQ_LogsEnrichis WHERE IsCurrent = 1 GROUP BY RuleCode,[Status] ORDER BY 1,2;  -- 14 règles
SELECT COUNT(*) FROM audit.ScoresDQ;
SELECT COUNT(*) AS Trains FROM comptage_API.DQ_DimTrain;   -- = DQ_Train
SELECT TOP (10) TrainNumber, Score, Verdict, Imputation FROM comptage_API.DQ_DimTrain;
```
Rejeu : relance la même commande, les comptes courants (`IsCurrent = 1`) restent identiques, l'ancienne exécution passe à `IsCurrent = 0` (historique conservé).

Recette sur le jeu d'août 2026 (5 000 trains, 4 au 26 août) : exécute `1_SQL/recette_chiffres_cles.sql`. Un `ECART` est à expliquer avant mise en service. Elle n'a de sens que sur ce jeu.

### 1.4 Droits
- `db_dq_executeur` : compte de l'agent SQL / de SSIS (`EXECUTE` sur les 2 schémas, lecture de la source).
- `db_dq_lecteur` : compte Power BI (`SELECT` sur les seules tables listées dans la section 10 du script (fin de la partie restitution), jamais tout le schéma ; `audit.LogsDQ` n'en fait pas partie).
```sql
ALTER ROLE db_dq_executeur ADD MEMBER [TON_COMPTE_SSIS];
ALTER ROLE db_dq_lecteur   ADD MEMBER [TON_COMPTE_POWERBI];
```
**Je vérifie** : connecté avec le compte Power BI, `SELECT TOP 1 * FROM comptage_API.DQ_DimTrain;` répond ; `SELECT TOP 1 * FROM audit.LogsDQ;` est refusé (voulu).

### 1.5 Modifier le score sans toucher à Power BI
```sql
UPDATE audit.ReglesDQ SET ScoreWeight = 2 WHERE RuleCode = N'DQ-01';     -- poids d'une règle
SELECT * FROM audit.ParametresDQ;  UPDATE audit.ParametresDQ SET ... ;     -- seuils, imputation
```
Puis relancer le pipeline (SSIS ou SQL) et actualiser Power BI.

---

## PARTIE 2 : SSIS (2 packages, tu remplaces seulement ce qui existe)

Dossier fourni :
```
2_SSIS/CFL_STA_COMPTAGE/SIV_MasterPackage_OdsToSta.dtsx
2_SSIS/CFL_DWH_COMPTAGE/SIV_MasterPackage_StaToDwh.dtsx
2_SSIS/generer_packages.py      (pour les régénérer avec tes GUID, optionnel)
```
Il n'y a **plus** de package enfant : les 5 anciens (`SIV_Dq_Counting_Parsing`, `_Regles`, `_Score`, `SIV_Dwh_Counting_Modele`, `_Controle`) sont à **supprimer** des projets. Le package existant `SIV_Split_Counting_Station_EVN` reste appelé tel quel dans le master STA.

### 2.0 Avant de commencer : le GUID de la connexion CM_STA
Les `.dtsx` fournis contiennent un GUID nul `{00000000-0000-0000-0000-000000000000}` à la place du DTSID de ton gestionnaire de connexion projet `CM_STA`.
1. Dans chaque projet, ouvre `CM_STA.conmgr` dans un éditeur de texte et copie la valeur de `DTS:DTSID` (accolades comprises).
2. **Option A** : dans chaque `.dtsx`, remplace toutes les occurrences de `{00000000-0000-0000-0000-000000000000}` par ce GUID (rechercher/remplacer).
   **Option B** : `cd 2_SSIS && python generer_packages.py --sta-cm-sta {GUID_STA} --dwh-cm-sta {GUID_DWH}` (Python 3, rien à installer ; régénère les 2 fichiers au bon endroit).
3. Le projet DWH a son propre `CM_STA` (GUID différent du projet STA).

**Je vérifie** : le fichier ne contient plus de GUID nul (recherche dans l'éditeur).

### 2.1 STA : `CFL_STA_COMPTAGE`
1. Sauvegarde le projet (copie du dossier) pour pouvoir revenir en arrière.
2. Dans Visual Studio (SSDT), projet `CFL_STA_COMPTAGE` : supprime du projet les packages `SIV_Dq_Counting_Parsing`, `SIV_Dq_Counting_Regles`, `SIV_Dq_Counting_Score` (clic droit > Exclure du projet puis supprimer le fichier).
3. Remplace le fichier `SIV_MasterPackage_OdsToSta.dtsx` du dossier du projet par celui de `2_SSIS`, puis rouvre le projet (ou *Recharger*).
4. Ouvre le master : **Je vérifie** le contenu :
   - Paramètres : `SourceName` (`SIV_APC`), `NbJoursFenetre` (10, à confirmer).
   - Variables : `DateDebut`, `DateFin` (texte `yyyy-MM-dd`), `ExecutionId`, `StepName`, `PreviousStepsStatus`.
   - Tâches dans l'ordre : *Initialiser batch Sta* → *Fenêtre de dates* (calcul de la date de fin J-1 et de début J-n) → *Ouvrir l'exécution DQ* → conteneur *Traitements Sta* : `Exécuter SIV_Split_Counting_Station_EVN` (existant) → *Charger staging DQ* → *Contrôler staging DQ* → *Parser JSON DQ* → *Exécuter les règles DQ* → *Calculer le score DQ* → *Clore exécution DQ* (Succeeded / Failed) et *Finaliser batch* (Succeeded / Failed).
   - Chaque tâche SQL utilise la connexion `CM_STA` (aucune erreur rouge, pas d'avertissement de connexion introuvable).
5. **Je compare avec le master ODS existant** : les tâches d'audit de batch (`usp_StartNewBatchStep` / `usp_FinalizeBatchStep`) sont des **suppositions** : aligne leur nom et leurs paramètres sur ceux de ton master ODS si différent.
6. Le calcul de `DateDebut` / `DateFin` à partir de `NbJoursFenetre` (J-n à J-1) est fait dans le conteneur *Fenêtre de dates* : vérifie qu'il donne des dates sensées.

**Je vérifie en exécutant** (DEV) : lance le master seul (clic droit > Exécuter le package). Puis :
```sql
SELECT TOP (3) ExecutionId, Statut, DateDebut, DateFin FROM audit.ExecutionsDQ ORDER BY ExecutionId DESC;     -- Succes
SELECT RegleDQID, Statut, DureeMs, ErrorMessage FROM audit.ExecutionsRegleDQ WHERE ExecutionId = (SELECT MAX(ExecutionId) FROM audit.ExecutionsDQ);  -- 14 lignes, pas d'erreur
```
Une règle en FAIL (métier) n'est **pas** une erreur SSIS. Une erreur technique fait échouer la tâche et clôt l'exécution en échec.

### 2.2 DWH : `CFL_DWH_COMPTAGE`
1. Sauvegarde du projet.
2. Supprime les packages `SIV_Dwh_Counting_Modele` et `SIV_Dwh_Counting_Controle`.
3. Remplace `SIV_MasterPackage_StaToDwh.dtsx` par celui de `2_SSIS` (avec le GUID du CM_STA **du projet DWH**).
4. **Je vérifie** : conteneur *Traitements Dwh* : *Rafraîchir le modèle DWH* (`usp_DQ_RafraichirModele`) → *Contrôler le modèle DWH* (`usp_DQ_ControlerModele`).

**Je vérifie en exécutant** :
```sql
SELECT 'DimTrain' T, COUNT(*) N FROM comptage_API.DQ_DimTrain UNION ALL
SELECT 'FaitResultat', COUNT(*) FROM comptage_API.DQ_FaitResultat UNION ALL
SELECT 'FaitArret', COUNT(*) FROM comptage_API.DQ_FaitArret UNION ALL
SELECT 'DimRegle', COUNT(*) FROM comptage_API.DQ_DimRegle;       -- DimRegle = 14, les autres > 0
```
Erreur 50060 / 50061 au contrôle : le modèle ne correspond pas au parsing ou au journal : relance d'abord le master STA puis le DWH.

### 2.3 Enchaînement et déploiement
- Ordre : ODS (existant) → master STA → master DWH. Dans ton job SQL Agent, ajoute les 2 étapes après le job ODS ; la 2e ne part que si la 1re réussit.
- **Retour arrière** : remets les copies des projets sauvegardées ; côté SQL, l'ancien script ne se remet pas tout seul (les anciennes vues ont été supprimées) : garde l'ancien `DQ_script_unique.sql` du pack précédent.

---

## PARTIE 3 : Power BI (.pbix, import)

Dossier : `3_POWER_BI/powerbi_dwh/DQ_DWH.pbip` (modèle + 8 pages), et `3_POWER_BI/kit_report_server/` en secours.

**Pourquoi cette étape** : ton Power BI Report Server (mai 2026) ne publie que des `.pbix`, et son Desktop n'ouvre pas les `.pbip`. Le `.pbip` est donc ouvert avec un **Power BI Desktop classique** (celui du PC où tu peux enregistrer en `.pbix`), puis enregistré en `.pbix`. Je n'ai pas pu produire le `.pbix` moi-même.

### 3.1 Ouvrir le projet
1. Power BI Desktop > Fichier > Options et paramètres > Options > **Fonctionnalités en préversion** : coche *Enregistrer au format de projet Power BI (.pbip)* et *Format TMDL du modèle sémantique* (et *PBIR* si proposé). Redémarre Desktop.
2. Fichier > Ouvrir > `powerbi_dwh/DQ_DWH.pbip` (garde les dossiers `DQ_DWH.SemanticModel` et `DQ_DWH.Report` à côté).
3. S'il y a une erreur d'ouverture (jamais testé dans Desktop) : note le message, passe au 3.5 (kit).

### 3.2 Les 3 paramètres
Accueil > Transformer les données > Gérer les paramètres :
- `Serveur` : ton serveur SQL (nom exact).
- `BaseDeDonnees` : `CFL_GOV`.
- `JoursDetail` : `30` (nombre de jours de **détail arrêt / véhicule**, calculé depuis la dernière date de circulation de `DQ_DimTrain` ; le filtre est exécuté par SQL Server).
Fermer et appliquer. Identifiants : Windows ou SQL, avec le compte qui a `db_dq_lecteur`. Mode **Importer** (aucun DirectQuery, pas de mode composite).

### 3.3 Vérifier le modèle
Je vérifie :
- Les tables chargées : `DimDate`, `DimTrain`, `DimRegle`, `DimStatut`, `DimGrain`, `DimGare`, `FaitResultat`, `FaitArret`, `FaitExecution`, `ParametresScore` (10 ; **pas** de `AggStatutRegle`).
- Vue Modèle : les relations sont là (voir `kit_report_server/relations.txt`) et `DimDate` est marquée table de dates.
- Chaque page affiche des données : Vue d'ensemble, Score de confiance, Complétude et imputation, Capteurs DQ-06, Trains, Règles appliquées, Suivi des exécutions ; les pages masquées (Détail du train, 4 infobulles) fonctionnent par clic droit > *Détail du train* sur un train de la page Trains.
- Les 8 filtres actuels sont présents.
- Les totaux de trains de la page Vue d'ensemble = `SELECT COUNT(*) FROM comptage_API.DQ_DimTrain`.

Colonne renommée en SQL = requête Power BI cassée (listes de colonnes explicites : l'erreur dit laquelle).

### 3.4 Enregistrer en .pbix
Fichier > **Enregistrer sous** > type **Fichier Power BI (.pbix)** > `DQ_DWH.pbix`. Ferme et rouvre le `.pbix` pour vérifier qu'il s'ouvre.
Version : enregistre avec un Desktop **au plus égal** à celui de ton Report Server (mai 2026) ; si Report Server refuse le fichier (« version non prise en charge »), utilise le Desktop *Report Server* ou l'option 3.5. À confirmer.

### 3.5 Publier sur Report Server
Report Server > Charger/Publier `DQ_DWH.pbix` ; renseigne les identifiants de la source ; planifie l'actualisation **après** la fin du job SSIS DWH.

### 3.6 Secours : le kit texte (sans le .pbip)
Dans le Desktop Report Server : *Obtenir les données > SQL Server*, puis pour chaque table colle la requête de `kit_report_server/requetes_M.txt` (Éditeur avancé), crée les mesures avec `mesures_DAX.txt` et les relations avec `relations.txt`. **Les pages (visuels) ne sont pas dans le kit** : elles sont à refaire à la main.

---

## Points à confirmer et limites
- Rien d'exécuté : SQL, `.dtsx`, `.pbip`. Les tâches d'audit de batch SSIS sont des suppositions.
- **% FAIL sur longue période** : le détail arrêt/véhicule est limité à `JoursDetail` jours alors que les trains couvrent tout l'historique : sur Vue d'ensemble et Règles appliquées, les % FAIL au-delà de N jours ne sont pas comparables. Ajuste `JoursDetail` ou la période affichée.
- **4 vues `audit` V1** (FailedRecords, RuleReport, HighLevelReport, DataGalaxy) ont été supprimées pour réduire : à confirmer qu'aucun rapport V1 ni DataGalaxy ne les lit. Réversible (elles sont dans l'historique du dépôt).
- **Infobulles** : le texte de chaque règle vient de `DQ_DimRegle[Calcul]` (page Règles appliquées et infobulle règle). Les infobulles par mesure ne sont pas ajoutées.
- Performances inchangées : le gain est la maintenance.
- Le détail par tâche dans SSIS est réduit à ses tâches ; le détail par règle reste dans `audit.ExecutionsRegleDQ` et la page Suivi des exécutions.
