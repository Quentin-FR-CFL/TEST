# TEST3

Pack de déploiement du flux DQ V1 (réduit : 3 vues SQL, 2 packages SSIS, Power BI sur tables).
**Lis `GUIDE_TEST3.md`** : SQL Server, SSIS STA puis DWH, Power BI (.pbix), avec « je crée / je vérifie » à chaque étape.

| Dossier | Contenu |
|---|---|
| `1_SQL` | `DQ_script_unique.sql` (tout le SQL, une page, rejouable) et la recette |
| `2_SSIS` | les 2 masters à mettre à la place des existants (+ générateur pour les GUID) |
| `3_POWER_BI` | projet `.pbip` à ouvrir puis enregistrer en `.pbix`, et kit texte de secours |
| `4_DOCUMENTATION` | lineage (09), règles, référentiel, choix à trancher, constats |

Rien n'est testé sur un vrai serveur : à faire en DEV d'abord.
