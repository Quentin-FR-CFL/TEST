"""Génère les deux master packages SSIS (.dtsx) des projets CFL_STA_COMPTAGE et CFL_DWH_COMPTAGE (version réduite : plus de package enfant).

Python 3, bibliothèque standard uniquement. Usage, depuis le dossier ssis/ :
    python generer_packages.py [--sta-cm-sta GUID] [--dwh-cm-sta GUID]
Les GUID sont les DTSID des gestionnaires de connexion projet CM_STA de chaque projet (ouvrir CM_STA.conmgr dans un
éditeur de texte et copier la valeur de DTS:DTSID, accolades comprises). Sans argument, un GUID nul est écrit : il faut
alors le remplacer (voir docs/06_industrialisation_v1/08_guide_ssis_pas_a_pas.md).

ATTENTION : ces fichiers n'ont jamais été ouverts dans Visual Studio (aucune installation SSIS disponible lors de leur
écriture). Seule la validité XML est vérifiée. Les procédures d'audit de batch (audit.usp_StartNewBatchStep et
audit.usp_FinalizeBatchStep) sont des SUPPOSITIONS d'après le guide des bonnes pratiques : à comparer aux tâches du master ODS.
"""
import argparse, os, uuid
import xml.etree.ElementTree as ET
from xml.sax.saxutils import quoteattr

NS_ID = uuid.UUID('6f1c1d6e-0a6b-4d7e-9a53-5a3c2f0b7e11')
NUL = '{00000000-0000-0000-0000-000000000000}'
TYPES = {'String': 8, 'Int32': 3, 'Int64': 20}
OLEDB = {'String': 130, 'Int32': 3, 'Int64': 20}


def gid(*parts):
    return '{' + str(uuid.uuid5(NS_ID, '|'.join(parts))).upper() + '}'


def a(nom, val):
    return f'{nom}={quoteattr(str(val))}'


class Pkg:
    def __init__(self, nom, projet, cm, description):
        self.nom, self.projet, self.cm, self.description = nom, projet, cm, description
        self.params, self.vars, self.racine, self.contraintes = [], [], [], []

    def param(self, nom, typ, valeur, desc=''):
        self.params.append((nom, typ, valeur, desc))

    def var(self, nom, typ, valeur):
        self.vars.append((nom, typ, valeur))

    # ---- éléments ----
    def _ref(self, parent, nom):
        return f'{parent}\\{nom}'

    def sql(self, parent, nom, requete, binds=(), resultat=None, conn=None, desc=''):
        """binds : [(variable, type)] dans l'ordre des ? ; resultat : (nom de colonne, variable) en ligne unique."""
        ref = self._ref(parent, nom)
        b = ''
        if resultat:
            b += f'<SQLTask:ResultBinding SQLTask:ResultName={quoteattr(resultat[0])} SQLTask:DtsVariableName={quoteattr(resultat[1])} />'
        for i, (v, t) in enumerate(binds):
            b += (f'<SQLTask:ParameterBinding SQLTask:ParameterName="{i}" SQLTask:DtsVariableName={quoteattr(v)} '
                  f'SQLTask:ParameterDirection="Input" SQLTask:DataType="{OLEDB[t]}" SQLTask:ParameterSize="-1" />')
        rt = ' SQLTask:ResultType="ResultSetType_SingleRow"' if resultat else ''
        x = (f'<DTS:Executable DTS:refId={quoteattr(ref)} DTS:CreationName="Microsoft.ExecuteSQLTask" '
             f'DTS:Description={quoteattr(desc or nom)} DTS:DTSID="{gid(self.nom, ref)}" DTS:ExecutableType="Microsoft.ExecuteSQLTask" '
             f'DTS:LocaleID="-1" DTS:ObjectName={quoteattr(nom)} DTS:ThreadHint="0"><DTS:Variables />'
             f'<DTS:ObjectData><SQLTask:SqlTaskData SQLTask:Connection="{conn or self.cm}" '
             f'SQLTask:SqlStatementSource={quoteattr(requete)}{rt} '
             f'xmlns:SQLTask="www.microsoft.com/sqlserver/dts/tasks/sqltask">{b}</SQLTask:SqlTaskData></DTS:ObjectData></DTS:Executable>')
        return nom, x

    def expr(self, parent, nom, expression):
        ref = self._ref(parent, nom)
        x = (f'<DTS:Executable DTS:refId={quoteattr(ref)} DTS:CreationName="Microsoft.ExpressionTask" DTS:Description="Expression Task" '
             f'DTS:DTSID="{gid(self.nom, ref)}" DTS:ExecutableType="Microsoft.ExpressionTask" DTS:LocaleID="-1" '
             f'DTS:ObjectName={quoteattr(nom)} DTS:ThreadHint="0"><DTS:Variables /><DTS:ObjectData>'
             f'<ExpressionTask Expression={quoteattr(expression)} /></DTS:ObjectData></DTS:Executable>')
        return nom, x

    def exec_pkg(self, parent, nom, fichier, affectations=()):
        ref = self._ref(parent, nom)
        aff = ''.join(f'<ParameterAssignment><ParameterName>{p}</ParameterName>'
                      f'<BindedVariableOrParameterName>{v}</BindedVariableOrParameterName></ParameterAssignment>'
                      for p, v in affectations)
        x = (f'<DTS:Executable DTS:refId={quoteattr(ref)} DTS:CreationName="Microsoft.ExecutePackageTask" DTS:Description="Execute Package Task" '
             f'DTS:DTSID="{gid(self.nom, ref)}" DTS:ExecutableType="Microsoft.ExecutePackageTask" DTS:LocaleID="-1" '
             f'DTS:ObjectName={quoteattr(nom)} DTS:ThreadHint="0"><DTS:Variables /><DTS:ObjectData><ExecutePackageTask>'
             f'<UseProjectReference>True</UseProjectReference><PackageName>{fichier}</PackageName>{aff}'
             f'</ExecutePackageTask></DTS:ObjectData></DTS:Executable>')
        return nom, x

    def sequence(self, parent, nom, enfants, liens, desc=''):
        """enfants : [(nom, xml)] ; liens : [(de, vers, type, expression)] avec type success|failure|completion."""
        ref = self._ref(parent, nom)
        cont = ''.join(x for _, x in enfants)
        pc = self.liens_xml(ref, liens)
        x = (f'<DTS:Executable DTS:refId={quoteattr(ref)} DTS:CreationName="STOCK:SEQUENCE" DTS:Description={quoteattr(desc or nom)} '
             f'DTS:DTSID="{gid(self.nom, ref)}" DTS:ExecutableType="STOCK:SEQUENCE" DTS:LocaleID="-1" DTS:ObjectName={quoteattr(nom)}>'
             f'<DTS:Variables /><DTS:Executables>{cont}</DTS:Executables>'
             f'{"<DTS:PrecedenceConstraints>" + pc + "</DTS:PrecedenceConstraints>" if pc else ""}</DTS:Executable>')
        return nom, x

    def liens_xml(self, ref_parent, liens):
        out = ''
        for i, (de, vers, typ, expression) in enumerate(liens):
            nom = 'Constraint' if i == 0 else f'Constraint {i}'
            val = {'success': '', 'failure': ' DTS:Value="1"', 'completion': ' DTS:Value="2"'}[typ]
            ev = ''
            if expression:
                ev = f' DTS:EvalOp="3" DTS:Expression={quoteattr(expression)}'
            owner = ref_parent
            out += (f'<DTS:PrecedenceConstraint DTS:refId={quoteattr(owner + ".PrecedenceConstraints[" + nom + "]")} DTS:CreationName="" '
                    f'DTS:DTSID="{gid(self.nom, owner, nom)}" DTS:From={quoteattr(self._ref(owner, de))} DTS:LogicalAnd="{'False' if vers == 'Finaliser batch Failed' else 'True'}" '
                    f'DTS:ObjectName={quoteattr(nom)}{val}{ev} DTS:To={quoteattr(self._ref(owner, vers))} />')
        return out

    def xml(self):
        v = ''.join(f'<DTS:Variable DTS:CreationName="" DTS:DTSID="{gid(self.nom, "var", n)}" DTS:IncludeInDebugDump="6789" '
                    f'DTS:Namespace="User" DTS:ObjectName={quoteattr(n)}><DTS:VariableValue DTS:DataType="{TYPES[t]}">{val}'
                    f'</DTS:VariableValue></DTS:Variable>' for n, t, val in self.vars)
        p = ''.join(f'<DTS:PackageParameter DTS:CreationName="" DTS:DataType="{TYPES[t]}" DTS:Description={quoteattr(d)} '
                    f'DTS:DTSID="{gid(self.nom, "param", n)}" DTS:ObjectName={quoteattr(n)}>'
                    f'<DTS:Property DTS:DataType="{TYPES[t]}" DTS:Name="ParameterValue">{val}</DTS:Property></DTS:PackageParameter>'
                    for n, t, val, d in self.params)
        ex = ''.join(x for _, x in self.racine)
        pc = self.liens_xml('Package', self.contraintes)
        return ('<?xml version="1.0"?>\n'
                '<DTS:Executable xmlns:DTS="www.microsoft.com/SqlServer/Dts" DTS:refId="Package" '
                'DTS:CreationName="Microsoft.Package" '
                f'DTS:Description={quoteattr(self.description)} DTS:DTSID="{gid(self.nom)}" DTS:ExecutableType="Microsoft.Package" '
                f'DTS:LastModifiedProductVersion="16.0.5685.0" DTS:LocaleID="1036" DTS:ObjectName={quoteattr(self.nom)} '
                f'DTS:PackageType="5" DTS:VersionBuild="1" DTS:VersionGUID="{gid(self.nom, "version")}">'
                '<DTS:Property DTS:Name="PackageFormatVersion">8</DTS:Property>'
                f'<DTS:Variables>{v}</DTS:Variables><DTS:PackageParameters>{p}</DTS:PackageParameters>'
                f'<DTS:Executables>{ex}</DTS:Executables>'
                f'{"<DTS:PrecedenceConstraints>" + pc + "</DTS:PrecedenceConstraints>" if pc else ""}'
                '</DTS:Executable>\n')


# ---------------------------------------------------------------------------------------------------------------
# Éléments communs aux master packages (modèle du master ODS : Initialiser batch, Traitements, Finaliser Succeeded / Failed)
# ---------------------------------------------------------------------------------------------------------------
INIT = 'EXEC audit.usp_StartNewBatchStep @SourceName = ?, @StepName = ?'
FINAL = 'EXEC audit.usp_FinalizeBatchStep @SourceName = ?, @StepName = ?, @Status = {s}'
BIND_BATCH = [('$Package::SourceName', 'String'), ('User::StepName', 'String')]


def fenetre(p):
    """Conteneur « Fenêtre de dates » : J-NbJoursFenetre à J-1, comme la publication J-10 à J-1 du package ODS."""
    enf = [p.expr('Package\\Fenêtre de dates', 'Calculer la date de fin (J-1)',
                  '@[User::DateFin] = (DT_WSTR, 10)(DT_DBDATE)DATEADD("day", -1, GETDATE())'),
           p.expr('Package\\Fenêtre de dates', 'Calculer la date de début (J-n)',
                  '@[User::DateDebut] = (DT_WSTR, 10)(DT_DBDATE)DATEADD("day", -@[$Package::NbJoursFenetre], GETDATE())')]
    return p.sequence('Package', 'Fenêtre de dates', enf,
                      [('Calculer la date de fin (J-1)', 'Calculer la date de début (J-n)', 'success', None)],
                      'Calcul de la fenêtre de dates à traiter')


def master(nom, projet, cm, etape, nom_etape, nom_cont, enfants, liens_cont, avant=None, apres_succes=None, apres_echec=None):
    """Construit un master package. avant : tâches entre la fenêtre et le conteneur ; apres_* : tâches avant la finalisation."""
    p = Pkg(nom, projet, cm, f'Master package {nom_etape} du projet {projet}')
    p.param('SourceName', 'String', 'SIV_APC', 'Source DQ et batch')
    p.param('NbJoursFenetre', 'Int32', 10, 'Taille de la fenêtre : J-n à J-1 (10 comme la publication du package ODS, à confirmer)')
    p.var('StepName', 'String', etape)
    p.var('PreviousStepsStatus', 'Int32', 0)
    p.var('DateDebut', 'String', '1900-01-01')
    p.var('DateFin', 'String', '1900-01-01')
    p.var('ExecutionId', 'Int64', 0)
    racine = []
    racine.append(p.sql('Package', f'Initialiser batch {nom_etape}', INIT, BIND_BATCH))
    racine.append(fenetre(p))
    suite = f'Fenêtre de dates'
    liens = [(f'Initialiser batch {nom_etape}', 'Fenêtre de dates', 'success', '@[User::PreviousStepsStatus]==0')]
    dernier = 'Fenêtre de dates'
    for t in (avant or []):
        racine.append(t)
        liens.append((dernier, t[0], 'success', None))
        dernier = t[0]
    racine.append(p.sequence('Package', nom_cont, enfants, liens_cont, f'Traitements {nom_etape}'))
    liens.append((dernier, nom_cont, 'success', None))
    # branche succès
    fin_ok = p.sql('Package', 'Finaliser batch Succeeded', FINAL.format(s=0), BIND_BATCH)
    fin_ko = p.sql('Package', 'Finaliser batch Failed', FINAL.format(s=1), BIND_BATCH)
    propage = p.sql('Package', "Propager l'échec technique", "THROW 50099, N'Échec du master package : voir le journal SSISDB et audit.', 1;")
    prev_ok, prev_ko = nom_cont, nom_cont
    for t in (apres_succes or []):
        racine.append(t)
        liens.append((prev_ok, t[0], 'success', None))
        prev_ok = t[0]
    for t in (apres_echec or []):
        racine.append(t)
        liens.append((prev_ko, t[0], 'failure', None))
        prev_ko = t[0]
    racine += [fin_ok, fin_ko, propage]
    liens.append((prev_ok, 'Finaliser batch Succeeded', 'success', None))
    liens.append((prev_ko, 'Finaliser batch Failed', 'failure' if not apres_echec else 'completion', None))
    liens.append(('Finaliser batch Failed', "Propager l'échec technique", 'completion', None))
    # un échec avant le conteneur (fenêtre de dates, ouverture de l'exécution) finalise aussi le batch en échec (contraintes en OU)
    for amont in ['Fenêtre de dates'] + [t[0] for t in (avant or [])]:
        liens.append((amont, 'Finaliser batch Failed', 'failure', None))
    p.racine, p.contraintes = racine, liens
    return p


B_DATES = [('User::DateDebut', 'String'), ('User::DateFin', 'String')]
B_EXE = [('User::ExecutionId', 'Int64')]


def construire(cm_sta_sta, cm_sta_dwh):
    """Deux packages seulement : un master par couche (STA, DWH). Les traitements sont des tâches « Exécuter SQL » directement
    dans le conteneur du master (plus de package enfant) : SSIS montre l'étape qui échoue, le détail par règle est dans audit."""
    out = {}
    # ======================= STA =======================
    pr = 'CFL_STA_COMPTAGE'
    m = Pkg('SIV_MasterPackage_OdsToSta', pr, cm_sta_sta, 'x')
    ouvrir = m.sql('Package', "Ouvrir l'exécution DQ",
                   'SET NOCOUNT ON; DECLARE @e bigint = NULL; EXEC audit.usp_DQ_OuvrirExecution @SourceName = ?, @DateDebut = ?, '
                   '@DateFin = ?, @ExecutionId = @e OUTPUT, @SsisExecutionId = ?; SELECT ExecutionId = @e;',
                   [('$Package::SourceName', 'String'), ('User::DateDebut', 'String'), ('User::DateFin', 'String'),
                    ('System::ServerExecutionID', 'Int64')], resultat=('ExecutionId', 'User::ExecutionId'))
    c = 'Package\\Traitements Sta'
    enf = [m.exec_pkg(c, 'Exécuter SIV_Split_Counting_Station_EVN', 'SIV_Split_Counting_Station_EVN.dtsx'),
           m.sql(c, 'Charger staging DQ', 'EXEC comptage_API.usp_DQ_ChargerStaging @DateDebut = ?, @DateFin = ?', B_DATES),
           m.sql(c, 'Contrôler staging DQ', 'EXEC comptage_API.usp_DQ_ControlerStaging @ExecutionId = ?', B_EXE),
           m.sql(c, 'Parser JSON DQ', 'EXEC comptage_API.usp_DQ_ParserStaging @DateDebut = ?, @DateFin = ?, @ExecutionId = ?', B_DATES + B_EXE),
           m.sql(c, 'Exécuter les règles DQ',
                 'EXEC audit.usp_DQ_ExecuterRegles @SourceName = ?, @DateDebut = ?, @DateFin = ?, @ExecutionId = ?, @Cloturer = 0',
                 [('$Package::SourceName', 'String')] + B_DATES + B_EXE),
           m.sql(c, 'Calculer le score DQ', 'EXEC audit.usp_DQ_CalculerScore @SourceName = ?, @ExecutionId = ?, @DateDebut = ?, @DateFin = ?',
                 [('$Package::SourceName', 'String')] + B_EXE + B_DATES)]
    lc = [(enf[i][0], enf[i + 1][0], 'success', None) for i in range(len(enf) - 1)]
    clore_ok = m.sql('Package', 'Clore exécution DQ Succeeded',
                     "EXEC audit.usp_DQ_CloreExecution @ExecutionId = ?, @Statut = 'Succes'", B_EXE)
    clore_ko = m.sql('Package', 'Clore exécution DQ Failed',
                     "EXEC audit.usp_DQ_CloreExecution @ExecutionId = ?, @Statut = 'Echec', "
                     "@Message = N'Échec du master package SSIS : voir audit.ExecutionsRegleDQ et le journal SSISDB'", B_EXE)
    p = master('SIV_MasterPackage_OdsToSta', pr, cm_sta_sta, 'STA', 'Sta', 'Traitements Sta', enf, lc,
               avant=[ouvrir], apres_succes=[clore_ok], apres_echec=[clore_ko])
    out[(pr, p.nom)] = p

    # ======================= DWH =======================
    pr = 'CFL_DWH_COMPTAGE'
    m = Pkg('SIV_MasterPackage_StaToDwh', pr, cm_sta_dwh, 'x')
    c = 'Package\\Traitements Dwh'
    enf = [m.sql(c, 'Rafraîchir le modèle DWH', 'EXEC comptage_API.usp_DQ_RafraichirModele @SourceName = ?, @DateDebut = ?, @DateFin = ?',
                 [('$Package::SourceName', 'String')] + B_DATES),
           m.sql(c, 'Contrôler le modèle DWH', 'EXEC comptage_API.usp_DQ_ControlerModele @SourceName = ?, @DateDebut = ?, @DateFin = ?',
                 [('$Package::SourceName', 'String')] + B_DATES)]
    p = master('SIV_MasterPackage_StaToDwh', pr, cm_sta_dwh, 'DWH', 'Dwh', 'Traitements Dwh', enf,
               [(enf[0][0], enf[1][0], 'success', None)])
    out[(pr, p.nom)] = p
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--sta-cm-sta', default=NUL, help='DTSID de CM_STA dans CFL_STA_COMPTAGE')
    ap.add_argument('--dwh-cm-sta', default=NUL, help='DTSID de CM_STA dans CFL_DWH_COMPTAGE')
    a_ = ap.parse_args()
    racine = os.path.dirname(os.path.abspath(__file__))
    for (projet, nom), p in construire(a_.sta_cm_sta, a_.dwh_cm_sta).items():
        txt = p.xml()
        ET.fromstring(txt.encode('utf-8'))          # validité XML
        d = os.path.join(racine, projet)
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, nom + '.dtsx'), 'w', encoding='utf-8', newline='\n') as f:
            f.write(txt)
        print(projet + '/' + nom + '.dtsx')


if __name__ == '__main__':
    main()
