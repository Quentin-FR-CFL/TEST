/*==============================================================================
 DQ - SCRIPT UNIQUE : installation complète des règles de qualité de données (STA + DWH)
===============================================================================
 But : créer, en une seule exécution, tout ce que le pipeline DQ utilise dans la base CFL_GOV :
   - schémas et droits, vue sur la source, tables de staging et de parsing,
   - catalogue des règles, journal des résultats, exécutions et scores,
   - les 14 procédures de règles et l'orchestrateur,
   - le score, le modèle en étoile Power BI et ses vues,
   - la procédure de pipeline appelée après le job SSIS, le catalogue de départ et la maintenance.

 Utilisation :
   1. Prérequis : la table comptage_API.Counting existe (alimentée par le flux ODS).
   2. Exécuter ce fichier en entier dans SSMS (rejouable : CREATE OR ALTER, IF NOT EXISTS, MERGE).
   3. Le pipeline se lance ensuite par : EXEC audit.usp_DQ_Pipeline_SIV_APC @DateDebut = ?, @DateFin = ?;
   4. Contrôle : relire les tables vides puis exécuter le pipeline sur une fenêtre (voir la recette en annexe).

 Fichier généré par sql/construire_script_unique.py à partir des scripts de sql/ : ne pas le modifier à la main,
 modifier le script source puis relancer le programme. Non exécuté sur un serveur à ce jour.

 Sommaire :
 01. Schémas, rôles et droits
 02. Vue sur la source et table de staging
 03. Tables issues du parsing JSON
 04. Catalogue des règles, exécutions, journal et scores
 05. Fonctions de lecture des valeurs JSON
 06. Procédures de staging, contrôles techniques et parsing
 07. Écriture des résultats et orchestrateur
 08. DQ-01 - Cohérence flux / occupation
 09. DQ-02 - Complétude EVN
 10. DQ-03 - Remise à zéro au terminus
 11. DQ-04 - Charge critique
 12. DQ-05 - État du matériel
 13. DQ-06 - Disponibilité des capteurs
 14. DQ-07 - Complétude de la séquence d'arrêts
 15. DQ-08 - Équilibre des flux
 16. DQ-09 - Remise à zéro à l'origine
 17. DQ-10 - Occupation reconstruite non négative
 18. DQ-11 - Cohérence entre les mailles
 19. DQ-12 - Valeurs exploitables
 20. DQ-13 - Capteur figé
 21. DQ-14 - Flux aux extrémités
 22. Score, couverture, verdict et imputation
 23. Tables du modèle en étoile (Power BI)
 24. Rafraîchissement du modèle, contrôle et vues
 25. Pipeline complet (point d'entrée appelé après SSIS)
 26. Données de départ : catalogue des 14 règles et paramètres du score
 27. Purge et maintenance
===============================================================================*/

USE CFL_GOV;
GO

/*==============================================================================
 ÉTAPE 01/27 - Schémas, rôles et droits
 Source : sql/00_schemas.sql
 But : Crée les schémas audit et comptage_API, deux rôles (exécuteur,
 lecteur) et leurs droits.
===============================================================================*/

/*
================================================================================
 00 - Schémas de la base (périmètre SIV_APC)
================================================================================
 Choix du projet SSIS (CFL_ODS_COMPTAGE, CFL_STA_COMPTAGE, CFL_DWH_COMPTAGE) : le schéma comptage_API est commun aux trois couches.
   comptage_API : source ODS (Counting), objets de la couche STA (préfixe DQ_ : staging, parsing, fonctions, vues)
                  et de la couche DWH (préfixe DQ_ : dimensions, faits, agrégats, vues Power BI : comptage_API.vw_DQ_*)
   audit        : catalogue V1 (ReglesDQ), journal (LogsDQ), exécutions, scores, orchestrateur et procédures de règles
 En DEV, DbNameOds = DbNameSta = CFL_GOV (paramètres de projet SSIS) : tout est dans la même base. Séparer les couches dans
 des bases distinctes (valeurs de DbNameOds / DbNameSta différentes) demanderait des synonymes : voir docs/06_industrialisation_v1/07.

 Rôles (à créer par l'équipe DWH, voir docs/06_industrialisation_v1/04) :
   db_dq_executeur  : exécute le traitement (compte des packages SSIS / de l'agent SQL)
   db_dq_lecteur    : lit les tables DQ_* du modèle et les tables audit listées (compte Power BI)
================================================================================
*/
-- But : créer le schéma audit (catalogue, journal, scores, procédures de règles) s'il n'existe pas.
IF SCHEMA_ID(N'audit')        IS NULL EXEC (N'CREATE SCHEMA audit AUTHORIZATION dbo');
-- But : créer le schéma comptage_API (source, staging, parsing, modèle Power BI) s'il n'existe pas.
IF SCHEMA_ID(N'comptage_API') IS NULL EXEC (N'CREATE SCHEMA comptage_API AUTHORIZATION dbo');
GO

-- But : créer les deux rôles (exécuteur du pipeline, lecteur des résultats).
IF DATABASE_PRINCIPAL_ID(N'db_dq_executeur') IS NULL CREATE ROLE db_dq_executeur;
IF DATABASE_PRINCIPAL_ID(N'db_dq_lecteur')   IS NULL CREATE ROLE db_dq_lecteur;
GO

-- But : donner au rôle exécuteur le droit d'appeler les procédures (les droits du lecteur Power BI sont
-- accordés à la fin de la restitution, table par table).
GRANT EXECUTE ON SCHEMA::audit        TO db_dq_executeur;
GRANT EXECUTE ON SCHEMA::comptage_API TO db_dq_executeur;
-- Les droits de lecture de db_dq_lecteur (tables listées) sont accordés à la fin de 10_proc_restitution_et_vues.sql.
GO

/*==============================================================================
 ÉTAPE 02/27 - Vue sur la source et table de staging
 Source : sql/01_source_et_staging.sql
 But : Lit la table source comptage_API.Counting sans la modifier (vue typée)
 et crée la table qui reçoit la copie de la fenêtre traitée.
===============================================================================*/

/*
================================================================================
 01 - Source (comptage API) et staging
================================================================================
 La source est la table alimentée par le job SSIS existant : UNE LIGNE PAR TRAIN,
 avec les colonnes JSON de comptage (voir docs/03_dataset_et_maille.md).
 Le dossier ne modifie jamais cette table : il la lit.

 La source est comptage_API.Counting (table du job SSIS CFL_ODS_COMPTAGE, package SIV_api_Counting). Les noms de
 colonnes attendus sont ceux du CSV d'origine (hypothèse à confirmer) : le seul point d'adaptation est la vue
 comptage_API.vw_DQ_SourceTrain ci-dessous.
 Si la table source est typée (int, date...) ou stocke la chaîne 'NULL', la vue
 comptage_API.vw_DQ_SourceTrain absorbe les deux cas (CAST en texte, NULLIF 'NULL', TRY_CONVERT).
================================================================================
*/
-- ---------------------------------------------------------------------------
-- 1. Vue de lecture typée de la source (une ligne = un train)
-- ---------------------------------------------------------------------------
-- But : vue typée de comptage_API.Counting : « NULL » texte -> NULL, nombres et dates en TRY_CONVERT
-- (une valeur illisible devient NULL, jamais une erreur).
CREATE OR ALTER VIEW comptage_API.vw_DQ_SourceTrain
AS
SELECT
    CountingId                  = TRY_CONVERT(bigint, c.CountingId),
    CirculationDate             = TRY_CONVERT(date, CAST(c.CirculationDate AS nvarchar(40))),
    LoadDateTime                = TRY_CONVERT(datetime2(7), CAST(c.LoadDateTime AS nvarchar(40))),
    TravelId                    = NULLIF(CAST(c.TravelId AS nvarchar(50)), N'NULL'),
    TrainNumber                 = NULLIF(LTRIM(RTRIM(CAST(c.TrainNumber AS nvarchar(20)))), N'NULL'),
    Variant                     = NULLIF(CAST(c.Variant AS nvarchar(20)), N'NULL'),
    TrainType                   = NULLIF(CAST(c.TrainType AS nvarchar(30)), N'NULL'),
    Series                      = NULLIF(CAST(c.Series AS nvarchar(30)), N'NULL'),
    LineCode                    = NULLIF(CAST(c.LineCode AS nvarchar(30)), N'NULL'),
    DepartureStation            = NULLIF(CAST(c.DepartureStation AS nvarchar(100)), N'NULL'),
    ArrivalStation              = NULLIF(CAST(c.ArrivalStation AS nvarchar(100)), N'NULL'),
    HeadEVN                     = NULLIF(CAST(c.HeadEuropeanVehicleNumber AS nvarchar(20)), N'NULL'),
    IsDegraded                  = CASE CAST(c.IsDegraded AS nvarchar(10)) WHEN N'1' THEN 1 WHEN N'True' THEN 1
                                                                           WHEN N'0' THEN 0 WHEN N'False' THEN 0 END,
    HasComposition              = CASE CAST(c.HasComposition AS nvarchar(10)) WHEN N'1' THEN 1 WHEN N'True' THEN 1
                                                                               WHEN N'0' THEN 0 WHEN N'False' THEN 0 END,
    TotalCapacityTxt            = NULLIF(CAST(c.TotalCapacity AS nvarchar(40)), N'NULL'),
    TotalOccupancyTxt           = NULLIF(CAST(c.TotalOccupancy AS nvarchar(40)), N'NULL'),
    OccupancyRatePercentTxt     = NULLIF(CAST(c.OccupancyRatePercent AS nvarchar(40)), N'NULL'),
    EuropeanVehicleNumbersJson  = COALESCE(NULLIF(CAST(c.EuropeanVehicleNumbersJson AS nvarchar(max)), N'NULL'), N'[]'),
    StopsJson                   = COALESCE(NULLIF(CAST(c.StopsJson AS nvarchar(max)), N'NULL'), N'[]')
FROM comptage_API.Counting AS c;
GO

-- ---------------------------------------------------------------------------
-- 2. Staging : photographie typée de la FENETRE en cours de traitement
--    (vidée et rechargée à chaque exécution ; un seul pipeline à la fois, voir applock)
-- ---------------------------------------------------------------------------
-- But : table de staging : copie de la fenêtre traitée, une ligne par train, JSON gardé en
-- nvarchar(max). Vidée et rechargée à chaque exécution.
IF OBJECT_ID(N'comptage_API.DQ_StgTrain', N'U') IS NULL
CREATE TABLE comptage_API.DQ_StgTrain
(
    CountingId                  bigint         NOT NULL,
    CirculationDate             date           NULL,
    LoadDateTime                datetime2(7)   NULL,
    TravelId                    nvarchar(50)   NULL,
    TrainNumber                 nvarchar(20)   NULL,
    Variant                     nvarchar(20)   NULL,
    TrainType                   nvarchar(30)   NULL,
    Series                      nvarchar(30)   NULL,
    LineCode                    nvarchar(30)   NULL,
    DepartureStation            nvarchar(100)  NULL,
    ArrivalStation              nvarchar(100)  NULL,
    HeadEVN                     nvarchar(20)   NULL,
    IsDegraded                  bit            NULL,
    HasComposition              bit            NULL,
    TotalCapacityTxt            nvarchar(40)   NULL,
    TotalOccupancyTxt           nvarchar(40)   NULL,
    OccupancyRatePercentTxt     nvarchar(40)   NULL,
    EuropeanVehicleNumbersJson  nvarchar(max)  NOT NULL,
    StopsJson                   nvarchar(max)  NOT NULL,
    JsonValide                  bit            NOT NULL CONSTRAINT DF_StgTrain_JsonValide DEFAULT (1),
    CleValide                   bit            NOT NULL CONSTRAINT DF_StgTrain_CleValide DEFAULT (1),
    CONSTRAINT PK_StgTrain PRIMARY KEY CLUSTERED (CountingId)
);
GO

/*==============================================================================
 ÉTAPE 03/27 - Tables issues du parsing JSON
 Source : sql/02_tables_parsing.sql
 But : Crée les tables Train, Arrêt, Véhicule (EVN) et EVN attendus, remplies
 par le parsing, et la vue qui décrit les arrêts sans donnée.
===============================================================================*/

/*
================================================================================
 02 - Tables de parsing (une table par maille) : Train, Arrêt, Arrêt x véhicule
================================================================================
 Mailles (voir docs/03_dataset_et_maille.md, section 5) :
   comptage_API.DQ_Train      1 ligne par circulation        (clé CountingId)
   comptage_API.DQ_Arret      1 ligne par élément de StopsJson   (clé CountingId, Rang)
   comptage_API.DQ_ArretEVN   1 ligne par véhicule à l'arrêt  (clé CountingId, Rang, VehIdx)
   comptage_API.DQ_EVNAttendu 1 ligne par EVN de la composition attendue (EuropeanVehicleNumbersJson)

 Convention des colonnes d'état de lecture (xxxSt) :
   0 = valeur lue, 1 = absente (clé absente, null ou vide), 2 = illisible (non entière).
 Les valeurs xxx sont NULL dès que l'état n'est pas 0 (équivalent du None du moteur Python).
 Convention des états capteur (ExtEtat, IntEtat) :
   0 = sans donnée, 1 = valide (>= 100 %), 2 = invalide (< 100 %).
================================================================================
*/
-- But : un train par ligne (identité, totaux, nombre d'arrêts). Rempli par le parsing.
IF OBJECT_ID(N'comptage_API.DQ_Train', N'U') IS NULL
CREATE TABLE comptage_API.DQ_Train
(
    CountingId       bigint        NOT NULL,
    RunId            varchar(60)   NOT NULL,           -- TrainNumber|CirculationDate
    CirculationDate  date          NOT NULL,
    TrainNumber      nvarchar(20)  NOT NULL,
    Variant          nvarchar(20)  NULL,
    TravelId         nvarchar(50)  NULL,
    TrainType        nvarchar(30)  NULL,
    Series           nvarchar(30)  NULL,
    LineCode         nvarchar(30)  NULL,
    DepartureStation nvarchar(100) NULL,
    ArrivalStation   nvarchar(100) NULL,
    HeadEVN          nvarchar(20)  NULL,
    IsDegraded       bit           NULL,
    HasComposition   bit           NULL,
    TotalCapacity    int           NULL,  CapSt  tinyint NOT NULL,
    TotalOccupancy   int           NULL,  OccSt  tinyint NOT NULL,
    RateSt           tinyint       NOT NULL,           -- état de lecture de OccupancyRatePercent
    NbStops          smallint      NOT NULL CONSTRAINT DF_Train_NbStops DEFAULT (0),
    NbStopsObs       smallint      NOT NULL CONSTRAINT DF_Train_NbStopsObs DEFAULT (0),
    NbEvnExpected    smallint      NOT NULL CONSTRAINT DF_Train_NbEvnExp DEFAULT (0),
    LoadDateTime     datetime2(7)  NULL,
    ParsedAtUtc      datetime2(0)  NOT NULL CONSTRAINT DF_Train_ParsedAt DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT PK_apc_Train PRIMARY KEY CLUSTERED (CountingId)
);
GO
-- But : index de recherche des trains par date de circulation.
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_apc_Train_Date' AND object_id = OBJECT_ID(N'comptage_API.DQ_Train'))
    CREATE UNIQUE NONCLUSTERED INDEX IX_apc_Train_Date ON comptage_API.DQ_Train (CirculationDate, TrainNumber)
        INCLUDE (CountingId);        -- unicité (TrainNumber, CirculationDate) : contrôle technique + RunId
GO

-- But : un arrêt par ligne (occupation, montées, descentes, capacité avec leur état de lecture).
-- Rempli par le parsing.
IF OBJECT_ID(N'comptage_API.DQ_Arret', N'U') IS NULL
CREATE TABLE comptage_API.DQ_Arret
(
    CountingId       bigint        NOT NULL,
    Rang             smallint      NOT NULL,           -- position dans StopsJson, de 1 à n
    RunId            varchar(100)  NOT NULL,           -- TrainNumber|CirculationDate|Rang
    CirculationDate  date          NOT NULL,
    TrainNumber      nvarchar(20)  NOT NULL,
    StationCode      nvarchar(20)  NULL,
    StationName      nvarchar(100) NULL,
    StopType         varchar(10)   NULL,               -- Start / Stop / End
    StationPassed    bit           NULL,
    IsDegraded       bit           NULL,
    Occ              int           NULL,  OccSt   tinyint NOT NULL,   -- occupancy.allClasses
    Boarding         int           NULL,  BoardingSt  tinyint NOT NULL,   -- boarding.allClasses
    Alighting        int           NULL,  AlightingSt tinyint NOT NULL,   -- alighting.allClasses
    Capacity         int           NULL,  CapacitySt  tinyint NOT NULL,   -- capacity.allClasses
    HasData          bit           NOT NULL,           -- occupation lue (OccSt = 0)
    NbEvnObs         smallint      NOT NULL CONSTRAINT DF_Arret_NbEvnObs DEFAULT (0),
    Heure            tinyint       NULL,               -- heure réelle d'arrivée (à défaut de départ)
    CumulFlux        int           NULL,               -- Σ(montées - descentes) de 1 à Rang ; NULL si un flux manque sur 1..Rang
    CONSTRAINT PK_apc_Arret PRIMARY KEY CLUSTERED (CountingId, Rang)
);
GO
-- But : index de recherche des arrêts par date de circulation.
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_apc_Arret_Date' AND object_id = OBJECT_ID(N'comptage_API.DQ_Arret'))
    CREATE NONCLUSTERED INDEX IX_apc_Arret_Date ON comptage_API.DQ_Arret (CirculationDate) INCLUDE (RunId);
-- But : index d'unicité sur l'identifiant d'arrêt (jointure avec le journal).
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_apc_Arret_RunId' AND object_id = OBJECT_ID(N'comptage_API.DQ_Arret'))
    CREATE UNIQUE NONCLUSTERED INDEX IX_apc_Arret_RunId ON comptage_API.DQ_Arret (RunId);
GO

-- But : un véhicule (EVN) à un arrêt par ligne, avec les états des capteurs. Rempli par le parsing.
IF OBJECT_ID(N'comptage_API.DQ_ArretEVN', N'U') IS NULL
CREATE TABLE comptage_API.DQ_ArretEVN
(
    CountingId       bigint        NOT NULL,
    Rang             smallint      NOT NULL,
    VehIdx           smallint      NOT NULL,           -- position du véhicule dans vehicles[] (0-based)
    RunId            varchar(130)  NOT NULL,           -- TrainNumber|CirculationDate|Rang|EVN
    CirculationDate  date          NOT NULL,
    TrainNumber      nvarchar(20)  NOT NULL,
    EVN              nvarchar(20)  NOT NULL,           -- europeanVehicleNumber (12 chiffres)
    Position         smallint      NULL,               -- compositionVehiclePosition
    SerieVehicule    nvarchar(30)  NULL,
    Occ              int           NULL,  OccSt        tinyint NOT NULL,   -- occupancy.allClasses
    SensorCapacity   int           NULL,  SensorCapSt  tinyint NOT NULL,   -- sensorCapacity.allClasses
    Boarding         int           NULL,  BoardingSt   tinyint NOT NULL,   -- boarding.firstClass + secondClass
    Alighting        int           NULL,  AlightingSt  tinyint NOT NULL,   -- alighting.firstClass + secondClass
    ExtPct           int           NULL,
    IntPct           int           NULL,
    ExtEtat          tinyint       NOT NULL,           -- 0 sans donnée, 1 valide, 2 invalide
    IntEtat          tinyint       NOT NULL,
    CONSTRAINT PK_apc_ArretEVN PRIMARY KEY CLUSTERED (CountingId, Rang, VehIdx) WITH (DATA_COMPRESSION = PAGE)
);
GO
-- But : index de recherche par EVN.
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_apc_ArretEVN_EVN' AND object_id = OBJECT_ID(N'comptage_API.DQ_ArretEVN'))
    CREATE NONCLUSTERED INDEX IX_apc_ArretEVN_EVN ON comptage_API.DQ_ArretEVN (CountingId, EVN, Rang)
        INCLUDE (Occ, Boarding, Alighting, ExtEtat, IntEtat) WITH (DATA_COMPRESSION = PAGE);
-- But : index de recherche par date de circulation.
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_apc_ArretEVN_Date' AND object_id = OBJECT_ID(N'comptage_API.DQ_ArretEVN'))
    CREATE NONCLUSTERED INDEX IX_apc_ArretEVN_Date ON comptage_API.DQ_ArretEVN (CirculationDate) WITH (DATA_COMPRESSION = PAGE);
GO

-- But : composition attendue du train (EVN), utilisée par DQ-02 et DQ-06.
IF OBJECT_ID(N'comptage_API.DQ_EVNAttendu', N'U') IS NULL
CREATE TABLE comptage_API.DQ_EVNAttendu
(
    CountingId       bigint        NOT NULL,
    EVN              nvarchar(20)  NOT NULL,
    CirculationDate  date          NOT NULL,
    CONSTRAINT PK_apc_EVNAttendu PRIMARY KEY CLUSTERED (CountingId, EVN)
);
GO

-- ---------------------------------------------------------------------------
-- Motif des arrêts sans donnée (DQ-07, score et imputation)
--   pat : un caractère par arrêt dans l'ordre du trajet, D = mesuré, . = sans donnée
--   Motif : aucun | tout | combinaison de début, fin, trou (séparés par +)
-- ---------------------------------------------------------------------------
-- But : vue : motif des arrêts sans donnée par train (début, fin, trou, tout). Alimente DQ-07, le
-- score et l'imputation.
CREATE OR ALTER VIEW comptage_API.vw_DQ_TrainMotif
AS
SELECT
    t.CountingId,
    Motif = CASE
              WHEN p.pat IS NULL OR CHARINDEX('.', p.pat) = 0 THEN N'aucun'
              WHEN CHARINDEX('D', p.pat) = 0 THEN N'tout'
              ELSE CONCAT_WS(N'+',
                     CASE WHEN LEFT(p.pat, 1)  = '.' THEN N'début' END,
                     CASE WHEN RIGHT(p.pat, 1) = '.' THEN N'fin' END,
                     CASE WHEN SUBSTRING(p.pat, CHARINDEX('D', p.pat),
                                         (LEN(p.pat) - CHARINDEX('D', REVERSE(p.pat)) + 1) - CHARINDEX('D', p.pat) + 1)
                               LIKE '%.%' THEN N'trou' END)
            END,
    ArretsManquants = p.manquants
FROM comptage_API.DQ_Train AS t
OUTER APPLY (
    SELECT pat = CAST(STRING_AGG(CASE WHEN a.HasData = 1 THEN 'D' ELSE '.' END, '')
                      WITHIN GROUP (ORDER BY a.Rang) AS varchar(max)),
           manquants = CAST(STRING_AGG(CASE WHEN a.HasData = 0 THEN COALESCE(a.StationName, N'') END, N'|')
                            WITHIN GROUP (ORDER BY a.Rang) AS nvarchar(max))
    FROM comptage_API.DQ_Arret AS a
    WHERE a.CountingId = t.CountingId
) AS p;
GO

/*==============================================================================
 ÉTAPE 04/27 - Catalogue des règles, exécutions, journal et scores
 Source : sql/03_audit_catalogue_logs.sql
 But : Crée le schéma de contrôle : catalogue des règles, paramètres,
 exécutions, journal central LogsDQ (columnstore), scores et la fonction qui
 construit l'identifiant d'objet.
===============================================================================*/

/*
================================================================================
 03 - Schéma audit : catalogue, exécutions, logs, score, paramètres
================================================================================
 ATTENTION : audit.ReglesDQ et audit.LogsDQ EXISTENT déjà dans CFL_GOV (DEV) d'après la
 proposition V1. Le DDL ci-dessous est RECONSTITUE à partir des schémas et du document
 de la proposition (liste des colonnes et exemples SQL) : il n'a pas pu être comparé au
 DDL réel. Mode d'emploi :
   - base vierge          : exécuter tout le fichier ;
   - tables déjà en DEV   : comparer, puis n'exécuter que la section 9 (delta, idempotent)
                            qui ajoute les colonnes d'extension signalées [EXT].
 Les colonnes marquées [EXT] sont des extensions de la V1, à valider (voir
 docs/06_industrialisation_v1/07_choix_a_trancher.md).
================================================================================
*/
-- ---------------------------------------------------------------------------
-- 1. Séquence des identifiants d'exécution
-- ---------------------------------------------------------------------------
-- But : séquence qui fournit l'identifiant de chaque exécution du pipeline.
IF OBJECT_ID(N'audit.seq_ExecutionId', N'SO') IS NULL
    CREATE SEQUENCE audit.seq_ExecutionId AS bigint START WITH 1 INCREMENT BY 1 CACHE 50;
GO

-- ---------------------------------------------------------------------------
-- 2. Catalogue des règles : une ligne par règle et périmètre
-- ---------------------------------------------------------------------------
-- But : catalogue des règles : code, procédure, ordre, seuils, activation, version, poids du score.
-- Piloté par les données, aucun redéploiement pour changer un seuil.
IF OBJECT_ID(N'audit.ReglesDQ', N'U') IS NULL
CREATE TABLE audit.ReglesDQ
(
    RegleDQID              int IDENTITY(1,1) NOT NULL,
    SourceName             nvarchar(50)   NOT NULL,           -- périmètre, ex. SIV_APC
    RuleCode               nvarchar(20)   NOT NULL,           -- code stable, ex. DQ-03
    RuleName               nvarchar(200)  NOT NULL,
    [Description]          nvarchar(max)  NULL,               -- explication du contrôle (calcul)
    GrainName              nvarchar(50)   NOT NULL,           -- granularité de restitution, ex. Train
    GrainDefinitionJson    nvarchar(1000) NOT NULL,           -- composants ordonnés, ex. ["TrainNumber","CirculationDate"]
    SequenceOrder          int            NOT NULL,           -- ordre de lancement
    Severity               nvarchar(20)   NULL,               -- niveau de criticité (à trancher)
    StoredProc             nvarchar(300)  NOT NULL,           -- ex. audit.usp_DQ_BR_DQ03_RemiseZeroTerminus
    IsActive               bit            NOT NULL CONSTRAINT DF_ReglesDQ_IsActive DEFAULT (1),
    ThresholdLow           decimal(19,6)  NULL,
    ThresholdMedium        decimal(19,6)  NULL,
    ThresholdHigh          decimal(19,6)  NULL,
    ThresholdUnit          nvarchar(30)   NULL,               -- ratio, nombre...
    ThresholdDescription   nvarchar(1000) NULL,
    RuleVersion            nvarchar(20)   NOT NULL CONSTRAINT DF_ReglesDQ_Version DEFAULT (N'1.0'),
    DataGalaxyId           nvarchar(100)  NULL,               -- prêt pour DataGalaxy (hors flux V1)
    DataGalaxyUrl          nvarchar(500)  NULL,
    CreatedAt              datetime2(0)   NOT NULL CONSTRAINT DF_ReglesDQ_Created DEFAULT (SYSUTCDATETIME()),
    UpdatedAt              datetime2(0)   NOT NULL CONSTRAINT DF_ReglesDQ_Updated DEFAULT (SYSUTCDATETIME()),
    -- ---- extensions [EXT] ----
    DetailGrainsJson       nvarchar(2000) NULL,               -- [EXT] mailles de détail écrites par la procédure (ARRET, EVN)
    ParamsJson             nvarchar(2000) NULL,               -- [EXT] paramètres hors seuils, dont la variante de calcul
    ScoreWeight            decimal(9,4)   NOT NULL CONSTRAINT DF_ReglesDQ_Weight DEFAULT (1),  -- [EXT] poids dans le score (0 = exclu)
    StatutValidation       nvarchar(30)   NOT NULL CONSTRAINT DF_ReglesDQ_Valid DEFAULT (N'VALIDEE'),  -- [EXT] VALIDEE | A_TRANCHER | ATTEND_PO_SIV
    ChoixValides           nvarchar(max)  NULL,               -- [EXT] choix métier validés (texte du dashboard)
    CONSTRAINT PK_ReglesDQ PRIMARY KEY CLUSTERED (RegleDQID),
    CONSTRAINT UQ_ReglesDQ_Source_Code UNIQUE (SourceName, RuleCode),
    CONSTRAINT CK_ReglesDQ_GrainJson CHECK (ISJSON(GrainDefinitionJson) = 1),
    CONSTRAINT CK_ReglesDQ_ParamsJson CHECK (ParamsJson IS NULL OR ISJSON(ParamsJson) = 1),
    CONSTRAINT CK_ReglesDQ_DetailJson CHECK (DetailGrainsJson IS NULL OR ISJSON(DetailGrainsJson) = 1)
);
GO

-- Historique des modifications du catalogue (traçabilité de la gouvernance)
-- But : historique des modifications du catalogue (alimenté par le trigger).
IF OBJECT_ID(N'audit.ReglesDQ_Historique', N'U') IS NULL
CREATE TABLE audit.ReglesDQ_Historique
(
    HistoriqueId   bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_ReglesDQ_Historique PRIMARY KEY,
    RegleDQID      int           NOT NULL,
    Operation      varchar(10)   NOT NULL,
    ModifieLe      datetime2(0)  NOT NULL CONSTRAINT DF_ReglesDQ_Histo_Date DEFAULT (SYSUTCDATETIME()),
    ModifiePar     nvarchar(128) NOT NULL CONSTRAINT DF_ReglesDQ_Histo_User DEFAULT (SUSER_SNAME()),
    AvantJson      nvarchar(max) NULL,
    ApresJson      nvarchar(max) NULL
);
GO
-- But : trigger : copie chaque modification du catalogue dans l'historique (gouvernance).
CREATE OR ALTER TRIGGER audit.trg_ReglesDQ_Historique
ON audit.ReglesDQ AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    INSERT audit.ReglesDQ_Historique (RegleDQID, Operation, AvantJson, ApresJson)
    SELECT d.RegleDQID, 'UPDATE',
           (SELECT d2.* FROM deleted AS d2 WHERE d2.RegleDQID = d.RegleDQID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
           (SELECT i2.* FROM inserted AS i2 WHERE i2.RegleDQID = d.RegleDQID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM deleted AS d;
    UPDATE r SET UpdatedAt = SYSUTCDATETIME()
    FROM audit.ReglesDQ AS r JOIN inserted AS i ON i.RegleDQID = r.RegleDQID;
END;
GO

-- ---------------------------------------------------------------------------
-- 3. Paramètres du score (équivalent de config/score_config.json)
-- ---------------------------------------------------------------------------
-- But : paramètres du score et de l'exploitation (points par statut, seuils de verdict, fenêtre par
-- défaut, rétention).
IF OBJECT_ID(N'audit.ParametresDQ', N'U') IS NULL
CREATE TABLE audit.ParametresDQ
(
    SourceName   nvarchar(50)   NOT NULL,
    Cle          nvarchar(60)   NOT NULL,
    Valeur       nvarchar(200)  NOT NULL,
    [Description] nvarchar(500) NULL,
    CONSTRAINT PK_ParametresDQ PRIMARY KEY CLUSTERED (SourceName, Cle)
);
GO

-- ---------------------------------------------------------------------------
-- 4. Exécutions : un ExecutionId par lancement de l'orchestrateur
-- ---------------------------------------------------------------------------
-- But : une ligne par lancement du pipeline : fenêtre de dates, statut, corrélation SSIS facultative.
IF OBJECT_ID(N'audit.ExecutionsDQ', N'U') IS NULL
CREATE TABLE audit.ExecutionsDQ
(
    ExecutionId        bigint        NOT NULL,
    SourceName         nvarchar(50)  NOT NULL,
    DateDebut          date          NOT NULL,              -- fenêtre de contrôle (CirculationDate)
    DateFin            date          NOT NULL,
    ExecutionDateTime  datetime2(0)  NOT NULL CONSTRAINT DF_ExecDQ_Start DEFAULT (SYSUTCDATETIME()),
    EndDateTime        datetime2(0)  NULL,
    Statut             varchar(20)   NOT NULL CONSTRAINT DF_ExecDQ_Statut DEFAULT ('EnCours'),
                                                             -- EnCours | Succes | SuccesPartiel | Echec
    LanceePar          nvarchar(128) NOT NULL CONSTRAINT DF_ExecDQ_User DEFAULT (SUSER_SNAME()),
    SsisExecutionId    bigint        NULL,                  -- corrélation avec le catalogue SSISDB (facultatif)
    NbReglesLancees    int           NULL,
    NbReglesEnErreur   int           NULL,
    NbTrains           int           NULL,
    Message            nvarchar(2000) NULL,
    CONSTRAINT PK_ExecutionsDQ PRIMARY KEY CLUSTERED (ExecutionId),
    CONSTRAINT CK_ExecutionsDQ_Statut CHECK (Statut IN ('EnCours', 'Succes', 'SuccesPartiel', 'Echec'))
);
GO

-- But : une ligne par règle et par exécution : durée, nombre de résultats, erreur technique.
IF OBJECT_ID(N'audit.ExecutionsRegleDQ', N'U') IS NULL
CREATE TABLE audit.ExecutionsRegleDQ
(
    ExecutionId   bigint        NOT NULL,
    RegleDQID     int           NOT NULL,
    DebutUtc      datetime2(3)  NOT NULL,
    FinUtc        datetime2(3)  NULL,
    DureeMs       int           NULL,
    NbResultats   int           NULL,
    Statut        varchar(10)   NOT NULL,                   -- Succes | Erreur
    ErrorNumber   int           NULL,
    ErrorMessage  nvarchar(2000) NULL,
    CONSTRAINT PK_ExecutionsRegleDQ PRIMARY KEY CLUSTERED (ExecutionId, RegleDQID)
);
GO

-- But : résultat des contrôles techniques du staging (BLOQUANT, AVERTISSEMENT, INFO).
IF OBJECT_ID(N'audit.ControlesTechniquesDQ', N'U') IS NULL
CREATE TABLE audit.ControlesTechniquesDQ
(
    ControleId    bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_ControlesTechniquesDQ PRIMARY KEY,
    ExecutionId   bigint        NOT NULL,
    ControleCode  varchar(40)   NOT NULL,
    Niveau        varchar(15)   NOT NULL,                   -- BLOQUANT | AVERTISSEMENT | INFO
    NbLignes      bigint        NULL,
    Detail        nvarchar(1000) NULL,
    CreatedAt     datetime2(0)  NOT NULL CONSTRAINT DF_CtlTech_Date DEFAULT (SYSUTCDATETIME())
);
GO

-- ---------------------------------------------------------------------------
-- 5. Logs : une ligne = le résultat d'une règle sur un objet contrôlé, pour une exécution
-- ---------------------------------------------------------------------------
-- But : JOURNAL CENTRAL : une ligne = le résultat d'une règle sur un objet (train, arrêt ou véhicule)
-- pour une exécution. Columnstore.
IF OBJECT_ID(N'audit.LogsDQ', N'U') IS NULL
CREATE TABLE audit.LogsDQ
(
    LogDQID          bigint IDENTITY(1,1) NOT NULL,
    ExecutionId      bigint         NOT NULL,
    RunId            varchar(130)   NOT NULL,              -- identifiant métier lisible de l'objet contrôlé
    RegleDQID        int            NOT NULL,
    [Status]         varchar(12)    NOT NULL,
    FailureReason    varchar(60)    NULL,                  -- code de la raison métier (FAIL, NOT_TESTED)
    ObservedValue    nvarchar(4000) NULL,                  -- JSON : champs et valeurs du calcul
    ExpectedValue    nvarchar(100)  NULL,
    AbsoluteGap      decimal(19,6)  NULL,
    RelativeGap      decimal(19,6)  NULL,
    GrainValuesJson  nvarchar(1000) NULL,                  -- JSON : [{"name":..., "value":...}]
    ErrorDescription nvarchar(1000) NULL,                  -- erreur technique éventuelle
    -- ---- extensions [EXT] ----
    GrainLevel       tinyint        NOT NULL,              -- [EXT] 1 = Train, 2 = Arrêt, 3 = Véhicule (EVN)
    SourceKey        bigint         NOT NULL,              -- [EXT] CountingId de la ligne source
    WindowDate       date           NOT NULL,              -- [EXT] date de circulation (fenêtre, purge, partition)
    IsCurrent        bit            NOT NULL CONSTRAINT DF_LogsDQ_IsCurrent DEFAULT (1),  -- [EXT] dernier résultat de l'objet
    CONSTRAINT PK_LogsDQ PRIMARY KEY NONCLUSTERED (LogDQID),
    CONSTRAINT CK_LogsDQ_Status CHECK ([Status] IN ('PASS','WARNING','FAIL','CRITICAL','NOT_TESTED','N/A','MEASURE')),
    CONSTRAINT CK_LogsDQ_Grain CHECK (GrainLevel IN (1, 2, 3)),
    CONSTRAINT CK_LogsDQ_ObservedJson CHECK (ObservedValue IS NULL OR ISJSON(ObservedValue) = 1),
    CONSTRAINT CK_LogsDQ_GrainJson CHECK (GrainValuesJson IS NULL OR ISJSON(GrainValuesJson) = 1)
);
GO
-- But : index columnstore clusterisé du journal (compression, lectures analytiques).
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'CCI_LogsDQ' AND object_id = OBJECT_ID(N'audit.LogsDQ'))
    CREATE CLUSTERED COLUMNSTORE INDEX CCI_LogsDQ ON audit.LogsDQ;
GO
-- But : index de recherche par exécution et règle (réécriture rejouable).
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_LogsDQ_Exec_Regle' AND object_id = OBJECT_ID(N'audit.LogsDQ'))
    CREATE NONCLUSTERED INDEX IX_LogsDQ_Exec_Regle ON audit.LogsDQ (ExecutionId, RegleDQID);
-- But : index filtré sur les résultats courants (IsCurrent = 1).
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_LogsDQ_Courant' AND object_id = OBJECT_ID(N'audit.LogsDQ'))
    CREATE NONCLUSTERED INDEX IX_LogsDQ_Courant ON audit.LogsDQ (RegleDQID, WindowDate) WHERE IsCurrent = 1;
GO

-- ---------------------------------------------------------------------------
-- 6. Scores : un score par train (GrainLevel 1) et par arrêt (GrainLevel 2) et par exécution
-- ---------------------------------------------------------------------------
-- But : score, couverture, verdict et imputation par train (niveau 1) et par arrêt (niveau 2).
IF OBJECT_ID(N'audit.ScoresDQ', N'U') IS NULL
CREATE TABLE audit.ScoresDQ
(
    ScoreDQID          bigint IDENTITY(1,1) NOT NULL,
    ExecutionId        bigint         NOT NULL,
    SourceName         nvarchar(50)   NOT NULL,
    GrainLevel         tinyint        NOT NULL,            -- 1 = Train, 2 = Arrêt
    SourceKey          bigint         NOT NULL,            -- CountingId
    Rang               smallint       NULL,                -- arrêt (GrainLevel 2)
    WindowDate         date           NOT NULL,
    Score              decimal(5,1)   NULL,
    Couverture         decimal(5,1)   NULL,
    Verdict            nvarchar(20)   NOT NULL,            -- Bonne | À surveiller | Mauvaise | Non évaluable
    PartArretsMesures  decimal(5,1)   NULL,                -- Train
    Imputation         nvarchar(20)   NULL,                -- Train : Rien à imputer | Imputer | Exclure
    PositionManquants  nvarchar(40)   NULL,
    ArretsAImputer     nvarchar(1000) NULL,
    IsCurrent          bit            NOT NULL CONSTRAINT DF_ScoresDQ_IsCurrent DEFAULT (1),
    CONSTRAINT PK_ScoresDQ PRIMARY KEY NONCLUSTERED (ScoreDQID)
);
GO
-- But : index columnstore clusterisé des scores.
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'CCI_ScoresDQ' AND object_id = OBJECT_ID(N'audit.ScoresDQ'))
    CREATE CLUSTERED COLUMNSTORE INDEX CCI_ScoresDQ ON audit.ScoresDQ;
-- But : index de recherche des scores par exécution.
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_ScoresDQ_Exec' AND object_id = OBJECT_ID(N'audit.ScoresDQ'))
    CREATE NONCLUSTERED INDEX IX_ScoresDQ_Exec ON audit.ScoresDQ (ExecutionId, GrainLevel);
GO

-- ---------------------------------------------------------------------------
-- 7. Fonction de construction du RunId (identifiant métier lisible)
--    RunId = composants de la granularité séparés par « | » (NULL ignorés)
-- ---------------------------------------------------------------------------
-- But : fonction : construit l'identifiant métier lisible d'un objet (train|date|rang|EVN).
CREATE OR ALTER FUNCTION audit.fn_BuildRunId
(
    @V1 nvarchar(100), @V2 nvarchar(100), @V3 nvarchar(100), @V4 nvarchar(100), @V5 nvarchar(100)
)
RETURNS varchar(130)
AS
BEGIN
    RETURN CONVERT(varchar(130), CONCAT_WS(N'|', @V1, @V2, @V3, @V4, @V5));
END;
GO

-- ---------------------------------------------------------------------------
-- 8. Quelques contrôles de cohérence du catalogue (utilisés par l'orchestrateur)
-- ---------------------------------------------------------------------------
-- (voir 07_ecriture_et_orchestrateur.sql : la liste blanche des procédures y est appliquée)
GO

-- ---------------------------------------------------------------------------
-- 9. DELTA IDEMPOTENT pour des tables DEJA existantes en DEV : ajoute les extensions [EXT]
--    (à exécuter seulement si les sections 2 et 5 ont été sautées)
-- ---------------------------------------------------------------------------
/*
-- But : delta idempotent. Si une V1 existe déjà, ajoute les colonnes [EXT] manquantes sans toucher aux
-- données.
IF COL_LENGTH(N'audit.ReglesDQ', N'DetailGrainsJson') IS NULL ALTER TABLE audit.ReglesDQ ADD DetailGrainsJson nvarchar(2000) NULL;
IF COL_LENGTH(N'audit.ReglesDQ', N'ParamsJson')       IS NULL ALTER TABLE audit.ReglesDQ ADD ParamsJson nvarchar(2000) NULL;
IF COL_LENGTH(N'audit.ReglesDQ', N'ScoreWeight')      IS NULL ALTER TABLE audit.ReglesDQ ADD ScoreWeight decimal(9,4) NOT NULL CONSTRAINT DF_ReglesDQ_Weight DEFAULT (1);
IF COL_LENGTH(N'audit.ReglesDQ', N'StatutValidation') IS NULL ALTER TABLE audit.ReglesDQ ADD StatutValidation nvarchar(30) NOT NULL CONSTRAINT DF_ReglesDQ_Valid DEFAULT (N'VALIDEE');
IF COL_LENGTH(N'audit.ReglesDQ', N'ChoixValides')     IS NULL ALTER TABLE audit.ReglesDQ ADD ChoixValides nvarchar(max) NULL;
IF COL_LENGTH(N'audit.LogsDQ', N'GrainLevel')  IS NULL ALTER TABLE audit.LogsDQ ADD GrainLevel tinyint NOT NULL CONSTRAINT DF_LogsDQ_GrainLevel DEFAULT (1);
IF COL_LENGTH(N'audit.LogsDQ', N'SourceKey')   IS NULL ALTER TABLE audit.LogsDQ ADD SourceKey bigint NOT NULL CONSTRAINT DF_LogsDQ_SourceKey DEFAULT (0);
IF COL_LENGTH(N'audit.LogsDQ', N'WindowDate')  IS NULL ALTER TABLE audit.LogsDQ ADD WindowDate date NOT NULL CONSTRAINT DF_LogsDQ_WindowDate DEFAULT ('19000101');
IF COL_LENGTH(N'audit.LogsDQ', N'IsCurrent')   IS NULL ALTER TABLE audit.LogsDQ ADD IsCurrent bit NOT NULL CONSTRAINT DF_LogsDQ_IsCurrent DEFAULT (1);
*/
GO

/*==============================================================================
 ÉTAPE 05/27 - Fonctions de lecture des valeurs JSON
 Source : sql/04_fonctions_parsing.sql
 But : Deux fonctions qui lisent une valeur JSON et distinguent « lue », «
 absente » et « illisible ».
===============================================================================*/

/*
================================================================================
 04 - Fonction de lecture d'une valeur de comptage
================================================================================
 Équivalent SQL de val() / csv_val() du moteur Python (src/dq_engine.py) :
   St = 1 (absente)   : valeur NULL, vide ou chaîne 'NULL'
   St = 2 (illisible) : valeur non entière (texte, booléen, décimal non entier)
   St = 0 (lue)       : entier, chaîne d'entier, ou nombre décimal entier (3.0)
 Fonction table en ligne (inlinée par l'optimiseur, pas de coût de fonction scalaire).
 Usage : CROSS APPLY comptage_API.fn_DQ_Val(JSON_VALUE(p.StopJson, '$.occupancy.allClasses')) AS occ
================================================================================
*/
-- But : fonction : lit une valeur numérique JSON et renvoie la valeur et son état (0 lue, 1 absente, 2
-- illisible). Distingue « absente » de « zéro ».
CREATE OR ALTER FUNCTION comptage_API.fn_DQ_Val (@v nvarchar(4000))
RETURNS TABLE
AS
RETURN
(
    SELECT
        Val = y.n,
        St  = CAST(CASE WHEN x.t IS NULL THEN 1 WHEN y.n IS NULL THEN 2 ELSE 0 END AS tinyint)
    FROM (SELECT t = NULLIF(NULLIF(LTRIM(RTRIM(@v)), N''), N'NULL')) AS x
    CROSS APPLY (
        SELECT n = COALESCE(
                       TRY_CONVERT(bigint, x.t),
                       CASE WHEN TRY_CONVERT(decimal(38, 6), x.t) = ROUND(TRY_CONVERT(decimal(38, 6), x.t), 0)
                            THEN TRY_CONVERT(bigint, TRY_CONVERT(decimal(38, 6), x.t)) END)
    ) AS y
);
GO

-- Lecture d'un pourcentage de fiabilité capteur : 0 sans donnée, 1 valide (>= 100), 2 invalide
-- But : fonction : lit le pourcentage de fiabilité d'un capteur et renvoie son état (0 sans donnée, 1
-- valide, 2 invalide).
CREATE OR ALTER FUNCTION comptage_API.fn_DQ_EtatCapteur (@v nvarchar(4000))
RETURNS TABLE
AS
RETURN
(
    SELECT Pct = f.Val,
           Etat = CAST(CASE WHEN f.St <> 0 THEN 0 WHEN f.Val >= 100 THEN 1 ELSE 2 END AS tinyint)
    FROM comptage_API.fn_DQ_Val(@v) AS f
);
GO

/*==============================================================================
 ÉTAPE 06/27 - Procédures de staging, contrôles techniques et parsing
 Source : sql/05_proc_staging_parsing.sql
 But : Copie la fenêtre depuis la source, contrôle sa qualité technique, puis
 éclate le JSON dans les tables typées.
===============================================================================*/

/*
================================================================================
 05 - Procédures de staging, contrôle technique et parsing JSON
================================================================================
 Ordre d'appel (assuré par audit.usp_DQ_Pipeline_SIV_APC, fichier 11) :
   1. comptage_API.usp_DQ_ChargerStaging       copie typée de la fenêtre depuis la source
   2. comptage_API.usp_DQ_ControlerStaging     contrôles techniques (bloquants / avertissements)
   3. comptage_API.usp_DQ_ParserStaging        éclatement des JSON en Train / Arret / ArretEVN / EVNAttendu
 Fenêtre : @DateDebut..@DateFin inclus, sur CirculationDate.
================================================================================
*/
-- ---------------------------------------------------------------------------
-- 1. Staging : photographie de la fenêtre
-- ---------------------------------------------------------------------------
-- But : copie typée de la fenêtre depuis la source vers le staging (un seul enregistrement par train,
-- le plus récent).
CREATE OR ALTER PROCEDURE comptage_API.usp_DQ_ChargerStaging
    @DateDebut date,
    @DateFin   date
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;

    -- But : vider le staging avant de le recharger avec la fenêtre.
    TRUNCATE TABLE comptage_API.DQ_StgTrain;

    -- Une seule ligne par CountingId : en cas de double chargement SSIS, on garde le plus récent.
    -- But : numéroter les doublons de chargement SSIS (CountingId) pour ne garder que la ligne la plus
    -- récente.
    ;WITH s AS (
        SELECT v.*, rn = ROW_NUMBER() OVER (PARTITION BY v.CountingId ORDER BY v.LoadDateTime DESC)
        FROM comptage_API.vw_DQ_SourceTrain AS v
        WHERE v.CountingId IS NOT NULL
          AND v.CirculationDate BETWEEN @DateDebut AND @DateFin
    )
    -- But : copier les trains de la fenêtre, avec deux indicateurs de validité (JSON lisible, clé présente).
    INSERT comptage_API.DQ_StgTrain
        (CountingId, CirculationDate, LoadDateTime, TravelId, TrainNumber, Variant, TrainType, Series, LineCode,
         DepartureStation, ArrivalStation, HeadEVN, IsDegraded, HasComposition,
         TotalCapacityTxt, TotalOccupancyTxt, OccupancyRatePercentTxt,
         EuropeanVehicleNumbersJson, StopsJson, JsonValide, CleValide)
    SELECT CountingId, CirculationDate, LoadDateTime, TravelId, TrainNumber, Variant, TrainType, Series, LineCode,
           DepartureStation, ArrivalStation, HeadEVN, IsDegraded, HasComposition,
           TotalCapacityTxt, TotalOccupancyTxt, OccupancyRatePercentTxt,
           EuropeanVehicleNumbersJson, StopsJson,
           JsonValide = CASE WHEN ISJSON(StopsJson) = 1 AND ISJSON(EuropeanVehicleNumbersJson) = 1 THEN 1 ELSE 0 END,
           CleValide  = CASE WHEN TrainNumber IS NOT NULL AND CirculationDate IS NOT NULL THEN 1 ELSE 0 END
    FROM s
    WHERE rn = 1;
END;
GO

-- ---------------------------------------------------------------------------
-- 2. Contrôles techniques du staging (équivalent de l'étape « Contrôler la staging »)
--    BLOQUANT : l'exception arrête le pipeline ; AVERTISSEMENT : journalisé, la ligne est écartée
-- ---------------------------------------------------------------------------
-- But : contrôles techniques du staging : volume, JSON valides, clés. Un contrôle BLOQUANT arrête le
-- pipeline.
CREATE OR ALTER PROCEDURE comptage_API.usp_DQ_ControlerStaging
    @ExecutionId bigint
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    DECLARE @n bigint, @nbloq bigint;

    -- But : contrôle BLOQUANT si la fenêtre ne contient aucun train.
    SELECT @n = COUNT_BIG(*) FROM comptage_API.DQ_StgTrain;
    INSERT audit.ControlesTechniquesDQ (ExecutionId, ControleCode, Niveau, NbLignes, Detail)
    VALUES (@ExecutionId, 'STG_LIGNES', CASE WHEN @n = 0 THEN 'BLOQUANT' ELSE 'INFO' END, @n,
            N'Trains chargés dans la fenêtre');

    -- But : signaler les trains dont le JSON est illisible (ils sont écartés).
    INSERT audit.ControlesTechniquesDQ (ExecutionId, ControleCode, Niveau, NbLignes, Detail)
    SELECT @ExecutionId, 'JSON_INVALIDE', 'AVERTISSEMENT', COUNT_BIG(*),
           N'Trains écartés : StopsJson ou EuropeanVehicleNumbersJson n''est pas un JSON valide'
    FROM comptage_API.DQ_StgTrain WHERE JsonValide = 0 HAVING COUNT_BIG(*) > 0;

    INSERT audit.ControlesTechniquesDQ (ExecutionId, ControleCode, Niveau, NbLignes, Detail)
    SELECT @ExecutionId, 'CLE_ABSENTE', 'AVERTISSEMENT', COUNT_BIG(*),
           N'Trains écartés : TrainNumber ou CirculationDate absent'
    FROM comptage_API.DQ_StgTrain WHERE CleValide = 0 HAVING COUNT_BIG(*) > 0;

    -- Unicité (TrainNumber, CirculationDate) : indispensable au RunId (voir choix à trancher)
    INSERT audit.ControlesTechniquesDQ (ExecutionId, ControleCode, Niveau, NbLignes, Detail)
    SELECT @ExecutionId, 'DOUBLON_TRAIN_DATE', 'BLOQUANT', COUNT_BIG(*),
           N'Couples (TrainNumber, CirculationDate) présents plusieurs fois'
    FROM (SELECT TrainNumber, CirculationDate FROM comptage_API.DQ_StgTrain
          WHERE JsonValide = 1 AND CleValide = 1
          GROUP BY TrainNumber, CirculationDate HAVING COUNT(*) > 1) AS d
    HAVING COUNT_BIG(*) > 0;

    SELECT @nbloq = COUNT_BIG(*) FROM audit.ControlesTechniquesDQ WHERE ExecutionId = @ExecutionId AND Niveau = 'BLOQUANT';
    IF @nbloq > 0
        THROW 50010, N'Contrôle technique bloquant du staging : voir audit.ControlesTechniquesDQ.', 1;
END;
GO

-- ---------------------------------------------------------------------------
-- 3. Parsing JSON : staging -> Train / Arret / ArretEVN / EVNAttendu
--    Réentrant : supprime puis recrée les lignes de la fenêtre dans une seule transaction.
-- ---------------------------------------------------------------------------
-- But : éclate StopsJson et EuropeanVehicleNumbersJson UNE SEULE fois dans Train, Arret, ArretEVN et
-- EVNAttendu, puis calcule le cumul des flux et les compteurs.
CREATE OR ALTER PROCEDURE comptage_API.usp_DQ_ParserStaging
    @DateDebut   date,
    @DateFin     date,
    @ExecutionId bigint = NULL
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;

    -- Arrêts éclatés une fois, dans une table temporaire (le JSON des véhicules est relu ensuite)
    -- But : éclater StopsJson UNE fois (un arrêt par ligne) ; le JSON des véhicules est relu ensuite depuis
    -- cette table.
    CREATE TABLE #Stops
    (
        CountingId bigint NOT NULL, Rang smallint NOT NULL,
        CirculationDate date NOT NULL, TrainNumber nvarchar(20) NOT NULL,
        StopJson nvarchar(max) NOT NULL,
        PRIMARY KEY (CountingId, Rang)
    );
    INSERT #Stops (CountingId, Rang, CirculationDate, TrainNumber, StopJson)
    SELECT s.CountingId, CAST(CAST(j.[key] AS int) + 1 AS smallint), s.CirculationDate, s.TrainNumber, j.value
    FROM comptage_API.DQ_StgTrain AS s
    CROSS APPLY OPENJSON(s.StopsJson) AS j
    WHERE s.JsonValide = 1 AND s.CleValide = 1 AND j.[type] = 5;      -- 5 = objet

    -- But : tout le parsing d'une fenêtre est une transaction unique (rejouable, jamais à moitié fait).
    BEGIN TRAN;

    -- But : effacer le parsing précédent de la fenêtre (on supprime d'abord les tables filles).
    DELETE FROM comptage_API.DQ_ArretEVN   WHERE CirculationDate BETWEEN @DateDebut AND @DateFin;
    DELETE FROM comptage_API.DQ_EVNAttendu WHERE CirculationDate BETWEEN @DateDebut AND @DateFin;
    DELETE FROM comptage_API.DQ_Arret      WHERE CirculationDate BETWEEN @DateDebut AND @DateFin;
    DELETE FROM comptage_API.DQ_Train      WHERE CirculationDate BETWEEN @DateDebut AND @DateFin;

    -- ---- Train ----
    -- But : remplir DQ_Train (identité, totaux et états de lecture, nombre d'EVN attendus).
    INSERT comptage_API.DQ_Train
        (CountingId, RunId, CirculationDate, TrainNumber, Variant, TravelId, TrainType, Series, LineCode,
         DepartureStation, ArrivalStation, HeadEVN, IsDegraded, HasComposition,
         TotalCapacity, CapSt, TotalOccupancy, OccSt, RateSt, NbEvnExpected, LoadDateTime)
    SELECT s.CountingId,
           audit.fn_BuildRunId(s.TrainNumber, CONVERT(nvarchar(10), s.CirculationDate, 23), NULL, NULL, NULL),
           s.CirculationDate, s.TrainNumber, s.Variant, s.TravelId, s.TrainType, s.Series, s.LineCode,
           s.DepartureStation, s.ArrivalStation, s.HeadEVN, s.IsDegraded, s.HasComposition,
           CAST(cap.Val AS int), cap.St, CAST(occ.Val AS int), occ.St,
           CAST(CASE WHEN rate.t IS NULL THEN 1 WHEN TRY_CONVERT(decimal(18, 4), rate.t) IS NULL THEN 2 ELSE 0 END AS tinyint),
           (SELECT COUNT(DISTINCT e.value) FROM OPENJSON(s.EuropeanVehicleNumbersJson) AS e),
           s.LoadDateTime
    FROM comptage_API.DQ_StgTrain AS s
    CROSS APPLY comptage_API.fn_DQ_Val(s.TotalCapacityTxt)  AS cap
    CROSS APPLY comptage_API.fn_DQ_Val(s.TotalOccupancyTxt) AS occ
    CROSS APPLY (SELECT t = NULLIF(NULLIF(LTRIM(RTRIM(s.OccupancyRatePercentTxt)), N''), N'NULL')) AS rate
    WHERE s.JsonValide = 1 AND s.CleValide = 1;

    -- ---- EVN attendus (composition attendue) ----
    -- But : remplir la composition attendue (liste d'EVN du JSON).
    INSERT comptage_API.DQ_EVNAttendu (CountingId, EVN, CirculationDate)
    SELECT DISTINCT s.CountingId, CAST(e.value AS nvarchar(20)), s.CirculationDate
    FROM comptage_API.DQ_StgTrain AS s
    CROSS APPLY OPENJSON(s.EuropeanVehicleNumbersJson) AS e
    WHERE s.JsonValide = 1 AND s.CleValide = 1 AND e.[type] = 1;       -- 1 = chaîne

    -- ---- Arrêts ----
    -- But : remplir DQ_Arret (un arrêt par ligne : gare, type, occupation, montées, descentes, capacité,
    -- heure).
    INSERT comptage_API.DQ_Arret
        (CountingId, Rang, RunId, CirculationDate, TrainNumber, StationCode, StationName, StopType,
         StationPassed, IsDegraded,
         Occ, OccSt, Boarding, BoardingSt, Alighting, AlightingSt, Capacity, CapacitySt,
         HasData, NbEvnObs, Heure)
    SELECT p.CountingId, p.Rang,
           audit.fn_BuildRunId(p.TrainNumber, CONVERT(nvarchar(10), p.CirculationDate, 23), CAST(p.Rang AS nvarchar(10)), NULL, NULL),
           p.CirculationDate, p.TrainNumber,
           JSON_VALUE(p.StopJson, '$.stationCode'), JSON_VALUE(p.StopJson, '$.stationName'),
           JSON_VALUE(p.StopJson, '$.stopType'),
           CASE JSON_VALUE(p.StopJson, '$.stationPassed') WHEN 'true' THEN 1 WHEN 'false' THEN 0 END,
           CASE JSON_VALUE(p.StopJson, '$.isDegraded')    WHEN 'true' THEN 1 WHEN 'false' THEN 0 END,
           CAST(o.Val AS int), o.St, CAST(b.Val AS int), b.St, CAST(a.Val AS int), a.St, CAST(c.Val AS int), c.St,
           CAST(CASE WHEN o.St = 0 THEN 1 ELSE 0 END AS bit),
           0,
           CASE WHEN h.t IS NOT NULL AND LEN(h.t) >= 2 AND LEFT(h.t, 2) LIKE '[0-9][0-9]' AND CAST(LEFT(h.t, 2) AS int) < 24
                THEN CAST(LEFT(h.t, 2) AS tinyint) END
    FROM #Stops AS p
    CROSS APPLY comptage_API.fn_DQ_Val(JSON_VALUE(p.StopJson, '$.occupancy.allClasses'))  AS o
    CROSS APPLY comptage_API.fn_DQ_Val(JSON_VALUE(p.StopJson, '$.boarding.allClasses'))   AS b
    CROSS APPLY comptage_API.fn_DQ_Val(JSON_VALUE(p.StopJson, '$.alighting.allClasses'))  AS a
    CROSS APPLY comptage_API.fn_DQ_Val(JSON_VALUE(p.StopJson, '$.capacity.allClasses'))   AS c
    CROSS APPLY (SELECT t = COALESCE(JSON_VALUE(p.StopJson, '$.actualArrivalTime'),
                                     JSON_VALUE(p.StopJson, '$.actualDepartureTime'))) AS h;

    -- ---- Véhicules à l'arrêt ----
    -- But : remplir DQ_ArretEVN (un véhicule par arrêt : occupation, montées/descentes 1re+2e classe,
    -- fiabilité des capteurs).
    INSERT comptage_API.DQ_ArretEVN
        (CountingId, Rang, VehIdx, RunId, CirculationDate, TrainNumber, EVN, Position, SerieVehicule,
         Occ, OccSt, SensorCapacity, SensorCapSt, Boarding, BoardingSt, Alighting, AlightingSt,
         ExtPct, IntPct, ExtEtat, IntEtat)
    SELECT p.CountingId, p.Rang, CAST(v.[key] AS smallint),
           audit.fn_BuildRunId(p.TrainNumber, CONVERT(nvarchar(10), p.CirculationDate, 23), CAST(p.Rang AS nvarchar(10)),
                               JSON_VALUE(v.value, '$.europeanVehicleNumber'), NULL),
           p.CirculationDate, p.TrainNumber,
           COALESCE(JSON_VALUE(v.value, '$.europeanVehicleNumber'), N''),
           TRY_CONVERT(smallint, JSON_VALUE(v.value, '$.compositionVehiclePosition')),
           JSON_VALUE(v.value, '$.series'),
           CAST(o.Val AS int), o.St, CAST(c.Val AS int), c.St,
           -- montées / descentes d'un véhicule = 1re classe + 2e classe (jamais allClasses dans la donnée)
           CASE WHEN bst.s = 0 THEN CAST(COALESCE(b1.Val, 0) + COALESCE(b2.Val, 0) AS int) END, bst.s,
           CASE WHEN ast.s = 0 THEN CAST(COALESCE(a1.Val, 0) + COALESCE(a2.Val, 0) AS int) END, ast.s,
           CAST(ex.Pct AS int), CAST(it.Pct AS int), ex.Etat, it.Etat
    FROM #Stops AS p
    CROSS APPLY OPENJSON(p.StopJson, '$.vehicles') AS v
    CROSS APPLY comptage_API.fn_DQ_Val(JSON_VALUE(v.value, '$.occupancy.allClasses'))        AS o
    CROSS APPLY comptage_API.fn_DQ_Val(JSON_VALUE(v.value, '$.sensorCapacity.allClasses'))   AS c
    CROSS APPLY comptage_API.fn_DQ_Val(JSON_VALUE(v.value, '$.boarding.firstClass'))         AS b1
    CROSS APPLY comptage_API.fn_DQ_Val(JSON_VALUE(v.value, '$.boarding.secondClass'))        AS b2
    CROSS APPLY comptage_API.fn_DQ_Val(JSON_VALUE(v.value, '$.alighting.firstClass'))        AS a1
    CROSS APPLY comptage_API.fn_DQ_Val(JSON_VALUE(v.value, '$.alighting.secondClass'))       AS a2
    CROSS APPLY (SELECT s = CAST(CASE WHEN b1.St = 2 OR b2.St = 2 THEN 2 WHEN b1.St = 1 AND b2.St = 1 THEN 1 ELSE 0 END AS tinyint)) AS bst
    CROSS APPLY (SELECT s = CAST(CASE WHEN a1.St = 2 OR a2.St = 2 THEN 2 WHEN a1.St = 1 AND a2.St = 1 THEN 1 ELSE 0 END AS tinyint)) AS ast
    CROSS APPLY comptage_API.fn_DQ_EtatCapteur(JSON_VALUE(v.value, '$.reliability.exteriorPercent')) AS ex
    CROSS APPLY comptage_API.fn_DQ_EtatCapteur(JSON_VALUE(v.value, '$.reliability.interiorPercent')) AS it
    WHERE v.[type] = 5;

    -- ---- Compteurs et colonnes dérivées ----
    -- But : compter les véhicules observés à chaque arrêt.
    UPDATE a SET NbEvnObs = x.n
    FROM comptage_API.DQ_Arret AS a
    JOIN (SELECT CountingId, Rang, n = COUNT(DISTINCT EVN)
          FROM comptage_API.DQ_ArretEVN WHERE CirculationDate BETWEEN @DateDebut AND @DateFin
          GROUP BY CountingId, Rang) AS x ON x.CountingId = a.CountingId AND x.Rang = a.Rang;

    -- Cumul des flux depuis l'origine : partagé par DQ-01 (reconstruction) et DQ-10 (occupation non négative)
    -- But : cumul des flux (montées - descentes) depuis l'origine, partagé par DQ-01 et DQ-10 ; NULL si un
    -- flux manque sur le trajet.
    ;WITH c AS (
        SELECT CountingId, Rang,
               cum  = SUM(CAST(Boarding AS bigint) - Alighting) OVER (PARTITION BY CountingId ORDER BY Rang ROWS UNBOUNDED PRECEDING),
               nbad = SUM(CASE WHEN Boarding IS NULL OR Alighting IS NULL THEN 1 ELSE 0 END)
                          OVER (PARTITION BY CountingId ORDER BY Rang ROWS UNBOUNDED PRECEDING)
        FROM comptage_API.DQ_Arret WHERE CirculationDate BETWEEN @DateDebut AND @DateFin
    )
    UPDATE a SET CumulFlux = CASE WHEN c.nbad = 0 THEN CAST(c.cum AS int) END
    FROM comptage_API.DQ_Arret AS a JOIN c ON c.CountingId = a.CountingId AND c.Rang = a.Rang;

    -- But : calculer, pour chaque train, le nombre d'arrêts et le nombre d'arrêts avec donnée.
    UPDATE t SET NbStops = x.n, NbStopsObs = x.nobs
    FROM comptage_API.DQ_Train AS t
    JOIN (SELECT CountingId, n = COUNT(*), nobs = SUM(CAST(HasData AS int))
          FROM comptage_API.DQ_Arret WHERE CirculationDate BETWEEN @DateDebut AND @DateFin GROUP BY CountingId) AS x
         ON x.CountingId = t.CountingId;

    -- But : valider le parsing.
    COMMIT;

    -- Contrôles techniques post-parsing (informatifs)
    -- But : contrôles techniques informatifs après parsing (volumes, EVN en double à un arrêt).
    IF @ExecutionId IS NOT NULL
    BEGIN
        INSERT audit.ControlesTechniquesDQ (ExecutionId, ControleCode, Niveau, NbLignes, Detail)
        SELECT @ExecutionId, 'PARSE_VOLUMES', 'INFO', (SELECT COUNT_BIG(*) FROM comptage_API.DQ_Train WHERE CirculationDate BETWEEN @DateDebut AND @DateFin),
               CONCAT(N'Trains ; arrêts = ', (SELECT COUNT_BIG(*) FROM comptage_API.DQ_Arret WHERE CirculationDate BETWEEN @DateDebut AND @DateFin),
                      N' ; véhicules x arrêts = ', (SELECT COUNT_BIG(*) FROM comptage_API.DQ_ArretEVN WHERE CirculationDate BETWEEN @DateDebut AND @DateFin));

        INSERT audit.ControlesTechniquesDQ (ExecutionId, ControleCode, Niveau, NbLignes, Detail)
        SELECT @ExecutionId, 'EVN_DOUBLON_ARRET', 'AVERTISSEMENT', COUNT_BIG(*),
               N'Arrêts où un même EVN apparaît plusieurs fois (DQ-13 suppose un EVN unique par arrêt)'
        FROM (SELECT CountingId, Rang, EVN FROM comptage_API.DQ_ArretEVN
              WHERE CirculationDate BETWEEN @DateDebut AND @DateFin
              GROUP BY CountingId, Rang, EVN HAVING COUNT(*) > 1) AS d
        HAVING COUNT_BIG(*) > 0;
    END;
END;
GO

/*==============================================================================
 ÉTAPE 07/27 - Écriture des résultats et orchestrateur
 Source : sql/07_ecriture_et_orchestrateur.sql
 But : Procédures communes : écriture dans le journal, synthèse au niveau
 Train, ouverture et clôture d'une exécution, et orchestrateur qui lance
 toutes les règles actives.
===============================================================================*/

/*
================================================================================
 07 - Écriture des résultats, synthèse Train et orchestrateur
================================================================================
 Contrat commun des procédures de règles audit.usp_DQ_BR_* (interface de la V1) :
     @SourceName, @RegleDQID, @ExecutionId, @DateDebut, @DateFin
 Chaque procédure :
   1. lit ses seuils dans audit.ReglesDQ (RegleDQID) ;
   2. calcule ses résultats dans la table temporaire #R (structure ci-dessous) ;
   3. appelle audit.usp_DQ_EcrireResultats, qui écrit dans audit.LogsDQ.

 Structure de #R (créée par chaque procédure de règle, lue par les procédures communes) :
   GrainLevel tinyint        1 = Train, 2 = Arrêt, 3 = Véhicule (EVN)
   CountingId bigint         clé du train
   Rang       smallint NULL  arrêt (niveaux 2 et 3)
   VehIdx     smallint NULL  véhicule (niveau 3)
   Status varchar(12), FailureReason varchar(60), ObservedValue nvarchar(4000),
   ExpectedValue nvarchar(100), AbsoluteGap decimal(19,6), RelativeGap decimal(19,6)
================================================================================
*/
-- ---------------------------------------------------------------------------
-- 1. Écriture dans audit.LogsDQ (une transaction par règle ; rejouable)
-- ---------------------------------------------------------------------------
-- But : écriture commune des résultats d'une règle (table #R) dans audit.LogsDQ, aux trois niveaux
-- Train, Arrêt, Véhicule. Rejouable.
CREATE OR ALTER PROCEDURE audit.usp_DQ_EcrireResultats
    @RegleDQID   int,
    @ExecutionId bigint,
    @DateDebut   date,
    @DateFin     date,
    @NbLignes    int = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;

    BEGIN TRAN;

    -- Rejouable : on remplace les résultats de CETTE règle pour CETTE exécution
    -- les trois INSERT qui suivent écrivent les résultats #R au niveau Train, puis Arrêt, puis Véhicule
    DELETE FROM audit.LogsDQ WHERE ExecutionId = @ExecutionId AND RegleDQID = @RegleDQID;

    -- Les résultats précédents de la fenêtre ne sont plus « courants » (ils restent dans l'historique)
    UPDATE audit.LogsDQ SET IsCurrent = 0
    WHERE RegleDQID = @RegleDQID AND IsCurrent = 1
      AND WindowDate BETWEEN @DateDebut AND @DateFin
      AND ExecutionId <> @ExecutionId;

    -- Niveau 1 : Train
    INSERT audit.LogsDQ (ExecutionId, RunId, RegleDQID, [Status], FailureReason, ObservedValue, ExpectedValue,
                         AbsoluteGap, RelativeGap, GrainValuesJson, GrainLevel, SourceKey, WindowDate, IsCurrent)
    SELECT @ExecutionId, t.RunId, @RegleDQID, r.[Status], r.FailureReason, r.ObservedValue, r.ExpectedValue,
           r.AbsoluteGap, r.RelativeGap,
           CONCAT(N'[{"name":"TrainNumber","value":"', STRING_ESCAPE(t.TrainNumber, 'json'),
                  N'"},{"name":"CirculationDate","value":"', CONVERT(nvarchar(10), t.CirculationDate, 23), N'"}]'),
           1, t.CountingId, t.CirculationDate, 1
    FROM #R AS r
    JOIN comptage_API.DQ_Train AS t ON t.CountingId = r.CountingId
    WHERE r.GrainLevel = 1;

    -- Niveau 2 : Arrêt
    INSERT audit.LogsDQ (ExecutionId, RunId, RegleDQID, [Status], FailureReason, ObservedValue, ExpectedValue,
                         AbsoluteGap, RelativeGap, GrainValuesJson, GrainLevel, SourceKey, WindowDate, IsCurrent)
    SELECT @ExecutionId, a.RunId, @RegleDQID, r.[Status], r.FailureReason, r.ObservedValue, r.ExpectedValue,
           r.AbsoluteGap, r.RelativeGap,
           CONCAT(N'[{"name":"TrainNumber","value":"', STRING_ESCAPE(a.TrainNumber, 'json'),
                  N'"},{"name":"CirculationDate","value":"', CONVERT(nvarchar(10), a.CirculationDate, 23),
                  N'"},{"name":"StopRank","value":"', a.Rang, N'"}]'),
           2, a.CountingId, a.CirculationDate, 1
    FROM #R AS r
    JOIN comptage_API.DQ_Arret AS a ON a.CountingId = r.CountingId AND a.Rang = r.Rang
    WHERE r.GrainLevel = 2;

    -- Niveau 3 : Véhicule à l'arrêt (EVN)
    INSERT audit.LogsDQ (ExecutionId, RunId, RegleDQID, [Status], FailureReason, ObservedValue, ExpectedValue,
                         AbsoluteGap, RelativeGap, GrainValuesJson, GrainLevel, SourceKey, WindowDate, IsCurrent)
    SELECT @ExecutionId, e.RunId, @RegleDQID, r.[Status], r.FailureReason, r.ObservedValue, r.ExpectedValue,
           r.AbsoluteGap, r.RelativeGap,
           CONCAT(N'[{"name":"TrainNumber","value":"', STRING_ESCAPE(e.TrainNumber, 'json'),
                  N'"},{"name":"CirculationDate","value":"', CONVERT(nvarchar(10), e.CirculationDate, 23),
                  N'"},{"name":"StopRank","value":"', e.Rang,
                  N'"},{"name":"EVNNumber","value":"', STRING_ESCAPE(e.EVN, 'json'), N'"}]'),
           3, e.CountingId, e.CirculationDate, 1
    FROM #R AS r
    JOIN comptage_API.DQ_ArretEVN AS e ON e.CountingId = r.CountingId AND e.Rang = r.Rang AND e.VehIdx = r.VehIdx
    WHERE r.GrainLevel = 3;

    SET @NbLignes = (SELECT COUNT(*) FROM #R);
    COMMIT;
END;
GO

-- ---------------------------------------------------------------------------
-- 2. Synthèse Train : pire statut des résultats d'un niveau de détail
--    (FAIL > WARNING > PASS ; NOT_TESTED si rien n'est testé, même sans aucun détail)
-- ---------------------------------------------------------------------------
-- But : remonte au niveau Train le pire statut des résultats d'un niveau fin (FAIL > WARNING > PASS).
CREATE OR ALTER PROCEDURE audit.usp_DQ_SyntheseTrain
    @DateDebut date,
    @DateFin   date,
    @Niveau    tinyint,            -- niveau de détail à synthétiser : 2 (arrêts) ou 3 (véhicules)
    @Raison    varchar(60)         -- FailureReason quand la synthèse est FAIL
AS
BEGIN
    SET NOCOUNT ON;
    -- But : ajouter une ligne Train par train : le pire statut de ses lignes fines, avec le décompte par
    -- statut.
    INSERT #R (GrainLevel, CountingId, Rang, VehIdx, [Status], FailureReason, ObservedValue)
    SELECT 1, t.CountingId, NULL, NULL,
           CASE g.sev WHEN 3 THEN 'FAIL' WHEN 2 THEN 'WARNING' WHEN 1 THEN 'PASS' ELSE 'NOT_TESTED' END,
           CASE WHEN g.sev = 3 THEN @Raison WHEN g.sev IS NULL OR g.sev = 0 THEN 'AUCUN_DETAIL_TESTE' END,
           (SELECT g.nb_pass AS nb_pass, g.nb_warning AS nb_warning, g.nb_fail AS nb_fail,
                   g.nb_not_tested AS nb_not_tested FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM comptage_API.DQ_Train AS t
    LEFT JOIN (
        SELECT CountingId,
               sev = MAX(CASE [Status] WHEN 'FAIL' THEN 3 WHEN 'WARNING' THEN 2 WHEN 'PASS' THEN 1 ELSE 0 END),
               nb_pass = SUM(CASE WHEN [Status] = 'PASS' THEN 1 ELSE 0 END),
               nb_warning = SUM(CASE WHEN [Status] = 'WARNING' THEN 1 ELSE 0 END),
               nb_fail = SUM(CASE WHEN [Status] = 'FAIL' THEN 1 ELSE 0 END),
               nb_not_tested = SUM(CASE WHEN [Status] = 'NOT_TESTED' THEN 1 ELSE 0 END)
        FROM #R WHERE GrainLevel = @Niveau GROUP BY CountingId
    ) AS g ON g.CountingId = t.CountingId
    WHERE t.CirculationDate BETWEEN @DateDebut AND @DateFin;
END;
GO

-- ---------------------------------------------------------------------------
-- 3. Ouverture / clôture d'une exécution
-- ---------------------------------------------------------------------------
-- But : crée (ou reprend) la ligne d'exécution et son identifiant.
CREATE OR ALTER PROCEDURE audit.usp_DQ_OuvrirExecution
    @SourceName      nvarchar(50),
    @DateDebut       date,
    @DateFin         date,
    @ExecutionId     bigint OUTPUT,
    @SsisExecutionId bigint = NULL
AS
BEGIN
    SET NOCOUNT ON;
    -- But : nouvelle exécution = nouvel identifiant ; une exécution existante est reprise (rejeu).
    IF @ExecutionId IS NULL SET @ExecutionId = NEXT VALUE FOR audit.seq_ExecutionId;
    IF NOT EXISTS (SELECT 1 FROM audit.ExecutionsDQ WHERE ExecutionId = @ExecutionId)
        INSERT audit.ExecutionsDQ (ExecutionId, SourceName, DateDebut, DateFin, SsisExecutionId)
        VALUES (@ExecutionId, @SourceName, @DateDebut, @DateFin, @SsisExecutionId);
END;
GO

-- But : clôt l'exécution : statut final, heure de fin, nombre de trains.
CREATE OR ALTER PROCEDURE audit.usp_DQ_CloreExecution
    @ExecutionId bigint,
    @Statut      varchar(20),
    @Message     nvarchar(2000) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    -- But : écrire le statut final, l'heure de fin et le nombre de trains.
    UPDATE audit.ExecutionsDQ
    SET Statut = @Statut, EndDateTime = SYSUTCDATETIME(),
        Message = COALESCE(@Message, Message),
        NbTrains = (SELECT COUNT(*) FROM audit.LogsDQ WHERE ExecutionId = @ExecutionId AND GrainLevel = 1
                    AND RegleDQID = (SELECT MIN(RegleDQID) FROM audit.ExecutionsRegleDQ
                                     WHERE ExecutionId = @ExecutionId AND Statut = 'Succes'))
    WHERE ExecutionId = @ExecutionId;
END;
GO

-- ---------------------------------------------------------------------------
-- 4. Orchestrateur générique : une seule ligne d'appel pour toutes les règles actives
--      EXEC audit.usp_DQ_ExecuterRegles @SourceName = N'SIV_APC', @DateDebut = ?, @DateFin = ?, @ExecutionId = NULL
--    - un échec technique d'une règle n'empêche pas les suivantes ;
--    - à la fin, si au moins une règle a échoué, l'orchestrateur lève une erreur (la tâche SSIS échoue) ;
--    - une non-conformité métier (FAIL) n'est PAS une erreur : elle est journalisée.
-- ---------------------------------------------------------------------------
-- But : ORCHESTRATEUR : lance toutes les règles actives du catalogue, une par une, avec TRY/CATCH par
-- règle et liste blanche de procédures.
CREATE OR ALTER PROCEDURE audit.usp_DQ_ExecuterRegles
    @SourceName      nvarchar(50),
    @DateDebut       date,
    @DateFin         date,
    @ExecutionId     bigint = NULL OUTPUT,
    @SsisExecutionId bigint = NULL,
    @Cloturer        bit    = NULL            -- NULL : clôt l'exécution seulement si cet appel l'a créée
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;

    IF @DateDebut IS NULL OR @DateFin IS NULL OR @DateFin < @DateDebut
        -- But : refuser une fenêtre de dates invalide ou un SourceName sans règle active.
        THROW 50001, N'Fenêtre de dates invalide (@DateDebut et @DateFin obligatoires, @DateFin >= @DateDebut).', 1;
    IF NOT EXISTS (SELECT 1 FROM audit.ReglesDQ WHERE SourceName = @SourceName AND IsActive = 1)
        THROW 50002, N'Aucune règle active dans audit.ReglesDQ pour ce SourceName.', 1;

    DECLARE @estCree bit = CASE WHEN @ExecutionId IS NULL
                                  OR NOT EXISTS (SELECT 1 FROM audit.ExecutionsDQ WHERE ExecutionId = @ExecutionId)
                                THEN 1 ELSE 0 END;
    EXEC audit.usp_DQ_OuvrirExecution @SourceName, @DateDebut, @DateFin, @ExecutionId OUTPUT, @SsisExecutionId;

    -- But : liste ordonnée des règles à lancer, limitée à la liste blanche audit.usp_DQ_BR_* qui existent.
    CREATE TABLE #Regles (Ordre int IDENTITY(1,1) PRIMARY KEY, RegleDQID int NOT NULL, RuleCode nvarchar(20) NOT NULL, Proc nvarchar(300) NOT NULL);
    INSERT #Regles (RegleDQID, RuleCode, Proc)
    SELECT RegleDQID, RuleCode, QUOTENAME(PARSENAME(StoredProc, 2)) + N'.' + QUOTENAME(PARSENAME(StoredProc, 1))
    FROM audit.ReglesDQ
    WHERE SourceName = @SourceName AND IsActive = 1
      AND StoredProc LIKE N'audit.usp[_]DQ[_]BR[_]%'              -- liste blanche : seules les procédures de règles
      AND OBJECT_ID(StoredProc, N'P') IS NOT NULL
    ORDER BY SequenceOrder, RegleDQID;

    -- Règles actives dont la procédure est absente ou hors liste blanche : erreur technique tracée
    -- But : tracer en erreur les règles actives dont la procédure est absente ou hors liste blanche.
    INSERT audit.ExecutionsRegleDQ (ExecutionId, RegleDQID, DebutUtc, FinUtc, DureeMs, NbResultats, Statut, ErrorMessage)
    SELECT @ExecutionId, r.RegleDQID, SYSUTCDATETIME(), SYSUTCDATETIME(), 0, 0, 'Erreur',
           N'Procédure introuvable ou hors liste blanche : ' + r.StoredProc
    FROM audit.ReglesDQ AS r
    WHERE r.SourceName = @SourceName AND r.IsActive = 1
      AND NOT EXISTS (SELECT 1 FROM #Regles AS x WHERE x.RegleDQID = r.RegleDQID)
      AND NOT EXISTS (SELECT 1 FROM audit.ExecutionsRegleDQ AS e WHERE e.ExecutionId = @ExecutionId AND e.RegleDQID = r.RegleDQID);

    DECLARE @i int = 1, @max int = (SELECT COUNT(*) FROM #Regles);
    DECLARE @id int, @proc nvarchar(300), @t0 datetime2(3), @nb int;

    -- But : boucle sur les règles ; un échec technique d'une règle n'empêche pas les suivantes (TRY/CATCH).
    WHILE @i <= @max
    BEGIN
        SELECT @id = RegleDQID, @proc = Proc FROM #Regles WHERE Ordre = @i;
        SET @t0 = SYSUTCDATETIME();
        BEGIN TRY
            EXEC @proc @SourceName = @SourceName, @RegleDQID = @id, @ExecutionId = @ExecutionId,
                       @DateDebut = @DateDebut, @DateFin = @DateFin;
            SELECT @nb = COUNT(*) FROM audit.LogsDQ WHERE ExecutionId = @ExecutionId AND RegleDQID = @id;
            DELETE FROM audit.ExecutionsRegleDQ WHERE ExecutionId = @ExecutionId AND RegleDQID = @id;
            INSERT audit.ExecutionsRegleDQ (ExecutionId, RegleDQID, DebutUtc, FinUtc, DureeMs, NbResultats, Statut)
            VALUES (@ExecutionId, @id, @t0, SYSUTCDATETIME(), DATEDIFF(MILLISECOND, @t0, SYSUTCDATETIME()), @nb, 'Succes');
        END TRY
        BEGIN CATCH
            IF XACT_STATE() <> 0 ROLLBACK TRAN;
            DELETE FROM audit.ExecutionsRegleDQ WHERE ExecutionId = @ExecutionId AND RegleDQID = @id;
            INSERT audit.ExecutionsRegleDQ (ExecutionId, RegleDQID, DebutUtc, FinUtc, DureeMs, NbResultats, Statut, ErrorNumber, ErrorMessage)
            VALUES (@ExecutionId, @id, @t0, SYSUTCDATETIME(), DATEDIFF(MILLISECOND, @t0, SYSUTCDATETIME()), 0, 'Erreur',
                    ERROR_NUMBER(), LEFT(ERROR_MESSAGE(), 2000));
        END CATCH;
        SET @i += 1;
    END;

    -- But : compter les règles lancées et en erreur, et les inscrire dans l'exécution.
    DECLARE @nLancees int, @nErreur int;
    SELECT @nLancees = COUNT(*), @nErreur = SUM(CASE WHEN Statut = 'Erreur' THEN 1 ELSE 0 END)
    FROM audit.ExecutionsRegleDQ WHERE ExecutionId = @ExecutionId;
    UPDATE audit.ExecutionsDQ SET NbReglesLancees = @nLancees, NbReglesEnErreur = @nErreur WHERE ExecutionId = @ExecutionId;

    -- But : clôturer l'exécution (Succes, SuccesPartiel ou Echec) quand cet appel l'a créée.
    IF COALESCE(@Cloturer, @estCree) = 1
        EXEC audit.usp_DQ_CloreExecution @ExecutionId,
             CASE WHEN @nErreur = 0 THEN 'Succes' WHEN @nErreur < @nLancees THEN 'SuccesPartiel' ELSE 'Echec' END;

    -- But : si au moins une règle a échoué, lever l'erreur 50020 pour que la tâche SSIS échoue. Un FAIL métier
    -- n'est pas une erreur.
    IF @nErreur > 0
    BEGIN
        DECLARE @msg nvarchar(2000) = CONCAT(N'Exécution ', @ExecutionId, N' : ', @nErreur,
                                             N' règle(s) en erreur technique, voir audit.ExecutionsRegleDQ.');
        THROW 50020, @msg, 1;
    END;
END;
GO

/*==============================================================================
 ÉTAPE 08/27 - DQ-01 - Cohérence flux / occupation
 Source : sql/regles/DQ01_CoherenceFluxOccupation.sql
 But : Procédure de la règle, appelée par l'orchestrateur. Lit son seuil dans
 le catalogue, calcule un statut par objet et écrit le résultat dans le
 journal. Le détail de la règle est dans l'en-tête ci-dessous.
===============================================================================*/

/*
================================================================================
 DQ-01 - Cohérence flux / occupation            Mailles : Arrêt (détail) + Train (synthèse)
================================================================================
 Choix validés le 2026-11-11 : reconstruction CUMULEE depuis l'origine (1er arrêt listé).
   reconstruite(n) = Σ (montées - descentes) des arrêts 1..n          (comptage_API.DQ_Arret.CumulFlux)
   écart(n)        = | occupation mesurée(n) - reconstruite(n) |
   seuil(n)        = MAX(tolérance absolue ; tolérance relative x reconstruite(n))
   PASS si écart <= seuil, sinon FAIL.
   NOT_TESTED : arrêt sans donnée, ou flux absent (ou illisible) sur l'un des arrêts 1..n.
   Train : pire statut de ses arrêts.
 Seuils (audit.ReglesDQ) : ThresholdMedium = tolérance relative (0,02) ;
                           ParamsJson.tolerance_abs = tolérance absolue (5 voyageurs).
================================================================================
*/
CREATE OR ALTER PROCEDURE audit.usp_DQ_BR_DQ01_CoherenceFluxOccupation
    @SourceName  nvarchar(50),
    @RegleDQID   int,
    @ExecutionId bigint,
    @DateDebut   date,
    @DateFin     date
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;

    -- But : lire dans le catalogue (audit.ReglesDQ) les seuils et paramètres de la règle.
    DECLARE @tolRel decimal(19,6), @tolAbs decimal(19,6);
    SELECT @tolRel = ThresholdMedium,
           @tolAbs = COALESCE(TRY_CONVERT(decimal(19,6), JSON_VALUE(ParamsJson, '$.tolerance_abs')), 5)
    FROM audit.ReglesDQ WHERE RegleDQID = @RegleDQID;

    -- But : table temporaire des résultats de la règle ; une ligne par objet testé, au grain voulu (1 Train, 2
    -- Arrêt, 3 Véhicule).
    CREATE TABLE #R (GrainLevel tinyint NOT NULL, CountingId bigint NOT NULL, Rang smallint NULL, VehIdx smallint NULL,
                     [Status] varchar(12) NOT NULL, FailureReason varchar(60) NULL, ObservedValue nvarchar(4000) NULL,
                     ExpectedValue nvarchar(100) NULL, AbsoluteGap decimal(19,6) NULL, RelativeGap decimal(19,6) NULL);

    ;WITH b AS (
        SELECT a.CountingId, a.Rang, a.HasData, a.Occ, a.CumulFlux,
               Teste = CASE WHEN a.HasData = 1 AND a.CumulFlux IS NOT NULL THEN 1 ELSE 0 END,
               Ecart = CAST(ABS(CAST(a.Occ AS bigint) - a.CumulFlux) AS decimal(19,6)),
               Seuil = CASE WHEN @tolRel * a.CumulFlux > @tolAbs THEN @tolRel * a.CumulFlux ELSE @tolAbs END
        FROM comptage_API.DQ_Arret AS a
        WHERE a.CirculationDate BETWEEN @DateDebut AND @DateFin
    )
    -- But : calculer le statut de chaque objet (PASS, WARNING, FAIL, NOT_TESTED) avec le motif, la valeur
    -- observée, la valeur attendue et les écarts.
    INSERT #R (GrainLevel, CountingId, Rang, VehIdx, [Status], FailureReason, ObservedValue, ExpectedValue, AbsoluteGap, RelativeGap)
    SELECT 2, b.CountingId, b.Rang, NULL,
           CASE WHEN b.Teste = 0 THEN 'NOT_TESTED' WHEN b.Ecart <= b.Seuil THEN 'PASS' ELSE 'FAIL' END,
           CASE WHEN b.HasData = 0 THEN 'ARRET_SANS_DONNEE'
                WHEN b.CumulFlux IS NULL THEN 'FLUX_ABSENT_SUR_TRAJET'
                WHEN b.Ecart > b.Seuil THEN 'ECART_CUMUL' END,
           (SELECT b.Occ AS occupation, b.CumulFlux AS reconstruite,
                   CASE WHEN b.Teste = 1 THEN b.Ecart END AS ecart, CASE WHEN b.Teste = 1 THEN b.Seuil END AS seuil
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
           CASE WHEN b.Teste = 1 THEN CAST(b.CumulFlux AS nvarchar(100)) END,
           CASE WHEN b.Teste = 1 THEN b.Ecart END,
           CASE WHEN b.Teste = 1 AND b.CumulFlux <> 0 THEN b.Ecart / ABS(b.CumulFlux) END
    FROM b;

    -- But : le statut Train est le pire statut des lignes fines.
    EXEC audit.usp_DQ_SyntheseTrain @DateDebut, @DateFin, 2, 'ARRET_EN_ECART';
    -- But : écrire #R dans audit.LogsDQ ; les résultats précédents de la fenêtre passent à IsCurrent = 0.
    EXEC audit.usp_DQ_EcrireResultats @RegleDQID, @ExecutionId, @DateDebut, @DateFin;
END;
GO

/*==============================================================================
 ÉTAPE 09/27 - DQ-02 - Complétude EVN
 Source : sql/regles/DQ02_CompletudeEVN.sql
 But : Procédure de la règle, appelée par l'orchestrateur. Lit son seuil dans
 le catalogue, calcule un statut par objet et écrit le résultat dans le
 journal. Le détail de la règle est dans l'en-tête ci-dessous.
===============================================================================*/

/*
================================================================================
 DQ-02 - Complétude EVN                          Mailles : Arrêt (détail) + Train (synthèse)
================================================================================
 Attendu = nombre d'EVN distincts de EuropeanVehicleNumbersJson (comptage_API.DQ_Train.NbEvnExpected).
   Arrêt sans donnée                         -> NOT_TESTED (c'est DQ-07 qui capte l'arrêt manquant)
   attendu = 0 ou attendu > seuil max (9)     -> FAIL
   EVN observés à l'arrêt <> attendu          -> FAIL, sinon PASS
   Train : FAIL si attendu = 0 ou > 9, sinon pire statut de ses arrêts.
 STATUT : en attente de la réponse du PO SIV (origine de EuropeanVehicleNumbersJson, composition
 ARAMIS ?). Le calcul ci-dessous est celui du moteur actuel. La comparaison des IDENTITES des
 véhicules (et pas seulement des nombres) est prévue en V2 (table comptage_API.DQ_EVNAttendu déjà alimentée).
 Seuil (audit.ReglesDQ) : ThresholdHigh = nombre maximal d'EVN attendus (9).
================================================================================
*/
CREATE OR ALTER PROCEDURE audit.usp_DQ_BR_DQ02_CompletudeEVN
    @SourceName  nvarchar(50),
    @RegleDQID   int,
    @ExecutionId bigint,
    @DateDebut   date,
    @DateFin     date
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;

    -- But : lire dans le catalogue (audit.ReglesDQ) les seuils et paramètres de la règle.
    DECLARE @max decimal(19,6);
    SELECT @max = ThresholdHigh FROM audit.ReglesDQ WHERE RegleDQID = @RegleDQID;

    -- But : table temporaire des résultats de la règle ; une ligne par objet testé, au grain voulu (1 Train, 2
    -- Arrêt, 3 Véhicule).
    CREATE TABLE #R (GrainLevel tinyint NOT NULL, CountingId bigint NOT NULL, Rang smallint NULL, VehIdx smallint NULL,
                     [Status] varchar(12) NOT NULL, FailureReason varchar(60) NULL, ObservedValue nvarchar(4000) NULL,
                     ExpectedValue nvarchar(100) NULL, AbsoluteGap decimal(19,6) NULL, RelativeGap decimal(19,6) NULL);

    -- But : calculer le statut de chaque objet (PASS, WARNING, FAIL, NOT_TESTED) avec le motif, la valeur
    -- observée, la valeur attendue et les écarts.
    INSERT #R (GrainLevel, CountingId, Rang, VehIdx, [Status], FailureReason, ObservedValue, ExpectedValue, AbsoluteGap, RelativeGap)
    SELECT 2, a.CountingId, a.Rang, NULL,
           CASE WHEN a.HasData = 0 THEN 'NOT_TESTED'
                WHEN t.NbEvnExpected = 0 OR t.NbEvnExpected > @max OR a.NbEvnObs <> t.NbEvnExpected THEN 'FAIL'
                ELSE 'PASS' END,
           CASE WHEN a.HasData = 0 THEN 'ARRET_SANS_DONNEE'
                WHEN t.NbEvnExpected = 0 THEN 'COMPOSITION_ATTENDUE_ABSENTE'
                WHEN t.NbEvnExpected > @max THEN 'COMPOSITION_ATTENDUE_TROP_GRANDE'
                WHEN a.NbEvnObs <> t.NbEvnExpected THEN 'EVN_OBSERVES_DIFFERENT_ATTENDU' END,
           (SELECT a.NbEvnObs AS evn_observes, t.NbEvnExpected AS evn_attendus FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
           CAST(t.NbEvnExpected AS nvarchar(100)),
           CASE WHEN a.HasData = 1 THEN CAST(a.NbEvnObs - t.NbEvnExpected AS decimal(19,6)) END,
           CASE WHEN a.HasData = 1 AND t.NbEvnExpected > 0
                THEN CAST(a.NbEvnObs - t.NbEvnExpected AS decimal(19,6)) / t.NbEvnExpected END
    FROM comptage_API.DQ_Arret AS a
    JOIN comptage_API.DQ_Train AS t ON t.CountingId = a.CountingId
    WHERE a.CirculationDate BETWEEN @DateDebut AND @DateFin;

    -- But : le statut Train est le pire statut des lignes fines.
    EXEC audit.usp_DQ_SyntheseTrain @DateDebut, @DateFin, 2, 'ARRET_EVN_INCOMPLET';

    -- Train : composition attendue absente ou trop grande => FAIL, quels que soient les arrêts
    UPDATE r SET [Status] = 'FAIL',
                 FailureReason = CASE WHEN t.NbEvnExpected = 0 THEN 'COMPOSITION_ATTENDUE_ABSENTE'
                                      ELSE 'COMPOSITION_ATTENDUE_TROP_GRANDE' END
    FROM #R AS r JOIN comptage_API.DQ_Train AS t ON t.CountingId = r.CountingId
    WHERE r.GrainLevel = 1 AND (t.NbEvnExpected = 0 OR t.NbEvnExpected > @max);

    -- But : écrire #R dans audit.LogsDQ ; les résultats précédents de la fenêtre passent à IsCurrent = 0.
    EXEC audit.usp_DQ_EcrireResultats @RegleDQID, @ExecutionId, @DateDebut, @DateFin;
END;
GO

/*==============================================================================
 ÉTAPE 10/27 - DQ-03 - Remise à zéro au terminus
 Source : sql/regles/DQ03_RemiseZeroTerminus.sql
 But : Procédure de la règle, appelée par l'orchestrateur. Lit son seuil dans
 le catalogue, calcule un statut par objet et écrit le résultat dans le
 journal. Le détail de la règle est dans l'en-tête ci-dessous.
===============================================================================*/

/*
================================================================================
 DQ-03 - Remise à zéro au terminus                              Maille : Train
================================================================================
 Terminus = dernier arrêt de type End (stopType = 'End').
   taux résiduel = | occupation au terminus - descentes au terminus | / capacité au terminus
   PASS si taux <= seuil (0,02), sinon FAIL.
   NOT_TESTED : pas de terminus, terminus sans donnée, descentes absentes, capacité absente ou nulle.
 Validé le 2026-11-11 : l'occupation du terminus est mesurée AVANT les descentes (constat C30 :
 elle est parfois inférieure aux descentes, ce qui est un problème de donnée, pas de la règle).
 Seuil (audit.ReglesDQ) : ThresholdLow = 0,02 (ratio de la capacité).
================================================================================
*/
CREATE OR ALTER PROCEDURE audit.usp_DQ_BR_DQ03_RemiseZeroTerminus
    @SourceName  nvarchar(50),
    @RegleDQID   int,
    @ExecutionId bigint,
    @DateDebut   date,
    @DateFin     date
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;

    -- But : lire dans le catalogue (audit.ReglesDQ) les seuils et paramètres de la règle.
    DECLARE @seuil decimal(19,6);
    SELECT @seuil = ThresholdLow FROM audit.ReglesDQ WHERE RegleDQID = @RegleDQID;

    -- But : table temporaire des résultats de la règle ; une ligne par objet testé, au grain voulu (1 Train, 2
    -- Arrêt, 3 Véhicule).
    CREATE TABLE #R (GrainLevel tinyint NOT NULL, CountingId bigint NOT NULL, Rang smallint NULL, VehIdx smallint NULL,
                     [Status] varchar(12) NOT NULL, FailureReason varchar(60) NULL, ObservedValue nvarchar(4000) NULL,
                     ExpectedValue nvarchar(100) NULL, AbsoluteGap decimal(19,6) NULL, RelativeGap decimal(19,6) NULL);

    ;WITH e AS (
        SELECT t.CountingId, x.Rang, x.HasData, x.Occ, x.Alighting, x.Capacity,
               Teste = CASE WHEN x.HasData = 1 AND x.Alighting IS NOT NULL AND x.Capacity > 0 THEN 1 ELSE 0 END,
               Taux  = CASE WHEN x.HasData = 1 AND x.Alighting IS NOT NULL AND x.Capacity > 0
                            THEN CAST(ABS(CAST(x.Occ AS bigint) - x.Alighting) AS decimal(19,6)) / x.Capacity END
        FROM comptage_API.DQ_Train AS t
        OUTER APPLY (SELECT TOP (1) a.Rang, a.HasData, a.Occ, a.Alighting, a.Capacity
                     FROM comptage_API.DQ_Arret AS a
                     WHERE a.CountingId = t.CountingId AND a.StopType = 'End'
                     ORDER BY a.Rang DESC) AS x
        WHERE t.CirculationDate BETWEEN @DateDebut AND @DateFin
    )
    -- But : calculer le statut de chaque objet (PASS, WARNING, FAIL, NOT_TESTED) avec le motif, la valeur
    -- observée, la valeur attendue et les écarts.
    INSERT #R (GrainLevel, CountingId, Rang, VehIdx, [Status], FailureReason, ObservedValue, ExpectedValue, AbsoluteGap, RelativeGap)
    SELECT 1, e.CountingId, NULL, NULL,
           CASE WHEN e.Teste = 0 THEN 'NOT_TESTED' WHEN e.Taux <= @seuil THEN 'PASS' ELSE 'FAIL' END,
           CASE WHEN e.Rang IS NULL THEN 'PAS_DE_TERMINUS'
                WHEN e.HasData = 0 THEN 'TERMINUS_SANS_DONNEE'
                WHEN e.Alighting IS NULL THEN 'DESCENTES_ABSENTES'
                WHEN e.Capacity IS NULL OR e.Capacity <= 0 THEN 'CAPACITE_ABSENTE_OU_NULLE'
                WHEN e.Taux > @seuil THEN 'OCCUPATION_RESIDUELLE_AU_TERMINUS' END,
           (SELECT e.Occ AS occupation, e.Alighting AS descentes, e.Capacity AS capacite,
                   CASE WHEN e.Teste = 1 THEN CAST(e.Taux * 100 AS decimal(9,2)) END AS taux_pct
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
           CASE WHEN e.Teste = 1 THEN CAST(@seuil AS nvarchar(100)) END,
           CASE WHEN e.Teste = 1 THEN ABS(CAST(e.Occ AS decimal(19,6)) - e.Alighting) END,
           e.Taux
    FROM e;

    -- But : écrire #R dans audit.LogsDQ ; les résultats précédents de la fenêtre passent à IsCurrent = 0.
    EXEC audit.usp_DQ_EcrireResultats @RegleDQID, @ExecutionId, @DateDebut, @DateFin;
END;
GO

/*==============================================================================
 ÉTAPE 11/27 - DQ-04 - Charge critique
 Source : sql/regles/DQ04_ChargeCritiqueEVN.sql
 But : Procédure de la règle, appelée par l'orchestrateur. Lit son seuil dans
 le catalogue, calcule un statut par objet et écrit le résultat dans le
 journal. Le détail de la règle est dans l'en-tête ci-dessous.
===============================================================================*/

/*
================================================================================
 DQ-04 - Charge critique        Mailles : Véhicule (détail), Arrêt (détail), Train (synthèse)
================================================================================
 Taux de charge = occupation / capacité.
   PASS <= 200 % (ThresholdLow = 2,00) ; WARNING <= 250 % (ThresholdMedium = 2,50) ; FAIL au-delà.
   Occupation absente                              -> NOT_TESTED
   Capacité nulle ou absente, occupation = 0        -> NOT_TESTED (véhicule vide, taux incalculable)
                                                       [validé le 2026-11-11, option A]
   Capacité nulle ou absente, occupation > 0        -> FAIL
 Capacité : Véhicule = sensorCapacity ; Arrêt = capacity de l'arrêt ; Train = TotalCapacity.
 Le Train garde le pire statut parmi son propre détail (TotalOccupancy / TotalCapacity), ses
 arrêts et ses véhicules.
================================================================================
*/
CREATE OR ALTER PROCEDURE audit.usp_DQ_BR_DQ04_ChargeCritiqueEVN
    @SourceName  nvarchar(50),
    @RegleDQID   int,
    @ExecutionId bigint,
    @DateDebut   date,
    @DateFin     date
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;

    -- But : lire dans le catalogue (audit.ReglesDQ) les seuils et paramètres de la règle.
    DECLARE @low decimal(19,6), @med decimal(19,6);
    SELECT @low = ThresholdLow, @med = ThresholdMedium FROM audit.ReglesDQ WHERE RegleDQID = @RegleDQID;

    -- But : table temporaire des résultats de la règle ; une ligne par objet testé, au grain voulu (1 Train, 2
    -- Arrêt, 3 Véhicule).
    CREATE TABLE #R (GrainLevel tinyint NOT NULL, CountingId bigint NOT NULL, Rang smallint NULL, VehIdx smallint NULL,
                     [Status] varchar(12) NOT NULL, FailureReason varchar(60) NULL, ObservedValue nvarchar(4000) NULL,
                     ExpectedValue nvarchar(100) NULL, AbsoluteGap decimal(19,6) NULL, RelativeGap decimal(19,6) NULL);
    CREATE TABLE #L (GrainLevel tinyint NOT NULL, CountingId bigint NOT NULL, Rang smallint NULL, VehIdx smallint NULL,
                     Occ int NULL, Cap int NULL);

    INSERT #L SELECT 3, e.CountingId, e.Rang, e.VehIdx, e.Occ, e.SensorCapacity
              FROM comptage_API.DQ_ArretEVN AS e WHERE e.CirculationDate BETWEEN @DateDebut AND @DateFin;
    INSERT #L SELECT 2, a.CountingId, a.Rang, NULL, CASE WHEN a.HasData = 1 THEN a.Occ END, a.Capacity
              FROM comptage_API.DQ_Arret AS a WHERE a.CirculationDate BETWEEN @DateDebut AND @DateFin;
    INSERT #L SELECT 1, t.CountingId, NULL, NULL, t.TotalOccupancy, t.TotalCapacity
              FROM comptage_API.DQ_Train AS t WHERE t.CirculationDate BETWEEN @DateDebut AND @DateFin;

    -- But : calculer le statut de chaque objet (PASS, WARNING, FAIL, NOT_TESTED) avec le motif, la valeur
    -- observée, la valeur attendue et les écarts.
    INSERT #R (GrainLevel, CountingId, Rang, VehIdx, [Status], FailureReason, ObservedValue, ExpectedValue, AbsoluteGap, RelativeGap)
    SELECT l.GrainLevel, l.CountingId, l.Rang, l.VehIdx,
           CASE WHEN l.Occ IS NULL THEN 'NOT_TESTED'
                WHEN l.Cap IS NULL OR l.Cap <= 0 THEN CASE WHEN l.Occ = 0 THEN 'NOT_TESTED' ELSE 'FAIL' END
                WHEN x.Taux <= @low THEN 'PASS'
                WHEN x.Taux <= @med THEN 'WARNING'
                ELSE 'FAIL' END,
           CASE WHEN l.Occ IS NULL THEN 'OCCUPATION_ABSENTE'
                WHEN l.Cap IS NULL OR l.Cap <= 0 THEN CASE WHEN l.Occ = 0 THEN 'CAPACITE_NULLE_VEHICULE_VIDE'
                                                           ELSE 'CAPACITE_NULLE_AVEC_VOYAGEURS' END
                WHEN x.Taux > @low THEN 'CHARGE_ELEVEE' END,
           (SELECT l.Occ AS occupation, l.Cap AS capacite, CAST(x.Taux * 100 AS decimal(9,2)) AS taux_pct
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
           CAST(@low AS nvarchar(100)),
           CASE WHEN x.Taux IS NOT NULL THEN x.Taux - @low END,
           x.Taux
    FROM #L AS l
    CROSS APPLY (SELECT Taux = CASE WHEN l.Occ IS NOT NULL AND l.Cap > 0
                                    THEN CAST(l.Occ AS decimal(19,6)) / l.Cap END) AS x;

    -- Synthèse Train : pire statut entre le détail du train, de ses arrêts et de ses véhicules
    SELECT CountingId,
           sev = MAX(CASE [Status] WHEN 'FAIL' THEN 3 WHEN 'WARNING' THEN 2 WHEN 'PASS' THEN 1 ELSE 0 END)
    INTO #Pire FROM #R GROUP BY CountingId;

    UPDATE r SET [Status] = CASE p.sev WHEN 3 THEN 'FAIL' WHEN 2 THEN 'WARNING' WHEN 1 THEN 'PASS' ELSE 'NOT_TESTED' END,
                 FailureReason = CASE WHEN p.sev >= 2 AND r.FailureReason IS NULL THEN 'DETAIL_EN_ECHEC' ELSE r.FailureReason END
    FROM #R AS r JOIN #Pire AS p ON p.CountingId = r.CountingId
    WHERE r.GrainLevel = 1;

    -- But : écrire #R dans audit.LogsDQ ; les résultats précédents de la fenêtre passent à IsCurrent = 0.
    EXEC audit.usp_DQ_EcrireResultats @RegleDQID, @ExecutionId, @DateDebut, @DateFin;
END;
GO

/*==============================================================================
 ÉTAPE 12/27 - DQ-05 - État du matériel
 Source : sql/regles/DQ05_EtatMateriel.sql
 But : Procédure de la règle, appelée par l'orchestrateur. Lit son seuil dans
 le catalogue, calcule un statut par objet et écrit le résultat dans le
 journal. Le détail de la règle est dans l'en-tête ci-dessous.
===============================================================================*/

/*
================================================================================
 DQ-05 - État du matériel                  Mailles : Train, Arrêt, Véhicule (EVN)
================================================================================
 État = 1 (dégradé) -> FAIL ; 0 (conforme) -> PASS ; absent -> NOT_TESTED.
   Train  : IsDegraded de la circulation
   Arrêt  : isDegraded de l'arrêt
   EVN    : hérite de l'arrêt (choix validé)
 Le sens exact de « dégradé » reste à demander à l'exploitant (question ouverte).
================================================================================
*/
CREATE OR ALTER PROCEDURE audit.usp_DQ_BR_DQ05_EtatMateriel
    @SourceName  nvarchar(50),
    @RegleDQID   int,
    @ExecutionId bigint,
    @DateDebut   date,
    @DateFin     date
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;

    -- But : table temporaire des résultats de la règle ; une ligne par objet testé, au grain voulu (1 Train, 2
    -- Arrêt, 3 Véhicule).
    CREATE TABLE #R (GrainLevel tinyint NOT NULL, CountingId bigint NOT NULL, Rang smallint NULL, VehIdx smallint NULL,
                     [Status] varchar(12) NOT NULL, FailureReason varchar(60) NULL, ObservedValue nvarchar(4000) NULL,
                     ExpectedValue nvarchar(100) NULL, AbsoluteGap decimal(19,6) NULL, RelativeGap decimal(19,6) NULL);

    -- But : calculer le statut de chaque objet (PASS, WARNING, FAIL, NOT_TESTED) avec le motif, la valeur
    -- observée, la valeur attendue et les écarts.
    INSERT #R (GrainLevel, CountingId, Rang, VehIdx, [Status], FailureReason, ObservedValue)
    SELECT 1, t.CountingId, NULL, NULL,
           CASE t.IsDegraded WHEN 1 THEN 'FAIL' WHEN 0 THEN 'PASS' ELSE 'NOT_TESTED' END,
           CASE t.IsDegraded WHEN 1 THEN 'MATERIEL_DEGRADE' WHEN 0 THEN NULL ELSE 'ETAT_ABSENT' END,
           (SELECT t.IsDegraded AS est_degrade FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM comptage_API.DQ_Train AS t WHERE t.CirculationDate BETWEEN @DateDebut AND @DateFin;

    INSERT #R (GrainLevel, CountingId, Rang, VehIdx, [Status], FailureReason, ObservedValue)
    SELECT 2, a.CountingId, a.Rang, NULL,
           CASE a.IsDegraded WHEN 1 THEN 'FAIL' WHEN 0 THEN 'PASS' ELSE 'NOT_TESTED' END,
           CASE a.IsDegraded WHEN 1 THEN 'MATERIEL_DEGRADE' WHEN 0 THEN NULL ELSE 'ETAT_ABSENT' END,
           (SELECT a.IsDegraded AS est_degrade FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM comptage_API.DQ_Arret AS a WHERE a.CirculationDate BETWEEN @DateDebut AND @DateFin;

    INSERT #R (GrainLevel, CountingId, Rang, VehIdx, [Status], FailureReason, ObservedValue)
    SELECT 3, e.CountingId, e.Rang, e.VehIdx,
           CASE a.IsDegraded WHEN 1 THEN 'FAIL' WHEN 0 THEN 'PASS' ELSE 'NOT_TESTED' END,
           CASE a.IsDegraded WHEN 1 THEN 'MATERIEL_DEGRADE' WHEN 0 THEN NULL ELSE 'ETAT_ABSENT' END,
           (SELECT a.IsDegraded AS est_degrade FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM comptage_API.DQ_ArretEVN AS e
    JOIN comptage_API.DQ_Arret AS a ON a.CountingId = e.CountingId AND a.Rang = e.Rang
    WHERE e.CirculationDate BETWEEN @DateDebut AND @DateFin;

    -- But : écrire #R dans audit.LogsDQ ; les résultats précédents de la fenêtre passent à IsCurrent = 0.
    EXEC audit.usp_DQ_EcrireResultats @RegleDQID, @ExecutionId, @DateDebut, @DateFin;
END;
GO

/*==============================================================================
 ÉTAPE 13/27 - DQ-06 - Disponibilité des capteurs
 Source : sql/regles/DQ06_DisponibiliteCapteurs.sql
 But : Procédure de la règle, appelée par l'orchestrateur. Lit son seuil dans
 le catalogue, calcule un statut par objet et écrit le résultat dans le
 journal. Le détail de la règle est dans l'en-tête ci-dessous.
===============================================================================*/

/*
================================================================================
 DQ-06 - Disponibilité des capteurs     Mailles : Véhicule (EVN), Arrêt, Train
================================================================================
 Un capteur est valide si sa fiabilité vaut 100 % (états de comptage_API.DQ_ArretEVN : ExtEtat / IntEtat,
 0 sans donnée, 1 valide, 2 invalide).
 Statut : 0 capteur invalide -> PASS ; 1 -> WARNING ; 2 ou plus -> FAIL ;
          aucun capteur avec une valeur -> NOT_TESTED.
 Seuils (audit.ReglesDQ) : ThresholdLow = 0 (PASS si invalides <= 0), ThresholdMedium = 1 (WARNING si <= 1).

 DEUX VARIANTES, choisies par audit.ReglesDQ.ParamsJson {"variante": "..."} :
   ACTUELLE        (moteur actuel, par défaut) : 1 EVN = 2 capteurs (extérieur + intérieur) ;
                   un capteur sans valeur compte comme invalide ; à l'arrêt Train, un capteur est valide
                   s'il est à 100 % à chaque arrêt mesuré, et un EVN jamais observé compte 2 capteurs invalides.
   EXTERIEUR_SEUL  (proposée à l'atelier du 2026-11-11, NON TRANCHEE) : seuls les capteurs extérieurs
                   comptent ; un capteur sans valeur est exclu du compte (NOT_TESTED) ; un EVN attendu
                   mais jamais observé est exclu (hypothèse à confirmer).
 Colonne ExtValides (ObservedValue) : « Oui » / « Non » / « Sans donnée » (filtre « Capteurs extérieurs
 valides » du dashboard et du modèle Power BI).
================================================================================
*/
CREATE OR ALTER PROCEDURE audit.usp_DQ_BR_DQ06_DisponibiliteCapteurs
    @SourceName  nvarchar(50),
    @RegleDQID   int,
    @ExecutionId bigint,
    @DateDebut   date,
    @DateFin     date
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;

    -- But : lire dans le catalogue (audit.ReglesDQ) les seuils et paramètres de la règle.
    DECLARE @low decimal(19,6), @med decimal(19,6), @variante nvarchar(30);
    SELECT @low = ThresholdLow, @med = ThresholdMedium,
           @variante = COALESCE(JSON_VALUE(ParamsJson, '$.variante'), N'ACTUELLE')
    FROM audit.ReglesDQ WHERE RegleDQID = @RegleDQID;
    IF @variante NOT IN (N'ACTUELLE', N'EXTERIEUR_SEUL')
        THROW 50031, N'DQ-06 : variante inconnue dans ParamsJson (ACTUELLE ou EXTERIEUR_SEUL).', 1;
    DECLARE @inclInt bit = CASE WHEN @variante = N'ACTUELLE' THEN 1 ELSE 0 END;      -- capteurs intérieurs comptés
    DECLARE @nodataInvalide bit = CASE WHEN @variante = N'ACTUELLE' THEN 1 ELSE 0 END; -- capteur sans valeur = invalide

    -- But : table temporaire des résultats de la règle ; une ligne par objet testé, au grain voulu (1 Train, 2
    -- Arrêt, 3 Véhicule).
    CREATE TABLE #R (GrainLevel tinyint NOT NULL, CountingId bigint NOT NULL, Rang smallint NULL, VehIdx smallint NULL,
                     [Status] varchar(12) NOT NULL, FailureReason varchar(60) NULL, ObservedValue nvarchar(4000) NULL,
                     ExpectedValue nvarchar(100) NULL, AbsoluteGap decimal(19,6) NULL, RelativeGap decimal(19,6) NULL);

    -- ---------------- Véhicule (EVN x arrêt) ----------------
    -- But : calculer le statut de chaque objet (PASS, WARNING, FAIL, NOT_TESTED) avec le motif, la valeur
    -- observée, la valeur attendue et les écarts.
    INSERT #R (GrainLevel, CountingId, Rang, VehIdx, [Status], FailureReason, ObservedValue, ExpectedValue, AbsoluteGap)
    SELECT 3, e.CountingId, e.Rang, e.VehIdx,
           CASE WHEN k.Valeurs = 0 THEN 'NOT_TESTED'
                WHEN k.Invalides <= @low THEN 'PASS' WHEN k.Invalides <= @med THEN 'WARNING' ELSE 'FAIL' END,
           CASE WHEN k.Valeurs = 0 THEN 'CAPTEURS_SANS_DONNEE'
                WHEN k.Invalides > @low THEN 'CAPTEUR_INVALIDE' END,
           (SELECT k.Invalides AS invalides,
                   CASE WHEN k.Valeurs = 0 THEN N'Sans donnée' WHEN k.ExtInvalide >= 1 THEN N'Non' ELSE N'Oui' END AS ext_valides
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
           CAST(@low AS nvarchar(100)),
           CASE WHEN k.Valeurs > 0 THEN CAST(k.Invalides AS decimal(19,6)) END
    FROM comptage_API.DQ_ArretEVN AS e
    CROSS APPLY (
        SELECT Valeurs   = (CASE WHEN e.ExtEtat <> 0 THEN 1 ELSE 0 END) + (CASE WHEN @inclInt = 1 AND e.IntEtat <> 0 THEN 1 ELSE 0 END),
               ExtInvalide = CASE WHEN @nodataInvalide = 1 THEN CASE WHEN e.ExtEtat <> 1 THEN 1 ELSE 0 END
                                  ELSE CASE WHEN e.ExtEtat = 2 THEN 1 ELSE 0 END END,
               Invalides = (CASE WHEN @nodataInvalide = 1 THEN CASE WHEN e.ExtEtat <> 1 THEN 1 ELSE 0 END
                                 ELSE CASE WHEN e.ExtEtat = 2 THEN 1 ELSE 0 END END)
                         + (CASE WHEN @inclInt = 0 THEN 0
                                 WHEN @nodataInvalide = 1 THEN CASE WHEN e.IntEtat <> 1 THEN 1 ELSE 0 END
                                 ELSE CASE WHEN e.IntEtat = 2 THEN 1 ELSE 0 END END)
    ) AS k
    WHERE e.CirculationDate BETWEEN @DateDebut AND @DateFin;

    -- ---------------- Arrêt (somme des capteurs de ses véhicules) ----------------
    ;WITH s AS (
        SELECT e.CountingId, e.Rang,
               Valeurs = SUM((CASE WHEN e.ExtEtat <> 0 THEN 1 ELSE 0 END) + (CASE WHEN @inclInt = 1 AND e.IntEtat <> 0 THEN 1 ELSE 0 END)),
               ExtInvalide = SUM(CASE WHEN @nodataInvalide = 1 THEN CASE WHEN e.ExtEtat <> 1 THEN 1 ELSE 0 END
                                      ELSE CASE WHEN e.ExtEtat = 2 THEN 1 ELSE 0 END END),
               Invalides = SUM((CASE WHEN @nodataInvalide = 1 THEN CASE WHEN e.ExtEtat <> 1 THEN 1 ELSE 0 END
                                     ELSE CASE WHEN e.ExtEtat = 2 THEN 1 ELSE 0 END END)
                             + (CASE WHEN @inclInt = 0 THEN 0
                                     WHEN @nodataInvalide = 1 THEN CASE WHEN e.IntEtat <> 1 THEN 1 ELSE 0 END
                                     ELSE CASE WHEN e.IntEtat = 2 THEN 1 ELSE 0 END END))
        FROM comptage_API.DQ_ArretEVN AS e
        WHERE e.CirculationDate BETWEEN @DateDebut AND @DateFin
        GROUP BY e.CountingId, e.Rang
    )
    INSERT #R (GrainLevel, CountingId, Rang, VehIdx, [Status], FailureReason, ObservedValue, ExpectedValue, AbsoluteGap)
    SELECT 2, a.CountingId, a.Rang, NULL,
           CASE WHEN s.Valeurs IS NULL OR s.Valeurs = 0 THEN 'NOT_TESTED'
                WHEN s.Invalides <= @low THEN 'PASS' WHEN s.Invalides <= @med THEN 'WARNING' ELSE 'FAIL' END,
           CASE WHEN s.Valeurs IS NULL THEN 'ARRET_SANS_VEHICULE'
                WHEN s.Valeurs = 0 THEN 'CAPTEURS_SANS_DONNEE'
                WHEN s.Invalides > @low THEN 'CAPTEUR_INVALIDE' END,
           (SELECT s.Invalides AS invalides,
                   CASE WHEN s.Valeurs IS NULL OR s.Valeurs = 0 THEN N'Sans donnée'
                        WHEN s.ExtInvalide >= 1 THEN N'Non' ELSE N'Oui' END AS ext_valides
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
           CAST(@low AS nvarchar(100)),
           CASE WHEN s.Valeurs > 0 THEN CAST(s.Invalides AS decimal(19,6)) END
    FROM comptage_API.DQ_Arret AS a
    LEFT JOIN s ON s.CountingId = a.CountingId AND s.Rang = a.Rang
    WHERE a.CirculationDate BETWEEN @DateDebut AND @DateFin;

    -- ---------------- Train (capteurs de l'ensemble du trajet) ----------------
    ;WITH u AS (
        SELECT CountingId, EVN FROM comptage_API.DQ_EVNAttendu WHERE CirculationDate BETWEEN @DateDebut AND @DateFin
        UNION
        SELECT CountingId, EVN FROM comptage_API.DQ_ArretEVN   WHERE CirculationDate BETWEEN @DateDebut AND @DateFin
    ),
    o AS (
        SELECT e.CountingId, e.EVN, Nobs = COUNT(*),
               ExtToutOk = MIN(CASE WHEN e.ExtEtat = 1 THEN 1 ELSE 0 END),
               IntToutOk = MIN(CASE WHEN e.IntEtat = 1 THEN 1 ELSE 0 END),
               ExtMauvais = MAX(CASE WHEN e.ExtEtat = 2 THEN 1 ELSE 0 END),
               IntMauvais = MAX(CASE WHEN e.IntEtat = 2 THEN 1 ELSE 0 END),
               AvecValeur = MAX(CASE WHEN e.ExtEtat <> 0 OR (@inclInt = 1 AND e.IntEtat <> 0) THEN 1 ELSE 0 END)
        FROM comptage_API.DQ_ArretEVN AS e
        WHERE e.CirculationDate BETWEEN @DateDebut AND @DateFin
        GROUP BY e.CountingId, e.EVN
    ),
    v AS (
        SELECT u.CountingId, u.EVN,
               ExtInv = CASE WHEN @nodataInvalide = 1 THEN CASE WHEN o.Nobs IS NULL OR o.ExtToutOk = 0 THEN 1 ELSE 0 END
                             ELSE COALESCE(o.ExtMauvais, 0) END,
               IntInv = CASE WHEN @inclInt = 0 THEN 0
                             WHEN @nodataInvalide = 1 THEN CASE WHEN o.Nobs IS NULL OR o.IntToutOk = 0 THEN 1 ELSE 0 END
                             ELSE COALESCE(o.IntMauvais, 0) END,
               AvecValeur = COALESCE(o.AvecValeur, 0)
        FROM u LEFT JOIN o ON o.CountingId = u.CountingId AND o.EVN = u.EVN
    ),
    g AS (
        SELECT CountingId, Invalides = SUM(ExtInv + IntInv), ExtInvalides = SUM(ExtInv),
               AvecValeur = MAX(AvecValeur), NbEvn = COUNT(*)
        FROM v GROUP BY CountingId
    )
    INSERT #R (GrainLevel, CountingId, Rang, VehIdx, [Status], FailureReason, ObservedValue, ExpectedValue, AbsoluteGap)
    SELECT 1, t.CountingId, NULL, NULL,
           CASE WHEN g.AvecValeur IS NULL OR g.AvecValeur = 0 THEN 'NOT_TESTED'
                WHEN g.Invalides <= @low THEN 'PASS' WHEN g.Invalides <= @med THEN 'WARNING' ELSE 'FAIL' END,
           CASE WHEN g.AvecValeur IS NULL OR g.AvecValeur = 0 THEN 'CAPTEURS_SANS_DONNEE'
                WHEN g.Invalides > @low THEN 'CAPTEUR_INVALIDE' END,
           (SELECT g.Invalides AS invalides, g.NbEvn AS evn_concernes,
                   CASE WHEN g.AvecValeur IS NULL OR g.AvecValeur = 0 THEN N'Sans donnée'
                        WHEN g.ExtInvalides >= 1 THEN N'Non' ELSE N'Oui' END AS ext_valides
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
           CAST(@low AS nvarchar(100)),
           CASE WHEN g.AvecValeur = 1 THEN CAST(g.Invalides AS decimal(19,6)) END
    FROM comptage_API.DQ_Train AS t
    LEFT JOIN g ON g.CountingId = t.CountingId
    WHERE t.CirculationDate BETWEEN @DateDebut AND @DateFin;

    -- But : écrire #R dans audit.LogsDQ ; les résultats précédents de la fenêtre passent à IsCurrent = 0.
    EXEC audit.usp_DQ_EcrireResultats @RegleDQID, @ExecutionId, @DateDebut, @DateFin;
END;
GO

/*==============================================================================
 ÉTAPE 14/27 - DQ-07 - Complétude de la séquence d'arrêts
 Source : sql/regles/DQ07_SequenceArrets.sql
 But : Procédure de la règle, appelée par l'orchestrateur. Lit son seuil dans
 le catalogue, calcule un statut par objet et écrit le résultat dans le
 journal. Le détail de la règle est dans l'en-tête ci-dessous.
===============================================================================*/

/*
================================================================================
 DQ-07 - Complétude de la séquence d'arrêts                     Maille : Train
================================================================================
 Arrêts attendus = nombre d'éléments de StopsJson (rang maximal attendu).
 Arrêt mesuré    = arrêt avec une occupation lue (comptage_API.DQ_Arret.HasData = 1).
   PASS si tous les arrêts attendus sont mesurés, sinon FAIL ; NOT_TESTED si aucun arrêt.
 ObservedValue : arrêts attendus / mesurés, motif des arrêts manquants (début, fin, trou, tout)
 et liste des arrêts manquants (alimente la décision d'imputation).
================================================================================
*/
CREATE OR ALTER PROCEDURE audit.usp_DQ_BR_DQ07_SequenceArrets
    @SourceName  nvarchar(50),
    @RegleDQID   int,
    @ExecutionId bigint,
    @DateDebut   date,
    @DateFin     date
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;

    -- But : table temporaire des résultats de la règle ; une ligne par objet testé, au grain voulu (1 Train, 2
    -- Arrêt, 3 Véhicule).
    CREATE TABLE #R (GrainLevel tinyint NOT NULL, CountingId bigint NOT NULL, Rang smallint NULL, VehIdx smallint NULL,
                     [Status] varchar(12) NOT NULL, FailureReason varchar(60) NULL, ObservedValue nvarchar(4000) NULL,
                     ExpectedValue nvarchar(100) NULL, AbsoluteGap decimal(19,6) NULL, RelativeGap decimal(19,6) NULL);

    -- But : calculer le statut de chaque objet (PASS, WARNING, FAIL, NOT_TESTED) avec le motif, la valeur
    -- observée, la valeur attendue et les écarts.
    INSERT #R (GrainLevel, CountingId, Rang, VehIdx, [Status], FailureReason, ObservedValue, ExpectedValue, AbsoluteGap, RelativeGap)
    SELECT 1, t.CountingId, NULL, NULL,
           CASE WHEN t.NbStops = 0 THEN 'NOT_TESTED' WHEN t.NbStopsObs = t.NbStops THEN 'PASS' ELSE 'FAIL' END,
           CASE WHEN t.NbStops = 0 THEN 'AUCUN_ARRET' WHEN t.NbStopsObs < t.NbStops THEN 'ARRETS_SANS_DONNEE' END,
           (SELECT t.NbStops AS arrets_attendus, t.NbStopsObs AS arrets_mesures, m.Motif AS motif,
                   CASE WHEN t.NbStopsObs < t.NbStops THEN LEFT(m.ArretsManquants, 1500) END AS arrets_manquants
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
           CAST(t.NbStops AS nvarchar(100)),
           CASE WHEN t.NbStops > 0 THEN CAST(t.NbStopsObs - t.NbStops AS decimal(19,6)) END,
           CASE WHEN t.NbStops > 0 THEN CAST(t.NbStopsObs - t.NbStops AS decimal(19,6)) / t.NbStops END
    FROM comptage_API.DQ_Train AS t
    LEFT JOIN comptage_API.vw_DQ_TrainMotif AS m ON m.CountingId = t.CountingId
    WHERE t.CirculationDate BETWEEN @DateDebut AND @DateFin;

    -- But : écrire #R dans audit.LogsDQ ; les résultats précédents de la fenêtre passent à IsCurrent = 0.
    EXEC audit.usp_DQ_EcrireResultats @RegleDQID, @ExecutionId, @DateDebut, @DateFin;
END;
GO

/*==============================================================================
 ÉTAPE 15/27 - DQ-08 - Équilibre des flux
 Source : sql/regles/DQ08_EquilibreFlux.sql
 But : Procédure de la règle, appelée par l'orchestrateur. Lit son seuil dans
 le catalogue, calcule un statut par objet et écrit le résultat dans le
 journal. Le détail de la règle est dans l'en-tête ci-dessous.
===============================================================================*/

/*
================================================================================
 DQ-08 - Équilibre des flux                                     Maille : Train
================================================================================
 Écart global        = | Σ montées - Σ descentes | / Σ montées               (tous les arrêts)
 Écart intermédiaire = | Σ montées - Σ descentes | / Σ montées               (arrêts hors premier et dernier)
 Seuil (ThresholdLow = 0,05).

 DEUX VARIANTES, choisies par audit.ReglesDQ.ParamsJson {"variante": "..."} :
   ACTUELLE (moteur actuel, par défaut) : FAIL si les deux écarts dépassent le seuil, PASS sinon.
       NOT_TESTED : un flux absent sur le trajet, ou Σ montées = 0, ou Σ montées intermédiaires = 0
       (donc tout train de 2 arrêts ou moins).
   INTERMEDIAIRES_SI_EXTREMITE_VIDE (proposée à l'atelier du 2026-11-11, NON TRANCHEE) :
       si les montées du 1er arrêt OU les descentes du dernier arrêt sont absentes ou nulles, on ne regarde
       que l'écart intermédiaire (FAIL s'il dépasse le seuil, PASS sinon) ; un flux absent à un arrêt
       intermédiaire reste NOT_TESTED. Sinon, règle actuelle. « À 0 » = montées = 0 au 1er arrêt et
       descentes = 0 au dernier : à confirmer par le métier.
 ObservedValue.mode : « complet » ou « intermédiaires seulement ».
================================================================================
*/
CREATE OR ALTER PROCEDURE audit.usp_DQ_BR_DQ08_EquilibreFlux
    @SourceName  nvarchar(50),
    @RegleDQID   int,
    @ExecutionId bigint,
    @DateDebut   date,
    @DateFin     date
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;

    -- But : lire dans le catalogue (audit.ReglesDQ) les seuils et paramètres de la règle.
    DECLARE @seuil decimal(19,6), @variante nvarchar(40);
    SELECT @seuil = ThresholdLow, @variante = COALESCE(JSON_VALUE(ParamsJson, '$.variante'), N'ACTUELLE')
    FROM audit.ReglesDQ WHERE RegleDQID = @RegleDQID;
    IF @variante NOT IN (N'ACTUELLE', N'INTERMEDIAIRES_SI_EXTREMITE_VIDE')
        THROW 50032, N'DQ-08 : variante inconnue dans ParamsJson.', 1;
    DECLARE @prop bit = CASE WHEN @variante = N'ACTUELLE' THEN 0 ELSE 1 END;

    -- But : table temporaire des résultats de la règle ; une ligne par objet testé, au grain voulu (1 Train, 2
    -- Arrêt, 3 Véhicule).
    CREATE TABLE #R (GrainLevel tinyint NOT NULL, CountingId bigint NOT NULL, Rang smallint NULL, VehIdx smallint NULL,
                     [Status] varchar(12) NOT NULL, FailureReason varchar(60) NULL, ObservedValue nvarchar(4000) NULL,
                     ExpectedValue nvarchar(100) NULL, AbsoluteGap decimal(19,6) NULL, RelativeGap decimal(19,6) NULL);

    ;WITH s AS (
        SELECT a.CountingId, a.Rang, a.Boarding, a.Alighting, n = COUNT(*) OVER (PARTITION BY a.CountingId)
        FROM comptage_API.DQ_Arret AS a WHERE a.CirculationDate BETWEEN @DateDebut AND @DateFin
    ),
    g AS (
        SELECT CountingId, n = MAX(n),
               FluxKo      = SUM(CASE WHEN Boarding IS NULL OR Alighting IS NULL THEN 1 ELSE 0 END),
               FluxKoInter = SUM(CASE WHEN Rang > 1 AND Rang < n AND (Boarding IS NULL OR Alighting IS NULL) THEN 1 ELSE 0 END),
               Tb = SUM(CAST(Boarding AS bigint)), Ta = SUM(CAST(Alighting AS bigint)),
               Ib = SUM(CASE WHEN Rang > 1 AND Rang < n THEN CAST(Boarding AS bigint) END),
               Ia = SUM(CASE WHEN Rang > 1 AND Rang < n THEN CAST(Alighting AS bigint) END),
               PremMont = MAX(CASE WHEN Rang = 1 THEN Boarding END),
               DernDesc = MAX(CASE WHEN Rang = n THEN Alighting END)
        FROM s GROUP BY CountingId
    ),
    c AS (
        SELECT t.CountingId, g.n, g.FluxKo, g.Tb, g.Ta, g.Ib, g.Ia,
               ExtVide = CASE WHEN g.PremMont IS NULL OR g.PremMont = 0 OR g.DernDesc IS NULL OR g.DernDesc = 0 THEN 1 ELSE 0 END,
               CompletOk = CASE WHEN g.n > 0 AND g.FluxKo = 0 AND g.Tb > 0 AND g.Ib > 0 THEN 1 ELSE 0 END,
               InterOk   = CASE WHEN g.n > 0 AND g.FluxKoInter = 0 AND g.Ib > 0 THEN 1 ELSE 0 END,
               EcartGlobal = CASE WHEN g.Tb > 0 THEN CAST(ABS(g.Tb - g.Ta) AS decimal(19,6)) / g.Tb END,
               EcartInter  = CASE WHEN g.Ib > 0 THEN CAST(ABS(g.Ib - g.Ia) AS decimal(19,6)) / g.Ib END
        FROM comptage_API.DQ_Train AS t LEFT JOIN g ON g.CountingId = t.CountingId
        WHERE t.CirculationDate BETWEEN @DateDebut AND @DateFin
    ),
    m AS (
        SELECT c.*, Mode = CASE WHEN @prop = 1 AND c.ExtVide = 1 AND c.InterOk = 1 THEN N'intermédiaires seulement'
                                WHEN c.CompletOk = 1 THEN N'complet' END
        FROM c
    )
    -- But : calculer le statut de chaque objet (PASS, WARNING, FAIL, NOT_TESTED) avec le motif, la valeur
    -- observée, la valeur attendue et les écarts.
    INSERT #R (GrainLevel, CountingId, Rang, VehIdx, [Status], FailureReason, ObservedValue, ExpectedValue, AbsoluteGap, RelativeGap)
    SELECT 1, m.CountingId, NULL, NULL,
           CASE WHEN m.Mode IS NULL THEN 'NOT_TESTED'
                WHEN m.Mode = N'complet' THEN CASE WHEN m.EcartGlobal > @seuil AND m.EcartInter > @seuil THEN 'FAIL' ELSE 'PASS' END
                ELSE CASE WHEN m.EcartInter > @seuil THEN 'FAIL' ELSE 'PASS' END END,
           CASE WHEN m.Mode IS NULL THEN CASE WHEN m.n IS NULL OR m.n = 0 THEN 'AUCUN_ARRET'
                                              WHEN m.n <= 2 THEN 'MOINS_DE_3_ARRETS'
                                              WHEN m.FluxKo > 0 THEN 'FLUX_ABSENT'
                                              ELSE 'DENOMINATEUR_NUL' END
                WHEN m.Mode = N'complet' AND m.EcartGlobal > @seuil AND m.EcartInter > @seuil THEN 'FLUX_DESEQUILIBRES'
                WHEN m.Mode <> N'complet' AND m.EcartInter > @seuil THEN 'FLUX_INTERMEDIAIRES_DESEQUILIBRES' END,
           (SELECT m.Mode AS mode,
                   CASE WHEN m.Mode IS NOT NULL THEN CAST(m.EcartGlobal * 100 AS decimal(9,2)) END AS ecart_global_pct,
                   CASE WHEN m.Mode IS NOT NULL THEN CAST(m.EcartInter * 100 AS decimal(9,2)) END AS ecart_inter_pct
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
           CAST(@seuil AS nvarchar(100)),
           CASE WHEN m.Mode IS NOT NULL THEN CAST(ABS(m.Tb - m.Ta) AS decimal(19,6)) END,
           CASE WHEN m.Mode IS NOT NULL THEN m.EcartGlobal END
    FROM m;

    -- But : écrire #R dans audit.LogsDQ ; les résultats précédents de la fenêtre passent à IsCurrent = 0.
    EXEC audit.usp_DQ_EcrireResultats @RegleDQID, @ExecutionId, @DateDebut, @DateFin;
END;
GO

/*==============================================================================
 ÉTAPE 16/27 - DQ-09 - Remise à zéro à l'origine
 Source : sql/regles/DQ09_RemiseZeroOrigine.sql
 But : Procédure de la règle, appelée par l'orchestrateur. Lit son seuil dans
 le catalogue, calcule un statut par objet et écrit le résultat dans le
 journal. Le détail de la règle est dans l'en-tête ci-dessous.
===============================================================================*/

/*
================================================================================
 DQ-09 - Remise à zéro à l'origine                              Maille : Train
================================================================================
 Origine = premier arrêt de type Start (stopType = 'Start').
   FAIL si occupation = 0 alors que des montées sont enregistrées ;
   sinon écart = | occupation à l'origine - montées à l'origine | / capacité à l'origine ;
   PASS si écart <= seuil (0,02), FAIL au-delà.
   NOT_TESTED : pas d'origine, origine sans donnée, montées absentes, capacité absente ou nulle
   (sauf le cas « occupation 0 avec montées », jugé FAIL sans capacité).
 Seuil (audit.ReglesDQ) : ThresholdLow = 0,02 (ratio de la capacité, comme DQ-03).
================================================================================
*/
CREATE OR ALTER PROCEDURE audit.usp_DQ_BR_DQ09_RemiseZeroOrigine
    @SourceName  nvarchar(50),
    @RegleDQID   int,
    @ExecutionId bigint,
    @DateDebut   date,
    @DateFin     date
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;

    -- But : lire dans le catalogue (audit.ReglesDQ) les seuils et paramètres de la règle.
    DECLARE @seuil decimal(19,6);
    SELECT @seuil = ThresholdLow FROM audit.ReglesDQ WHERE RegleDQID = @RegleDQID;

    -- But : table temporaire des résultats de la règle ; une ligne par objet testé, au grain voulu (1 Train, 2
    -- Arrêt, 3 Véhicule).
    CREATE TABLE #R (GrainLevel tinyint NOT NULL, CountingId bigint NOT NULL, Rang smallint NULL, VehIdx smallint NULL,
                     [Status] varchar(12) NOT NULL, FailureReason varchar(60) NULL, ObservedValue nvarchar(4000) NULL,
                     ExpectedValue nvarchar(100) NULL, AbsoluteGap decimal(19,6) NULL, RelativeGap decimal(19,6) NULL);

    ;WITH o AS (
        SELECT t.CountingId, x.Rang, x.HasData, x.Occ, x.Boarding, x.Capacity,
               Taux = CASE WHEN x.HasData = 1 AND x.Boarding IS NOT NULL AND x.Capacity > 0
                           THEN CAST(ABS(CAST(x.Occ AS bigint) - x.Boarding) AS decimal(19,6)) / x.Capacity END
        FROM comptage_API.DQ_Train AS t
        OUTER APPLY (SELECT TOP (1) a.Rang, a.HasData, a.Occ, a.Boarding, a.Capacity
                     FROM comptage_API.DQ_Arret AS a
                     WHERE a.CountingId = t.CountingId AND a.StopType = 'Start'
                     ORDER BY a.Rang ASC) AS x
        WHERE t.CirculationDate BETWEEN @DateDebut AND @DateFin
    ),
    k AS (
        SELECT o.*,
               Teste = CASE WHEN o.HasData = 1 AND o.Boarding IS NOT NULL
                             AND ((o.Occ = 0 AND o.Boarding > 0) OR o.Capacity > 0) THEN 1 ELSE 0 END
        FROM o
    )
    -- But : calculer le statut de chaque objet (PASS, WARNING, FAIL, NOT_TESTED) avec le motif, la valeur
    -- observée, la valeur attendue et les écarts.
    INSERT #R (GrainLevel, CountingId, Rang, VehIdx, [Status], FailureReason, ObservedValue, ExpectedValue, AbsoluteGap, RelativeGap)
    SELECT 1, k.CountingId, NULL, NULL,
           CASE WHEN k.Teste = 0 THEN 'NOT_TESTED'
                WHEN k.Occ = 0 AND k.Boarding > 0 THEN 'FAIL'
                WHEN k.Taux <= @seuil THEN 'PASS' ELSE 'FAIL' END,
           CASE WHEN k.Rang IS NULL THEN 'PAS_D_ORIGINE'
                WHEN k.HasData = 0 THEN 'ORIGINE_SANS_DONNEE'
                WHEN k.Boarding IS NULL THEN 'MONTEES_ABSENTES'
                WHEN k.Teste = 0 THEN 'CAPACITE_ABSENTE_OU_NULLE'
                WHEN k.Occ = 0 AND k.Boarding > 0 THEN 'OCCUPATION_NULLE_AVEC_MONTEES'
                WHEN k.Taux > @seuil THEN 'OCCUPATION_DIFFERENTE_DES_MONTEES' END,
           (SELECT k.Occ AS occupation, k.Boarding AS montees, k.Capacity AS capacite,
                   CASE WHEN k.Taux IS NOT NULL THEN CAST(k.Taux * 100 AS decimal(9,2)) END AS taux_pct
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
           CASE WHEN k.Teste = 1 THEN CAST(@seuil AS nvarchar(100)) END,
           CASE WHEN k.Teste = 1 THEN ABS(CAST(k.Occ AS decimal(19,6)) - k.Boarding) END,
           k.Taux
    FROM k;

    -- But : écrire #R dans audit.LogsDQ ; les résultats précédents de la fenêtre passent à IsCurrent = 0.
    EXEC audit.usp_DQ_EcrireResultats @RegleDQID, @ExecutionId, @DateDebut, @DateFin;
END;
GO

/*==============================================================================
 ÉTAPE 17/27 - DQ-10 - Occupation reconstruite non négative
 Source : sql/regles/DQ10_OccupationNonNegative.sql
 But : Procédure de la règle, appelée par l'orchestrateur. Lit son seuil dans
 le catalogue, calcule un statut par objet et écrit le résultat dans le
 journal. Le détail de la règle est dans l'en-tête ci-dessous.
===============================================================================*/

/*
================================================================================
 DQ-10 - Occupation reconstruite non négative          Mailles : Arrêt + Train
================================================================================
 Cumul(n) = Σ (montées - descentes) de 1 à n (comptage_API.DQ_Arret.CumulFlux, même cumul que DQ-01).
   Arrêt : PASS si cumul >= 0 ; WARNING si cumul >= -3 ; FAIL en dessous ; NOT_TESTED si un flux manque
           sur 1..n.
   Train : minimum du cumul, mêmes seuils ; NOT_TESTED si un flux manque sur le trajet.
 Seuil (audit.ReglesDQ) : ThresholdLow = 0 (PASS si >= 0), ThresholdMedium = -3 (WARNING si >= -3).
 ObservedValue (Train) : minimum du cumul et premier arrêt où le cumul devient négatif.
================================================================================
*/
CREATE OR ALTER PROCEDURE audit.usp_DQ_BR_DQ10_OccupationNonNegative
    @SourceName  nvarchar(50),
    @RegleDQID   int,
    @ExecutionId bigint,
    @DateDebut   date,
    @DateFin     date
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;

    -- But : lire dans le catalogue (audit.ReglesDQ) les seuils et paramètres de la règle.
    DECLARE @low decimal(19,6), @med decimal(19,6);
    SELECT @low = ThresholdLow, @med = ThresholdMedium FROM audit.ReglesDQ WHERE RegleDQID = @RegleDQID;

    -- But : table temporaire des résultats de la règle ; une ligne par objet testé, au grain voulu (1 Train, 2
    -- Arrêt, 3 Véhicule).
    CREATE TABLE #R (GrainLevel tinyint NOT NULL, CountingId bigint NOT NULL, Rang smallint NULL, VehIdx smallint NULL,
                     [Status] varchar(12) NOT NULL, FailureReason varchar(60) NULL, ObservedValue nvarchar(4000) NULL,
                     ExpectedValue nvarchar(100) NULL, AbsoluteGap decimal(19,6) NULL, RelativeGap decimal(19,6) NULL);

    -- Arrêt
    -- But : calculer le statut de chaque objet (PASS, WARNING, FAIL, NOT_TESTED) avec le motif, la valeur
    -- observée, la valeur attendue et les écarts.
    INSERT #R (GrainLevel, CountingId, Rang, VehIdx, [Status], FailureReason, ObservedValue, ExpectedValue, AbsoluteGap)
    SELECT 2, a.CountingId, a.Rang, NULL,
           CASE WHEN a.CumulFlux IS NULL THEN 'NOT_TESTED'
                WHEN a.CumulFlux >= @low THEN 'PASS' WHEN a.CumulFlux >= @med THEN 'WARNING' ELSE 'FAIL' END,
           CASE WHEN a.CumulFlux IS NULL THEN 'FLUX_ABSENT_SUR_TRAJET'
                WHEN a.CumulFlux < @low THEN 'OCCUPATION_RECONSTRUITE_NEGATIVE' END,
           (SELECT a.CumulFlux AS cumul FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
           CAST(@low AS nvarchar(100)),
           CASE WHEN a.CumulFlux < @low THEN CAST(a.CumulFlux - @low AS decimal(19,6)) END
    FROM comptage_API.DQ_Arret AS a
    WHERE a.CirculationDate BETWEEN @DateDebut AND @DateFin;

    -- Train
    ;WITH g AS (
        SELECT CountingId, n = COUNT(*), nNull = SUM(CASE WHEN CumulFlux IS NULL THEN 1 ELSE 0 END), Minimum = MIN(CumulFlux)
        FROM comptage_API.DQ_Arret WHERE CirculationDate BETWEEN @DateDebut AND @DateFin
        GROUP BY CountingId
    )
    INSERT #R (GrainLevel, CountingId, Rang, VehIdx, [Status], FailureReason, ObservedValue, ExpectedValue, AbsoluteGap)
    SELECT 1, t.CountingId, NULL, NULL,
           CASE WHEN g.n IS NULL OR g.nNull > 0 THEN 'NOT_TESTED'
                WHEN g.Minimum >= @low THEN 'PASS' WHEN g.Minimum >= @med THEN 'WARNING' ELSE 'FAIL' END,
           CASE WHEN g.n IS NULL THEN 'AUCUN_ARRET'
                WHEN g.nNull > 0 THEN 'FLUX_ABSENT_SUR_TRAJET'
                WHEN g.Minimum < @low THEN 'OCCUPATION_RECONSTRUITE_NEGATIVE' END,
           (SELECT CASE WHEN g.nNull = 0 THEN g.Minimum END AS cumul_min, fn.StationName AS premier_arret_negatif
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
           CAST(@low AS nvarchar(100)),
           CASE WHEN g.nNull = 0 AND g.Minimum < @low THEN CAST(g.Minimum - @low AS decimal(19,6)) END
    FROM comptage_API.DQ_Train AS t
    LEFT JOIN g ON g.CountingId = t.CountingId
    OUTER APPLY (SELECT TOP (1) a.StationName FROM comptage_API.DQ_Arret AS a
                 WHERE a.CountingId = t.CountingId AND a.CumulFlux < 0 ORDER BY a.Rang) AS fn
    WHERE t.CirculationDate BETWEEN @DateDebut AND @DateFin;

    -- But : écrire #R dans audit.LogsDQ ; les résultats précédents de la fenêtre passent à IsCurrent = 0.
    EXEC audit.usp_DQ_EcrireResultats @RegleDQID, @ExecutionId, @DateDebut, @DateFin;
END;
GO

/*==============================================================================
 ÉTAPE 18/27 - DQ-11 - Cohérence entre les mailles
 Source : sql/regles/DQ11_CoherenceMailles.sql
 But : Procédure de la règle, appelée par l'orchestrateur. Lit son seuil dans
 le catalogue, calcule un statut par objet et écrit le résultat dans le
 journal. Le détail de la règle est dans l'en-tête ci-dessous.
===============================================================================*/

/*
================================================================================
 DQ-11 - Cohérence entre les mailles                    Mailles : Arrêt + Train
================================================================================
 Compare la valeur de l'arrêt à la somme de ses véhicules, pour trois mesures :
 occupation, montées, descentes (montées / descentes d'un véhicule = 1re + 2e classe).
   écart relatif(A, B) = 0 si A = B = 0, sinon | A - B | / MAX(|A| ; |B|)   (on garde le pire des trois)
   PASS si écart <= 1 % ; WARNING si <= 5 % ; FAIL au-delà.
   NOT_TESTED : arrêt sans donnée, sans véhicule, flux de l'arrêt absent, ou valeur absente
   sur au moins un véhicule.
   Train : pire statut de ses arrêts.
 Seuils (audit.ReglesDQ) : ThresholdLow = 0,01 ; ThresholdMedium = 0,05.
 À discuter avec l'exploitant : si la valeur de l'arrêt est calculée comme la somme des véhicules,
 la règle ne peut rien détecter (poids 0 possible dans le score : audit.ReglesDQ.ScoreWeight).
================================================================================
*/
CREATE OR ALTER PROCEDURE audit.usp_DQ_BR_DQ11_CoherenceMailles
    @SourceName  nvarchar(50),
    @RegleDQID   int,
    @ExecutionId bigint,
    @DateDebut   date,
    @DateFin     date
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;

    -- But : lire dans le catalogue (audit.ReglesDQ) les seuils et paramètres de la règle.
    DECLARE @low decimal(19,6), @med decimal(19,6);
    SELECT @low = ThresholdLow, @med = ThresholdMedium FROM audit.ReglesDQ WHERE RegleDQID = @RegleDQID;

    -- But : table temporaire des résultats de la règle ; une ligne par objet testé, au grain voulu (1 Train, 2
    -- Arrêt, 3 Véhicule).
    CREATE TABLE #R (GrainLevel tinyint NOT NULL, CountingId bigint NOT NULL, Rang smallint NULL, VehIdx smallint NULL,
                     [Status] varchar(12) NOT NULL, FailureReason varchar(60) NULL, ObservedValue nvarchar(4000) NULL,
                     ExpectedValue nvarchar(100) NULL, AbsoluteGap decimal(19,6) NULL, RelativeGap decimal(19,6) NULL);

    ;WITH v AS (
        SELECT e.CountingId, e.Rang, Nv = COUNT(*),
               Incomplet = SUM(CASE WHEN e.Occ IS NULL OR e.Boarding IS NULL OR e.Alighting IS NULL THEN 1 ELSE 0 END),
               SOcc = SUM(CAST(e.Occ AS bigint)), SBoard = SUM(CAST(e.Boarding AS bigint)), SAlight = SUM(CAST(e.Alighting AS bigint))
        FROM comptage_API.DQ_ArretEVN AS e
        WHERE e.CirculationDate BETWEEN @DateDebut AND @DateFin
        GROUP BY e.CountingId, e.Rang
    ),
    c AS (
        SELECT a.CountingId, a.Rang, a.HasData, a.Occ, a.Boarding, a.Alighting, v.Nv, v.Incomplet, v.SOcc, v.SBoard, v.SAlight,
               Teste = CASE WHEN a.HasData = 1 AND v.Nv > 0 AND a.Boarding IS NOT NULL AND a.Alighting IS NOT NULL
                             AND v.Incomplet = 0 THEN 1 ELSE 0 END
        FROM comptage_API.DQ_Arret AS a LEFT JOIN v ON v.CountingId = a.CountingId AND v.Rang = a.Rang
        WHERE a.CirculationDate BETWEEN @DateDebut AND @DateFin
    ),
    d AS (
        SELECT c.*,
               G1 = CASE WHEN c.Teste = 0 THEN NULL WHEN c.Occ = 0 AND c.SOcc = 0 THEN 0.0
                         ELSE ABS(CAST(c.Occ AS decimal(19,6)) - c.SOcc)
                              / NULLIF(CASE WHEN ABS(CAST(c.Occ AS bigint)) > ABS(c.SOcc) THEN ABS(CAST(c.Occ AS bigint)) ELSE ABS(c.SOcc) END, 0) END,
               G2 = CASE WHEN c.Teste = 0 THEN NULL WHEN c.Boarding = 0 AND c.SBoard = 0 THEN 0.0
                         ELSE ABS(CAST(c.Boarding AS decimal(19,6)) - c.SBoard)
                              / NULLIF(CASE WHEN ABS(CAST(c.Boarding AS bigint)) > ABS(c.SBoard) THEN ABS(CAST(c.Boarding AS bigint)) ELSE ABS(c.SBoard) END, 0) END,
               G3 = CASE WHEN c.Teste = 0 THEN NULL WHEN c.Alighting = 0 AND c.SAlight = 0 THEN 0.0
                         ELSE ABS(CAST(c.Alighting AS decimal(19,6)) - c.SAlight)
                              / NULLIF(CASE WHEN ABS(CAST(c.Alighting AS bigint)) > ABS(c.SAlight) THEN ABS(CAST(c.Alighting AS bigint)) ELSE ABS(c.SAlight) END, 0) END
        FROM c
    ),
    p AS (
        SELECT d.*, Pire = CASE WHEN d.G1 >= d.G2 AND d.G1 >= d.G3 THEN d.G1 WHEN d.G2 >= d.G3 THEN d.G2 ELSE d.G3 END
        FROM d
    )
    -- But : calculer le statut de chaque objet (PASS, WARNING, FAIL, NOT_TESTED) avec le motif, la valeur
    -- observée, la valeur attendue et les écarts.
    INSERT #R (GrainLevel, CountingId, Rang, VehIdx, [Status], FailureReason, ObservedValue, ExpectedValue, RelativeGap)
    SELECT 2, p.CountingId, p.Rang, NULL,
           CASE WHEN p.Teste = 0 THEN 'NOT_TESTED' WHEN p.Pire <= @low THEN 'PASS' WHEN p.Pire <= @med THEN 'WARNING' ELSE 'FAIL' END,
           CASE WHEN p.Teste = 0 THEN CASE WHEN p.HasData = 0 THEN 'ARRET_SANS_DONNEE' WHEN p.Nv IS NULL THEN 'ARRET_SANS_VEHICULE'
                                           WHEN p.Boarding IS NULL OR p.Alighting IS NULL THEN 'FLUX_ARRET_ABSENT'
                                           ELSE 'VALEUR_VEHICULE_ABSENTE' END
                WHEN p.Pire > @low THEN 'ECART_ARRET_SOMME_VEHICULES' END,
           (SELECT p.Occ AS occupation_arret, p.SOcc AS occupation_vehicules,
                   p.Boarding AS montees_arret, p.SBoard AS montees_vehicules,
                   p.Alighting AS descentes_arret, p.SAlight AS descentes_vehicules,
                   CASE WHEN p.Teste = 1 THEN CAST(p.Pire * 100 AS decimal(9,2)) END AS ecart_max_pct
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
           CAST(@low AS nvarchar(100)),
           CASE WHEN p.Teste = 1 THEN p.Pire END
    FROM p;

    -- But : le statut Train est le pire statut des lignes fines.
    EXEC audit.usp_DQ_SyntheseTrain @DateDebut, @DateFin, 2, 'ARRET_INCOHERENT_AVEC_VEHICULES';
    -- But : écrire #R dans audit.LogsDQ ; les résultats précédents de la fenêtre passent à IsCurrent = 0.
    EXEC audit.usp_DQ_EcrireResultats @RegleDQID, @ExecutionId, @DateDebut, @DateFin;
END;
GO

/*==============================================================================
 ÉTAPE 19/27 - DQ-12 - Valeurs exploitables
 Source : sql/regles/DQ12_ValeursExploitables.sql
 But : Procédure de la règle, appelée par l'orchestrateur. Lit son seuil dans
 le catalogue, calcule un statut par objet et écrit le résultat dans le
 journal. Le détail de la règle est dans l'en-tête ci-dessous.
===============================================================================*/

/*
================================================================================
 DQ-12 - Valeurs exploitables                  Mailles : Véhicule, Arrêt, Train
================================================================================
 Taux exploitable = valeurs lues / valeurs attendues. Un vrai zéro est exploitable.
   PASS si taux = 100 % (ThresholdMedium = 1,00) ; WARNING si taux >= 98 % (ThresholdLow = 0,98) ; FAIL sinon.
 Valeurs contrôlées (4 par véhicule et par arrêt) :
   Véhicule : occupation, sensorCapacity, montées, descentes
   Arrêt    : occupation, capacité, montées, descentes
   Train    : TotalCapacity, TotalOccupancy, OccupancyRatePercent (3 valeurs)
              + les 4 valeurs de CHAQUE ARRET AVEC DONNEE (choix validé le 2026-11-11 : les arrêts muets
              relèvent de DQ-07 et ne sont plus comptés une seconde fois ici).
 ObservedValue (Train) : taux, valeurs absentes, valeurs illisibles, arrêts à occupation zéro
 (information sur les zéros).
================================================================================
*/
CREATE OR ALTER PROCEDURE audit.usp_DQ_BR_DQ12_ValeursExploitables
    @SourceName  nvarchar(50),
    @RegleDQID   int,
    @ExecutionId bigint,
    @DateDebut   date,
    @DateFin     date
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;

    -- But : lire dans le catalogue (audit.ReglesDQ) les seuils et paramètres de la règle.
    DECLARE @warn decimal(19,6), @pass decimal(19,6);
    SELECT @warn = ThresholdLow, @pass = ThresholdMedium FROM audit.ReglesDQ WHERE RegleDQID = @RegleDQID;

    -- But : table temporaire des résultats de la règle ; une ligne par objet testé, au grain voulu (1 Train, 2
    -- Arrêt, 3 Véhicule).
    CREATE TABLE #R (GrainLevel tinyint NOT NULL, CountingId bigint NOT NULL, Rang smallint NULL, VehIdx smallint NULL,
                     [Status] varchar(12) NOT NULL, FailureReason varchar(60) NULL, ObservedValue nvarchar(4000) NULL,
                     ExpectedValue nvarchar(100) NULL, AbsoluteGap decimal(19,6) NULL, RelativeGap decimal(19,6) NULL);

    -- Véhicule
    -- But : calculer le statut de chaque objet (PASS, WARNING, FAIL, NOT_TESTED) avec le motif, la valeur
    -- observée, la valeur attendue et les écarts.
    INSERT #R (GrainLevel, CountingId, Rang, VehIdx, [Status], FailureReason, ObservedValue, ExpectedValue, RelativeGap)
    SELECT 3, e.CountingId, e.Rang, e.VehIdx,
           CASE WHEN x.Taux >= @pass THEN 'PASS' WHEN x.Taux >= @warn THEN 'WARNING' ELSE 'FAIL' END,
           CASE WHEN x.Taux < @pass THEN 'VALEUR_ABSENTE_OU_ILLISIBLE' END,
           (SELECT CAST(x.Taux * 100 AS decimal(9,2)) AS taux_pct, 4 - q.Ok AS valeurs_non_lues FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
           CAST(@pass AS nvarchar(100)), x.Taux
    FROM comptage_API.DQ_ArretEVN AS e
    CROSS APPLY (SELECT Ok = (CASE WHEN e.OccSt = 0 THEN 1 ELSE 0 END) + (CASE WHEN e.SensorCapSt = 0 THEN 1 ELSE 0 END)
                           + (CASE WHEN e.BoardingSt = 0 THEN 1 ELSE 0 END) + (CASE WHEN e.AlightingSt = 0 THEN 1 ELSE 0 END)) AS q
    CROSS APPLY (SELECT Taux = CAST(q.Ok AS decimal(19,6)) / 4) AS x
    WHERE e.CirculationDate BETWEEN @DateDebut AND @DateFin;

    -- Arrêt (tous les arrêts, y compris muets : l'arrêt muet est FAIL à sa propre maille)
    INSERT #R (GrainLevel, CountingId, Rang, VehIdx, [Status], FailureReason, ObservedValue, ExpectedValue, RelativeGap)
    SELECT 2, a.CountingId, a.Rang, NULL,
           CASE WHEN x.Taux >= @pass THEN 'PASS' WHEN x.Taux >= @warn THEN 'WARNING' ELSE 'FAIL' END,
           CASE WHEN x.Taux < @pass THEN 'VALEUR_ABSENTE_OU_ILLISIBLE' END,
           (SELECT CAST(x.Taux * 100 AS decimal(9,2)) AS taux_pct, 4 - q.Ok AS valeurs_non_lues FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
           CAST(@pass AS nvarchar(100)), x.Taux
    FROM comptage_API.DQ_Arret AS a
    CROSS APPLY (SELECT Ok = (CASE WHEN a.OccSt = 0 THEN 1 ELSE 0 END) + (CASE WHEN a.CapacitySt = 0 THEN 1 ELSE 0 END)
                           + (CASE WHEN a.BoardingSt = 0 THEN 1 ELSE 0 END) + (CASE WHEN a.AlightingSt = 0 THEN 1 ELSE 0 END)) AS q
    CROSS APPLY (SELECT Taux = CAST(q.Ok AS decimal(19,6)) / 4) AS x
    WHERE a.CirculationDate BETWEEN @DateDebut AND @DateFin;

    -- Train : 3 valeurs du train + 4 valeurs par arrêt AVEC donnée
    ;WITH s AS (
        SELECT a.CountingId,
               Nb   = COUNT(*),
               Ok   = SUM((CASE WHEN a.OccSt = 0 THEN 1 ELSE 0 END) + (CASE WHEN a.CapacitySt = 0 THEN 1 ELSE 0 END)
                         + (CASE WHEN a.BoardingSt = 0 THEN 1 ELSE 0 END) + (CASE WHEN a.AlightingSt = 0 THEN 1 ELSE 0 END)),
               Abs_ = SUM((CASE WHEN a.OccSt = 1 THEN 1 ELSE 0 END) + (CASE WHEN a.CapacitySt = 1 THEN 1 ELSE 0 END)
                         + (CASE WHEN a.BoardingSt = 1 THEN 1 ELSE 0 END) + (CASE WHEN a.AlightingSt = 1 THEN 1 ELSE 0 END)),
               Ill  = SUM((CASE WHEN a.OccSt = 2 THEN 1 ELSE 0 END) + (CASE WHEN a.CapacitySt = 2 THEN 1 ELSE 0 END)
                         + (CASE WHEN a.BoardingSt = 2 THEN 1 ELSE 0 END) + (CASE WHEN a.AlightingSt = 2 THEN 1 ELSE 0 END))
        FROM comptage_API.DQ_Arret AS a
        WHERE a.CirculationDate BETWEEN @DateDebut AND @DateFin AND a.HasData = 1
        GROUP BY a.CountingId
    ),
    z AS (
        SELECT CountingId, Zeros = SUM(CASE WHEN Occ = 0 THEN 1 ELSE 0 END)
        FROM comptage_API.DQ_Arret WHERE CirculationDate BETWEEN @DateDebut AND @DateFin GROUP BY CountingId
    ),
    c AS (
        SELECT t.CountingId,
               Tot = 3 + 4 * COALESCE(s.Nb, 0),
               Ok  = (CASE WHEN t.CapSt = 0 THEN 1 ELSE 0 END) + (CASE WHEN t.OccSt = 0 THEN 1 ELSE 0 END)
                   + (CASE WHEN t.RateSt = 0 THEN 1 ELSE 0 END) + COALESCE(s.Ok, 0),
               Abs_ = (CASE WHEN t.CapSt = 1 THEN 1 ELSE 0 END) + (CASE WHEN t.OccSt = 1 THEN 1 ELSE 0 END)
                    + (CASE WHEN t.RateSt = 1 THEN 1 ELSE 0 END) + COALESCE(s.Abs_, 0),
               Ill  = (CASE WHEN t.CapSt = 2 THEN 1 ELSE 0 END) + (CASE WHEN t.OccSt = 2 THEN 1 ELSE 0 END)
                    + (CASE WHEN t.RateSt = 2 THEN 1 ELSE 0 END) + COALESCE(s.Ill, 0),
               Zeros = COALESCE(z.Zeros, 0)
        FROM comptage_API.DQ_Train AS t
        LEFT JOIN s ON s.CountingId = t.CountingId
        LEFT JOIN z ON z.CountingId = t.CountingId
        WHERE t.CirculationDate BETWEEN @DateDebut AND @DateFin
    )
    INSERT #R (GrainLevel, CountingId, Rang, VehIdx, [Status], FailureReason, ObservedValue, ExpectedValue, RelativeGap)
    SELECT 1, c.CountingId, NULL, NULL,
           CASE WHEN c.Ok * 1.0 / c.Tot >= @pass THEN 'PASS' WHEN c.Ok * 1.0 / c.Tot >= @warn THEN 'WARNING' ELSE 'FAIL' END,
           CASE WHEN c.Ok * 1.0 / c.Tot < @pass THEN 'VALEUR_ABSENTE_OU_ILLISIBLE' END,
           (SELECT CAST(c.Ok * 100.0 / c.Tot AS decimal(9,2)) AS taux_pct, c.Abs_ AS absents, c.Ill AS illisibles, c.Zeros AS arrets_occupation_zero
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
           CAST(@pass AS nvarchar(100)), CAST(c.Ok AS decimal(19,6)) / c.Tot
    FROM c;

    -- But : écrire #R dans audit.LogsDQ ; les résultats précédents de la fenêtre passent à IsCurrent = 0.
    EXEC audit.usp_DQ_EcrireResultats @RegleDQID, @ExecutionId, @DateDebut, @DateFin;
END;
GO

/*==============================================================================
 ÉTAPE 20/27 - DQ-13 - Capteur figé
 Source : sql/regles/DQ13_CapteurFige.sql
 But : Procédure de la règle, appelée par l'orchestrateur. Lit son seuil dans
 le catalogue, calcule un statut par objet et écrit le résultat dans le
 journal. Le détail de la règle est dans l'en-tête ci-dessous.
===============================================================================*/

/*
================================================================================
 DQ-13 - Capteur figé                Mailles : Véhicule (séquence EVN) + Train (synthèse)
================================================================================
 Séquence = occupation d'un EVN à chacun des arrêts du train, dans l'ordre. Un EVN absent à un arrêt, ou
 sans occupation lue, rend la séquence incomplète.
 Répétitions = plus longue suite d'arrêts consécutifs où l'EVN a la même occupation.
   NOT_TESTED : séquence incomplète ou de moins de 5 arrêts (ParamsJson.min_arrets).
   FAIL       : répétitions >= 6 (> ThresholdMedium = 5) ou occupation constante sur toute la séquence
   WARNING    : répétitions >= 4 (> ThresholdLow = 3)
   PASS       : sinon
 Chaque ligne « véhicule x arrêt » reçoit le statut de la séquence de son EVN (comme le moteur Python).
 Train : pire statut de ses EVN ; ObservedValue = répétitions maximales et nombre d'EVN figés.

 DEUX VARIANTES, choisies par audit.ReglesDQ.ParamsJson {"variante": "..."} :
   ACTUELLE (moteur actuel, par défaut) : une occupation répétée compte toujours, même sans mouvement.
       Constat C28 : 82 % des FAIL de séquence sont des zéros répétés (véhicule vide qui reste vide).
   MOUVEMENT_NET (proposée à l'atelier du 2026-11-11, NON TRANCHEE) : une répétition (occupation identique à celle
       de l'arrêt précédent) n'est suspecte que si l'EVN a un mouvement net à cet arrêt (montées - descentes <> 0).
       Répétitions = 1 + plus longue suite de répétitions suspectes ; montées/descentes absentes pour l'EVN
       -> séquence NOT_TESTED ; la notion « occupation constante » disparaît ; FAIL aussi si TOUTES les
       répétitions de la séquence sont suspectes (cas « zéro sur tout le trajet avec mouvements enregistrés »).
       Hypothèses de codage à confirmer : mouvement net <> 0 (et non montées + descentes > 0) ; échelle
       des seuils inchangée (1 + chaîne de répétitions suspectes).
================================================================================
*/
CREATE OR ALTER PROCEDURE audit.usp_DQ_BR_DQ13_CapteurFige
    @SourceName  nvarchar(50),
    @RegleDQID   int,
    @ExecutionId bigint,
    @DateDebut   date,
    @DateFin     date
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;

    -- But : lire dans le catalogue (audit.ReglesDQ) les seuils et paramètres de la règle.
    DECLARE @low decimal(19,6), @med decimal(19,6), @minArrets int, @variante nvarchar(30);
    SELECT @low = ThresholdLow, @med = ThresholdMedium,
           @minArrets = COALESCE(TRY_CONVERT(int, JSON_VALUE(ParamsJson, '$.min_arrets')), 5),
           @variante = COALESCE(JSON_VALUE(ParamsJson, '$.variante'), N'ACTUELLE')
    FROM audit.ReglesDQ WHERE RegleDQID = @RegleDQID;
    IF @variante NOT IN (N'ACTUELLE', N'MOUVEMENT_NET')
        THROW 50033, N'DQ-13 : variante inconnue dans ParamsJson.', 1;
    DECLARE @prop bit = CASE WHEN @variante = N'ACTUELLE' THEN 0 ELSE 1 END;

    -- But : table temporaire des résultats de la règle ; une ligne par objet testé, au grain voulu (1 Train, 2
    -- Arrêt, 3 Véhicule).
    CREATE TABLE #R (GrainLevel tinyint NOT NULL, CountingId bigint NOT NULL, Rang smallint NULL, VehIdx smallint NULL,
                     [Status] varchar(12) NOT NULL, FailureReason varchar(60) NULL, ObservedValue nvarchar(4000) NULL,
                     ExpectedValue nvarchar(100) NULL, AbsoluteGap decimal(19,6) NULL, RelativeGap decimal(19,6) NULL);

    -- Grille complète : un EVN x tous les arrêts de son train (Occ NULL si l'EVN est absent de l'arrêt)
    CREATE TABLE #Seq (CountingId bigint NOT NULL, EVN nvarchar(20) NOT NULL, Rang smallint NOT NULL,
                       Occ int NULL, Net int NULL, Susp tinyint NOT NULL DEFAULT (0),
                       PRIMARY KEY (CountingId, EVN, Rang));
    INSERT #Seq (CountingId, EVN, Rang, Occ, Net)
    SELECT a.CountingId, ev.EVN, a.Rang, v.Occ,
           CASE WHEN v.Boarding IS NOT NULL AND v.Alighting IS NOT NULL THEN v.Boarding - v.Alighting END
    FROM comptage_API.DQ_Arret AS a
    JOIN (SELECT DISTINCT CountingId, EVN FROM comptage_API.DQ_ArretEVN
          WHERE CirculationDate BETWEEN @DateDebut AND @DateFin) AS ev ON ev.CountingId = a.CountingId
    OUTER APPLY (SELECT TOP (1) x.Occ, x.Boarding, x.Alighting FROM comptage_API.DQ_ArretEVN AS x
                 WHERE x.CountingId = a.CountingId AND x.Rang = a.Rang AND x.EVN = ev.EVN
                 ORDER BY x.VehIdx) AS v
    WHERE a.CirculationDate BETWEEN @DateDebut AND @DateFin;

    -- Répétition suspecte (variante MOUVEMENT_NET) : même occupation que l'arrêt précédent ET mouvement net <> 0
    ;WITH l AS (
        SELECT CountingId, EVN, Rang, Occ, Net, PrevOcc = LAG(Occ) OVER (PARTITION BY CountingId, EVN ORDER BY Rang)
        FROM #Seq
    )
    UPDATE s SET Susp = 1
    FROM #Seq AS s JOIN l ON l.CountingId = s.CountingId AND l.EVN = s.EVN AND l.Rang = s.Rang
    WHERE l.Occ IS NOT NULL AND l.Occ = l.PrevOcc AND l.Net <> 0;

    ;WITH st AS (
        SELECT CountingId, EVN, n = COUNT(*),
               nNull = SUM(CASE WHEN Occ IS NULL THEN 1 ELSE 0 END),
               nNetNull = SUM(CASE WHEN Net IS NULL THEN 1 ELSE 0 END),
               nDist = COUNT(DISTINCT Occ),
               nSusp = SUM(CAST(Susp AS int))
        FROM #Seq GROUP BY CountingId, EVN
    ),
    isl AS (   -- plus longue suite d'arrêts consécutifs à occupation identique
        SELECT CountingId, EVN, run = COUNT(*)
        FROM (SELECT CountingId, EVN, Occ, grp = Rang - ROW_NUMBER() OVER (PARTITION BY CountingId, EVN, Occ ORDER BY Rang)
              FROM #Seq WHERE Occ IS NOT NULL) AS q
        GROUP BY CountingId, EVN, Occ, grp
    ),
    best AS (SELECT CountingId, EVN, Best = MAX(run) FROM isl GROUP BY CountingId, EVN),
    chain AS (  -- plus longue suite de répétitions suspectes consécutives
        SELECT CountingId, EVN, ch = MAX(c)
        FROM (SELECT CountingId, EVN, c = COUNT(*)
              FROM (SELECT CountingId, EVN, grp = Rang - ROW_NUMBER() OVER (PARTITION BY CountingId, EVN ORDER BY Rang)
                    FROM #Seq WHERE Susp = 1) AS q
              GROUP BY CountingId, EVN, grp) AS z
        GROUP BY CountingId, EVN
    )
    SELECT st.CountingId, st.EVN, st.n, st.nNull, st.nNetNull, st.nDist, st.nSusp,
           Best = CASE WHEN @prop = 0 THEN b.Best ELSE 1 + COALESCE(ch.ch, 0) END,
           Testable = CASE WHEN st.n >= @minArrets AND st.nNull = 0 AND (@prop = 0 OR st.nNetNull = 0) THEN 1 ELSE 0 END,
           Constante = CASE WHEN @prop = 0 THEN CASE WHEN st.nDist = 1 THEN 1 ELSE 0 END
                            ELSE CASE WHEN st.nSusp = st.n - 1 AND st.n > 1 THEN 1 ELSE 0 END END,
           [Status] = CAST(NULL AS varchar(12)), Reason = CAST(NULL AS varchar(60))
    INTO #Evn
    FROM st
    LEFT JOIN best AS b  ON b.CountingId  = st.CountingId AND b.EVN  = st.EVN
    LEFT JOIN chain AS ch ON ch.CountingId = st.CountingId AND ch.EVN = st.EVN;

    -- Statut de la séquence de chaque EVN
    UPDATE #Evn SET
        [Status] = CASE WHEN Testable = 0 THEN 'NOT_TESTED'
                        WHEN Best > @med OR Constante = 1 THEN 'FAIL'
                        WHEN Best > @low THEN 'WARNING' ELSE 'PASS' END,
        Reason   = CASE WHEN Testable = 0 THEN CASE WHEN n < @minArrets THEN 'SEQUENCE_TROP_COURTE'
                                                    WHEN nNull > 0 THEN 'EVN_OU_OCCUPATION_ABSENTE_A_UN_ARRET'
                                                    ELSE 'MONTEES_DESCENTES_ABSENTES' END
                        WHEN Best > @med OR Constante = 1 THEN 'OCCUPATION_REPETEE'
                        WHEN Best > @low THEN 'OCCUPATION_REPETEE_MODEREE' END;

    -- Une ligne par véhicule x arrêt, avec le statut de la séquence de l'EVN
    -- But : calculer le statut de chaque objet (PASS, WARNING, FAIL, NOT_TESTED) avec le motif, la valeur
    -- observée, la valeur attendue et les écarts.
    INSERT #R (GrainLevel, CountingId, Rang, VehIdx, [Status], FailureReason, ObservedValue, ExpectedValue, AbsoluteGap)
    SELECT 3, e.CountingId, e.Rang, e.VehIdx, v.[Status], v.Reason,
           (SELECT CASE WHEN v.Testable = 1 THEN v.Best END AS repetitions, v.n AS arrets_sequence FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
           CAST(@low AS nvarchar(100)),
           CASE WHEN v.Testable = 1 THEN CAST(v.Best AS decimal(19,6)) END
    FROM comptage_API.DQ_ArretEVN AS e
    JOIN #Evn AS v ON v.CountingId = e.CountingId AND v.EVN = e.EVN
    WHERE e.CirculationDate BETWEEN @DateDebut AND @DateFin;

    -- Train : pire statut de ses EVN
    ;WITH g AS (
        SELECT CountingId,
               sev = MAX(CASE [Status] WHEN 'FAIL' THEN 3 WHEN 'WARNING' THEN 2 WHEN 'PASS' THEN 1 ELSE 0 END),
               RepMax = MAX(CASE WHEN Testable = 1 THEN Best END),
               EvnFiges = SUM(CASE WHEN [Status] = 'FAIL' THEN 1 ELSE 0 END)
        FROM #Evn GROUP BY CountingId
    )
    INSERT #R (GrainLevel, CountingId, Rang, VehIdx, [Status], FailureReason, ObservedValue, ExpectedValue, AbsoluteGap)
    SELECT 1, t.CountingId, NULL, NULL,
           CASE g.sev WHEN 3 THEN 'FAIL' WHEN 2 THEN 'WARNING' WHEN 1 THEN 'PASS' ELSE 'NOT_TESTED' END,
           CASE WHEN g.sev = 3 THEN 'EVN_FIGE' WHEN g.sev = 2 THEN 'EVN_PARTIELLEMENT_FIGE'
                WHEN g.sev IS NULL OR g.sev = 0 THEN 'AUCUNE_SEQUENCE_TESTEE' END,
           (SELECT g.RepMax AS repetitions_max, g.EvnFiges AS evn_figes FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
           CAST(@low AS nvarchar(100)),
           CASE WHEN g.RepMax IS NOT NULL THEN CAST(g.RepMax AS decimal(19,6)) END
    FROM comptage_API.DQ_Train AS t
    LEFT JOIN g ON g.CountingId = t.CountingId
    WHERE t.CirculationDate BETWEEN @DateDebut AND @DateFin;

    -- But : écrire #R dans audit.LogsDQ ; les résultats précédents de la fenêtre passent à IsCurrent = 0.
    EXEC audit.usp_DQ_EcrireResultats @RegleDQID, @ExecutionId, @DateDebut, @DateFin;
END;
GO

/*==============================================================================
 ÉTAPE 21/27 - DQ-14 - Flux aux extrémités
 Source : sql/regles/DQ14_FluxExtremites.sql
 But : Procédure de la règle, appelée par l'orchestrateur. Lit son seuil dans
 le catalogue, calcule un statut par objet et écrit le résultat dans le
 journal. Le détail de la règle est dans l'en-tête ci-dessous.
===============================================================================*/

/*
================================================================================
 DQ-14 - Flux aux extrémités                                    Maille : Train
================================================================================
 part aux extrémités = (descentes à l'origine + montées au terminus) / total des flux x 100
   origine  = premier arrêt Start ; terminus = dernier arrêt End
   total    = Σ montées + Σ descentes des arrêts qui ont leurs DEUX flux (choix validé le 2026-11-11)
   PASS si descentes à l'origine = 0 ET montées au terminus = 0 ;
   WARNING si la part est non nulle et <= seuil (ThresholdLow = 0,02) ; FAIL au-delà.
   NOT_TESTED SEULEMENT si une extrémité ou son flux (descentes à l'origine / montées au terminus) est
   absent, ou si le total est nul. Le nombre d'arrêts sans flux est indiqué (la part est surévaluée
   quand des arrêts manquent).
 Point ouvert : rattachement des trains Dosto (split train, constat C27), à confirmer.
================================================================================
*/
CREATE OR ALTER PROCEDURE audit.usp_DQ_BR_DQ14_FluxExtremites
    @SourceName  nvarchar(50),
    @RegleDQID   int,
    @ExecutionId bigint,
    @DateDebut   date,
    @DateFin     date
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;

    -- But : lire dans le catalogue (audit.ReglesDQ) les seuils et paramètres de la règle.
    DECLARE @seuil decimal(19,6);
    SELECT @seuil = ThresholdLow FROM audit.ReglesDQ WHERE RegleDQID = @RegleDQID;

    -- But : table temporaire des résultats de la règle ; une ligne par objet testé, au grain voulu (1 Train, 2
    -- Arrêt, 3 Véhicule).
    CREATE TABLE #R (GrainLevel tinyint NOT NULL, CountingId bigint NOT NULL, Rang smallint NULL, VehIdx smallint NULL,
                     [Status] varchar(12) NOT NULL, FailureReason varchar(60) NULL, ObservedValue nvarchar(4000) NULL,
                     ExpectedValue nvarchar(100) NULL, AbsoluteGap decimal(19,6) NULL, RelativeGap decimal(19,6) NULL);

    ;WITH k AS (
        SELECT t.CountingId, StartRang = st.Rang, EndRang = en.Rang, D0 = st.Alighting, M1 = en.Boarding,
               Tot  = f.Tot, Sans = f.Sans
        FROM comptage_API.DQ_Train AS t
        OUTER APPLY (SELECT TOP (1) a.Rang, a.Alighting FROM comptage_API.DQ_Arret AS a
                     WHERE a.CountingId = t.CountingId AND a.StopType = 'Start' ORDER BY a.Rang ASC) AS st
        OUTER APPLY (SELECT TOP (1) a.Rang, a.Boarding FROM comptage_API.DQ_Arret AS a
                     WHERE a.CountingId = t.CountingId AND a.StopType = 'End' ORDER BY a.Rang DESC) AS en
        OUTER APPLY (SELECT Tot  = SUM(CASE WHEN a.Boarding IS NOT NULL AND a.Alighting IS NOT NULL
                                            THEN CAST(a.Boarding AS bigint) + a.Alighting END),
                            Sans = SUM(CASE WHEN a.Boarding IS NULL OR a.Alighting IS NULL THEN 1 ELSE 0 END)
                     FROM comptage_API.DQ_Arret AS a WHERE a.CountingId = t.CountingId) AS f
        WHERE t.CirculationDate BETWEEN @DateDebut AND @DateFin
    ),
    p AS (
        SELECT k.*, Teste = CASE WHEN k.StartRang IS NOT NULL AND k.EndRang IS NOT NULL AND k.D0 IS NOT NULL
                                  AND k.M1 IS NOT NULL AND k.Tot > 0 THEN 1 ELSE 0 END,
               Part = CASE WHEN k.Tot > 0 AND k.D0 IS NOT NULL AND k.M1 IS NOT NULL
                           THEN CAST(k.D0 + k.M1 AS decimal(19,6)) / k.Tot END
        FROM k
    )
    -- But : calculer le statut de chaque objet (PASS, WARNING, FAIL, NOT_TESTED) avec le motif, la valeur
    -- observée, la valeur attendue et les écarts.
    INSERT #R (GrainLevel, CountingId, Rang, VehIdx, [Status], FailureReason, ObservedValue, ExpectedValue, AbsoluteGap, RelativeGap)
    SELECT 1, p.CountingId, NULL, NULL,
           CASE WHEN p.Teste = 0 THEN 'NOT_TESTED'
                WHEN p.D0 = 0 AND p.M1 = 0 THEN 'PASS'
                WHEN p.Part <= @seuil THEN 'WARNING' ELSE 'FAIL' END,
           CASE WHEN p.StartRang IS NULL THEN 'PAS_D_ORIGINE'
                WHEN p.EndRang IS NULL THEN 'PAS_DE_TERMINUS'
                WHEN p.D0 IS NULL THEN 'DESCENTES_ORIGINE_ABSENTES'
                WHEN p.M1 IS NULL THEN 'MONTEES_TERMINUS_ABSENTES'
                WHEN p.Teste = 0 THEN 'TOTAL_FLUX_NUL'
                WHEN p.D0 = 0 AND p.M1 = 0 THEN NULL
                ELSE 'FLUX_AUX_EXTREMITES' END,
           (SELECT CASE WHEN p.Teste = 1 THEN CAST(p.Part * 100 AS decimal(9,2)) END AS part_pct,
                   p.D0 AS desc_origine, p.M1 AS mont_terminus, p.Sans AS arrets_sans_flux
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
           CASE WHEN p.Teste = 1 THEN CAST(@seuil AS nvarchar(100)) END,
           CASE WHEN p.Teste = 1 THEN CAST(p.D0 + p.M1 AS decimal(19,6)) END,
           CASE WHEN p.Teste = 1 THEN p.Part END
    FROM p;

    -- But : écrire #R dans audit.LogsDQ ; les résultats précédents de la fenêtre passent à IsCurrent = 0.
    EXEC audit.usp_DQ_EcrireResultats @RegleDQID, @ExecutionId, @DateDebut, @DateFin;
END;
GO

/*==============================================================================
 ÉTAPE 22/27 - Score, couverture, verdict et imputation
 Source : sql/08_score.sql
 But : Calcule, pour chaque train et chaque arrêt, un score pondéré, la
 couverture, le verdict et la recommandation d'imputation.
===============================================================================*/

/*
================================================================================
 08 - Score de confiance, verdict et décision d'imputation
================================================================================
 Équivalent SQL de src/score_engine.py. Paramètres dans audit.ParametresDQ (équivalent de
 config/score_config.json) et audit.ReglesDQ.ScoreWeight (poids par règle, 0 = exclue).
   valeur(règle) = points[statut]  (PASS 1, WARNING 0,5, FAIL 0)
   NOT_TESTED    : « exclu » (hors calcul), « fail » (0) ou « moitie » (0,5) selon not_tested
   score         = 100 x Σ poids x valeur / Σ poids des règles comptées
   couverture    = 100 x Σ poids des règles testées / Σ poids des règles applicables
   verdict       = Non évaluable si couverture < couverture_min, sinon Bonne / À surveiller / Mauvaise
   imputation    = Rien à imputer (tous les arrêts mesurés) | Imputer (arrêts manquants, verdict
                   imputable, part d'arrêts mesurés >= seuil) | Exclure (sinon)
 Niveaux : 1 = Train (règles applicables : toutes celles qui ont un résultat Train) ;
           2 = Arrêt (règles applicables : celles qui ont un résultat Arrêt : DQ-01, 02, 04, 05, 06, 10, 11, 12).
 Remarque d'arrondi : ROUND() de T-SQL arrondit les demi vers le haut ; le moteur Python arrondit au
 pair (round). Un écart de 0,1 point sur le score affiché est possible, il ne change jamais le
 verdict sauf si le score tombe exactement sur un seuil (voir la recette).
================================================================================
*/
-- But : calcule score, couverture, verdict et imputation à partir du journal courant et des
-- paramètres.
CREATE OR ALTER PROCEDURE audit.usp_DQ_CalculerScore
    @SourceName  nvarchar(50),
    @ExecutionId bigint,
    @DateDebut   date,
    @DateFin     date
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;

    -- ---- paramètres ----
    -- But : lire les paramètres du score (points par statut, seuils de verdict, couverture minimale, règle
    -- d'imputation).
    DECLARE @pPass decimal(9,4), @pWarn decimal(9,4), @pFail decimal(9,4), @nt varchar(10),
            @sBonne decimal(9,4), @sSurv decimal(9,4), @covMin decimal(9,4), @impPart decimal(9,4), @impVerdicts nvarchar(200);
    SELECT @pPass = MAX(CASE WHEN Cle = N'points_PASS'    THEN TRY_CONVERT(decimal(9,4), Valeur) END),
           @pWarn = MAX(CASE WHEN Cle = N'points_WARNING' THEN TRY_CONVERT(decimal(9,4), Valeur) END),
           @pFail = MAX(CASE WHEN Cle = N'points_FAIL'    THEN TRY_CONVERT(decimal(9,4), Valeur) END),
           @nt    = MAX(CASE WHEN Cle = N'not_tested'     THEN Valeur END),
           @sBonne = MAX(CASE WHEN Cle = N'seuil_bonne'        THEN TRY_CONVERT(decimal(9,4), Valeur) END),
           @sSurv  = MAX(CASE WHEN Cle = N'seuil_a_surveiller' THEN TRY_CONVERT(decimal(9,4), Valeur) END),
           @covMin = MAX(CASE WHEN Cle = N'couverture_min'     THEN TRY_CONVERT(decimal(9,4), Valeur) END),
           @impPart = MAX(CASE WHEN Cle = N'imputation_part_min_arrets_mesures' THEN TRY_CONVERT(decimal(9,4), Valeur) END),
           @impVerdicts = MAX(CASE WHEN Cle = N'imputation_verdicts_imputables' THEN Valeur END)
    FROM audit.ParametresDQ WHERE SourceName = @SourceName;
    -- But : refuser de calculer si un paramètre manque (erreur 50040).
    IF @pPass IS NULL OR @pWarn IS NULL OR @pFail IS NULL OR @nt IS NULL OR @sBonne IS NULL OR @sSurv IS NULL
       OR @covMin IS NULL OR @impPart IS NULL OR @impVerdicts IS NULL
        THROW 50040, N'Paramètres du score incomplets dans audit.ParametresDQ (voir 12_seed_catalogue.sql).', 1;
    DECLARE @ntPoints decimal(9,4) = CASE @nt WHEN 'fail' THEN @pFail WHEN 'moitie' THEN 0.5 END;   -- NULL si « exclu »

    -- ---- points par règle, pour les niveaux Train et Arrêt ----
    -- But : réunir, pour chaque train et chaque arrêt, le statut et le poids de chaque règle (poids 0 = règle
    -- hors score).
    CREATE TABLE #Pts (GrainLevel tinyint NOT NULL, CountingId bigint NOT NULL, Rang smallint NULL,
                       W decimal(9,4) NOT NULL, St varchar(12) NOT NULL);
    INSERT #Pts (GrainLevel, CountingId, Rang, W, St)
    SELECT 1, l.SourceKey, NULL, r.ScoreWeight, l.[Status]
    FROM audit.LogsDQ AS l
    JOIN audit.ReglesDQ AS r ON r.RegleDQID = l.RegleDQID AND r.SourceName = @SourceName AND r.ScoreWeight > 0
    WHERE l.ExecutionId = @ExecutionId AND l.GrainLevel = 1;

    INSERT #Pts (GrainLevel, CountingId, Rang, W, St)
    SELECT 2, l.SourceKey, a.Rang, r.ScoreWeight, l.[Status]
    FROM audit.LogsDQ AS l
    JOIN audit.ReglesDQ AS r ON r.RegleDQID = l.RegleDQID AND r.SourceName = @SourceName AND r.ScoreWeight > 0
    JOIN comptage_API.DQ_Arret AS a ON a.RunId = l.RunId
    WHERE l.ExecutionId = @ExecutionId AND l.GrainLevel = 2;

    -- But : agréger par objet : poids total, poids testé, poids non testé, points acquis.
    SELECT p.GrainLevel, p.CountingId, p.Rang,
           WTous   = SUM(p.W),
           WTestes = SUM(CASE WHEN p.St IN ('PASS', 'WARNING', 'FAIL') THEN p.W ELSE 0 END),
           WNt     = SUM(CASE WHEN p.St = 'NOT_TESTED' THEN p.W ELSE 0 END),
           Acc     = SUM(CASE p.St WHEN 'PASS' THEN p.W * @pPass WHEN 'WARNING' THEN p.W * @pWarn
                                   WHEN 'FAIL' THEN p.W * @pFail ELSE 0 END)
    INTO #Agg
    FROM #Pts AS p
    GROUP BY p.GrainLevel, p.CountingId, p.Rang;

    -- ---- score, couverture, verdict ----
    -- But : score = points acquis / poids compté, sur 100 ; couverture = part du poids réellement testée.
    SELECT g.GrainLevel, g.CountingId, g.Rang,
           Score = CASE WHEN c.WCompte > 0 THEN CAST(ROUND(100.0 * c.Acc / c.WCompte, 1) AS decimal(5,1)) END,
           Couverture = CASE WHEN g.WTous > 0 THEN CAST(ROUND(100.0 * g.WTestes / g.WTous, 1) AS decimal(5,1)) END
    INTO #Sc
    FROM #Agg AS g
    CROSS APPLY (SELECT WCompte = g.WTestes + CASE WHEN @ntPoints IS NULL THEN 0 ELSE g.WNt END,
                        Acc = g.Acc + CASE WHEN @ntPoints IS NULL THEN 0 ELSE g.WNt * @ntPoints END) AS c;

    -- But : écrire les scores dans une transaction ; les anciens scores de la fenêtre passent à IsCurrent = 0.
    BEGIN TRAN;

    UPDATE audit.ScoresDQ SET IsCurrent = 0
    WHERE SourceName = @SourceName AND IsCurrent = 1 AND WindowDate BETWEEN @DateDebut AND @DateFin;
    DELETE FROM audit.ScoresDQ WHERE ExecutionId = @ExecutionId AND SourceName = @SourceName;

    -- Niveau Train
    INSERT audit.ScoresDQ (ExecutionId, SourceName, GrainLevel, SourceKey, Rang, WindowDate, Score, Couverture, Verdict,
                           PartArretsMesures, Imputation, PositionManquants, ArretsAImputer, IsCurrent)
    SELECT @ExecutionId, @SourceName, 1, t.CountingId, NULL, t.CirculationDate, s.Score, s.Couverture, v.Verdict,
           CAST(x.Part AS decimal(5,1)), i.Imputation,
           CASE WHEN i.Imputation <> N'Rien à imputer' THEN m.Motif ELSE N'' END,
           CASE WHEN i.Imputation = N'Imputer' THEN LEFT(m.ArretsManquants, 1000) ELSE N'' END,
           1
    FROM comptage_API.DQ_Train AS t
    JOIN #Sc AS s ON s.GrainLevel = 1 AND s.CountingId = t.CountingId
    LEFT JOIN comptage_API.vw_DQ_TrainMotif AS m ON m.CountingId = t.CountingId
    CROSS APPLY (SELECT Verdict = CASE WHEN s.Score IS NULL OR s.Couverture IS NULL OR s.Couverture < @covMin THEN N'Non évaluable'
                                       WHEN s.Score >= @sBonne THEN N'Bonne'
                                       WHEN s.Score >= @sSurv THEN N'À surveiller'
                                       ELSE N'Mauvaise' END) AS v
    CROSS APPLY (SELECT Part = CASE WHEN t.NbStops > 0 THEN ROUND(100.0 * t.NbStopsObs / t.NbStops, 1) ELSE 0 END) AS x
    CROSS APPLY (SELECT Imputation = CASE WHEN t.NbStops > 0 AND t.NbStopsObs = t.NbStops THEN N'Rien à imputer'
                                          WHEN t.NbStops > 0 AND CHARINDEX(N',' + v.Verdict + N',', N',' + @impVerdicts + N',') > 0
                                               AND 100.0 * t.NbStopsObs / t.NbStops >= @impPart THEN N'Imputer'
                                          ELSE N'Exclure' END) AS i
    WHERE t.CirculationDate BETWEEN @DateDebut AND @DateFin;

    -- Niveau Arrêt
    INSERT audit.ScoresDQ (ExecutionId, SourceName, GrainLevel, SourceKey, Rang, WindowDate, Score, Couverture, Verdict, IsCurrent)
    SELECT @ExecutionId, @SourceName, 2, a.CountingId, a.Rang, a.CirculationDate, s.Score, s.Couverture,
           CASE WHEN s.Score IS NULL OR s.Couverture IS NULL OR s.Couverture < @covMin THEN N'Non évaluable'
                WHEN s.Score >= @sBonne THEN N'Bonne'
                WHEN s.Score >= @sSurv THEN N'À surveiller'
                ELSE N'Mauvaise' END,
           1
    FROM comptage_API.DQ_Arret AS a
    JOIN #Sc AS s ON s.GrainLevel = 2 AND s.CountingId = a.CountingId AND s.Rang = a.Rang
    WHERE a.CirculationDate BETWEEN @DateDebut AND @DateFin;

    COMMIT;
END;
GO

/*==============================================================================
 ÉTAPE 23/27 - Tables du modèle en étoile (Power BI)
 Source : sql/09_tables_restitution.sql
 But : Crée les dimensions, les faits en columnstore et l'agrégat lus par
 Power BI, et charge les dimensions fixes.
===============================================================================*/

/*
================================================================================
 09 - Modèle de restitution (schéma comptage_API, préfixe DQ_) : étoile + agrégats, prêt pour Power BI
================================================================================
 Alternative au cube SSAS (absent) : tables matérialisées à chaque exécution, index columnstore
 clustered sur les faits, clés entières, une colonne de date de circulation sur chaque table
 de faits (actualisation incrémentielle Power BI, purge et partitionnement futurs).

   DimDate, DimStatut, DimGrain, DimRegle, DimGare     dimensions conformes
   DimTrain          un train = une ligne (attributs, 14 statuts, score, verdict, imputation) :
                     sert de dimension ET de table de faits « score »
   FaitResultat      un résultat de règle sur un objet (Train, Arrêt, Véhicule) - format long
   FaitArret         un arrêt (complétude, heure, flux, score de l'arrêt)
================================================================================
*/
-- But : dimension date (un jour par ligne).
IF OBJECT_ID(N'comptage_API.DQ_DimDate', N'U') IS NULL
CREATE TABLE comptage_API.DQ_DimDate
(
    DateKey      int          NOT NULL CONSTRAINT PK_rpt_DimDate PRIMARY KEY,      -- AAAAMMJJ
    [Date]       date         NOT NULL,
    Annee        smallint     NOT NULL,
    Mois         tinyint      NOT NULL,
    NomMois      nvarchar(12) NOT NULL,
    AnneeMois    char(7)      NOT NULL,                                            -- AAAA-MM
    JourSemaine  tinyint      NOT NULL,                                            -- 1 = lundi
    NomJour      nvarchar(10) NOT NULL,
    EstWeekend   bit          NOT NULL
);
GO

-- But : dimension statut (PASS, WARNING, FAIL...) avec ordre, couleur et indicateur « testé ».
IF OBJECT_ID(N'comptage_API.DQ_DimStatut', N'U') IS NULL
CREATE TABLE comptage_API.DQ_DimStatut
(
    StatutKey   tinyint      NOT NULL CONSTRAINT PK_rpt_DimStatut PRIMARY KEY,
    Statut      varchar(12)  NOT NULL CONSTRAINT UQ_rpt_DimStatut UNIQUE,
    Ordre       tinyint      NOT NULL,
    EstTeste    bit          NOT NULL,       -- compte dans le dénominateur des taux « parmi les cas testés »
    EstEchec    bit          NOT NULL,       -- FAIL et CRITICAL
    CouleurHex  char(7)      NOT NULL
);
GO

-- But : dimension maille (Train, Arrêt, Véhicule).
IF OBJECT_ID(N'comptage_API.DQ_DimGrain', N'U') IS NULL
CREATE TABLE comptage_API.DQ_DimGrain
(
    GrainKey   tinyint      NOT NULL CONSTRAINT PK_rpt_DimGrain PRIMARY KEY,
    Grain      nvarchar(30) NOT NULL,
    Description nvarchar(200) NULL
);
GO

-- But : dimension règle (libellé, calcul, choix validés, poids).
IF OBJECT_ID(N'comptage_API.DQ_DimRegle', N'U') IS NULL
CREATE TABLE comptage_API.DQ_DimRegle
(
    RegleKey         int           NOT NULL CONSTRAINT PK_rpt_DimRegle PRIMARY KEY,     -- = audit.ReglesDQ.RegleDQID
    SourceName       nvarchar(50)  NOT NULL,
    RuleCode         nvarchar(20)  NOT NULL,
    RuleName         nvarchar(200) NOT NULL,
    Libelle          nvarchar(250) NOT NULL,                                            -- « DQ-03 Remise à zéro au terminus »
    Ordre            int           NOT NULL,
    Granularite      nvarchar(200) NULL,
    Calcul           nvarchar(max) NULL,
    ChoixValides     nvarchar(max) NULL,
    StatutValidation nvarchar(30)  NOT NULL,
    ScoreWeight      decimal(9,4)  NOT NULL,
    IsActive         bit           NOT NULL,
    RuleVersion      nvarchar(20)  NOT NULL
);
GO

-- But : dimension gare (nom le plus fréquent de chaque code).
IF OBJECT_ID(N'comptage_API.DQ_DimGare', N'U') IS NULL
CREATE TABLE comptage_API.DQ_DimGare
(
    StationCode    nvarchar(20)  NOT NULL CONSTRAINT PK_rpt_DimGare PRIMARY KEY,
    StationName    nvarchar(100) NOT NULL,          -- nom le plus fréquent du code (le nom n'est pas fiable, constat C03)
    NbNomsDistincts smallint     NOT NULL,
    Latitude       decimal(9,6)  NULL,              -- facultatif : config/stations_geoloc.csv (open data)
    Longitude      decimal(9,6)  NULL,
    Canton         nvarchar(50)  NULL,
    Commune        nvarchar(80)  NULL
);
GO

-- But : dimension large : un train, ses 14 statuts en colonnes, score, verdict, imputation.
IF OBJECT_ID(N'comptage_API.DQ_DimTrain', N'U') IS NULL
CREATE TABLE comptage_API.DQ_DimTrain
(
    CountingId        bigint        NOT NULL CONSTRAINT PK_rpt_DimTrain PRIMARY KEY,
    RunId             varchar(60)   NOT NULL,
    DateCirculation   date          NOT NULL,
    DateKey           int           NOT NULL,
    TrainNumber       nvarchar(20)  NOT NULL,
    Variant           nvarchar(20)  NULL,
    Ligne             nvarchar(30)  NOT NULL,         -- « Non renseigné » si absent
    TypeTrain         nvarchar(30)  NOT NULL,
    Serie             nvarchar(30)  NOT NULL,
    Origine           nvarchar(100) NOT NULL,
    Destination       nvarchar(100) NOT NULL,
    NbArrets          smallint      NOT NULL,
    NbArretsMesures   smallint      NOT NULL,
    MotifManquants    nvarchar(40)  NULL,             -- aucun | début | fin | trou | tout (combinaisons)
    ExtValides        nvarchar(15)  NOT NULL,         -- Oui | Non | Sans donnée (DQ-06)
    ToutVert          nvarchar(3)   NOT NULL,         -- Oui si DQ-06 = PASS
    Dq06Invalides     int           NULL,
    Dq12TauxPct       decimal(9,2)  NULL,
    DQ01 varchar(12) NULL, DQ02 varchar(12) NULL, DQ03 varchar(12) NULL, DQ04 varchar(12) NULL, DQ05 varchar(12) NULL,
    DQ06 varchar(12) NULL, DQ07 varchar(12) NULL, DQ08 varchar(12) NULL, DQ09 varchar(12) NULL, DQ10 varchar(12) NULL,
    DQ11 varchar(12) NULL, DQ12 varchar(12) NULL, DQ13 varchar(12) NULL, DQ14 varchar(12) NULL,
    NbFail            tinyint       NOT NULL,
    NbNotTested       tinyint       NOT NULL,
    Score             decimal(5,1)  NULL,
    Couverture        decimal(5,1)  NULL,
    TrancheScore      nvarchar(10)  NULL,             -- 0-10, 10-20 ... 90-100 (histogramme)
    Verdict           nvarchar(20)  NOT NULL,
    Imputation        nvarchar(20)  NOT NULL,
    PartArretsMesures decimal(5,1)  NULL,
    ArretsAImputer    nvarchar(1000) NULL,
    ExecutionId       bigint        NULL,             -- exécution du score
    MajUtc            datetime2(0)  NOT NULL CONSTRAINT DF_rpt_DimTrain_Maj DEFAULT (SYSUTCDATETIME())
);
GO
-- But : index de recherche des trains du modèle par date.
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_rpt_DimTrain_Date' AND object_id = OBJECT_ID(N'comptage_API.DQ_DimTrain'))
    CREATE NONCLUSTERED INDEX IX_rpt_DimTrain_Date ON comptage_API.DQ_DimTrain (DateCirculation) INCLUDE (Ligne, Verdict, Imputation);
GO

-- But : fait en columnstore : un résultat de règle sur un objet (détail et liste des échecs).
IF OBJECT_ID(N'comptage_API.DQ_FaitResultat', N'U') IS NULL
CREATE TABLE comptage_API.DQ_FaitResultat
(
    DateCirculation  date          NOT NULL,
    DateKey          int           NOT NULL,
    CountingId       bigint        NOT NULL,          -- -> DimTrain
    GrainKey         tinyint       NOT NULL,          -- -> DimGrain (1 Train, 2 Arrêt, 3 Véhicule)
    RegleKey         int           NOT NULL,          -- -> DimRegle
    StatutKey        tinyint       NOT NULL,          -- -> DimStatut
    Rang             smallint      NULL,
    EVN              nvarchar(20)  NULL,
    StationCode      nvarchar(20)  NULL,              -- -> DimGare (niveaux Arrêt et Véhicule)
    StopType         varchar(10)   NULL,
    SerieVehicule    nvarchar(30)  NULL,
    ExtValides       nvarchar(15)  NULL,              -- DQ-06 : Oui | Non | Sans donnée
    EcartAbsolu      decimal(19,6) NULL,
    EcartRelatif     decimal(19,6) NULL,
    MotifEchec       varchar(60)   NULL,
    ExecutionId      bigint        NOT NULL,
    LogDQID          bigint        NOT NULL
);
GO
-- But : index columnstore clusterisé du fait résultat.
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'CCI_rpt_FaitResultat' AND object_id = OBJECT_ID(N'comptage_API.DQ_FaitResultat'))
    CREATE CLUSTERED COLUMNSTORE INDEX CCI_rpt_FaitResultat ON comptage_API.DQ_FaitResultat;
GO

-- But : fait en columnstore : un arrêt avec ses mesures, son score et son verdict.
IF OBJECT_ID(N'comptage_API.DQ_FaitArret', N'U') IS NULL
CREATE TABLE comptage_API.DQ_FaitArret
(
    DateCirculation  date          NOT NULL,
    DateKey          int           NOT NULL,
    CountingId       bigint        NOT NULL,          -- -> DimTrain
    Rang             smallint      NOT NULL,
    StationCode      nvarchar(20)  NULL,              -- -> DimGare
    StopType         nvarchar(15)  NOT NULL,          -- Start | Stop | End | Non renseigné
    ArretMesure     bit           NOT NULL,          -- 1 = occupation lue (arrêt avec donnée)
    SansDonnee       bit           NOT NULL,
    Heure            tinyint       NULL,
    ExtValides       nvarchar(15)  NOT NULL,
    Occupation       int           NULL,
    Montees          int           NULL,
    Descentes        int           NULL,
    Capacite         int           NULL,
    CumulFlux        int           NULL,
    ScoreArret       decimal(5,1)  NULL,
    VerdictArret     nvarchar(20)  NULL,
    ExecutionId      bigint        NULL
);
GO
-- But : index columnstore clusterisé du fait arrêt.
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'CCI_rpt_FaitArret' AND object_id = OBJECT_ID(N'comptage_API.DQ_FaitArret'))
    CREATE CLUSTERED COLUMNSTORE INDEX CCI_rpt_FaitArret ON comptage_API.DQ_FaitArret;
GO

-- ---------------------------------------------------------------------------
-- Données de référence statiques
-- ---------------------------------------------------------------------------
-- But : alimenter comptage_API.DQ_DimStatut (MERGE : insère les lignes absentes, met à jour les autres
-- ; rejouable). dimension statut (PASS, WARNING, FAIL...) avec ordre, couleur et indicateur « testé ».
MERGE comptage_API.DQ_DimStatut AS t
USING (VALUES (1, 'PASS',       1, 1, 0, '#2E8B57'),
              (2, 'WARNING',    2, 1, 0, '#E3A008'),
              (3, 'FAIL',       3, 1, 1, '#C41039'),
              (4, 'CRITICAL',   4, 1, 1, '#7A0A22'),
              (5, 'NOT_TESTED', 5, 0, 0, '#B8B8BA'),
              (6, 'N/A',        6, 0, 0, '#D7D7D8'),
              (7, 'MEASURE',    7, 0, 0, '#58595B')) AS s (StatutKey, Statut, Ordre, EstTeste, EstEchec, CouleurHex)
ON t.StatutKey = s.StatutKey
WHEN MATCHED THEN UPDATE SET Statut = s.Statut, Ordre = s.Ordre, EstTeste = s.EstTeste, EstEchec = s.EstEchec, CouleurHex = s.CouleurHex
WHEN NOT MATCHED THEN INSERT (StatutKey, Statut, Ordre, EstTeste, EstEchec, CouleurHex)
     VALUES (s.StatutKey, s.Statut, s.Ordre, s.EstTeste, s.EstEchec, s.CouleurHex);
GO
-- But : alimenter comptage_API.DQ_DimGrain (MERGE : insère les lignes absentes, met à jour les autres
-- ; rejouable). dimension maille (Train, Arrêt, Véhicule).
MERGE comptage_API.DQ_DimGrain AS t
USING (VALUES (1, N'Train',    N'Une circulation (une ligne de la table source)'),
              (2, N'Arrêt',    N'Un arrêt du train (élément de StopsJson)'),
              (3, N'Véhicule', N'Un véhicule (EVN) à un arrêt')) AS s (GrainKey, Grain, Description)
ON t.GrainKey = s.GrainKey
WHEN MATCHED THEN UPDATE SET Grain = s.Grain, Description = s.Description
WHEN NOT MATCHED THEN INSERT (GrainKey, Grain, Description) VALUES (s.GrainKey, s.Grain, s.Description);
GO

/*==============================================================================
 ÉTAPE 24/27 - Rafraîchissement du modèle, contrôle et vues
 Source : sql/10_proc_restitution_et_vues.sql
 But : Reconstruit le modèle en étoile pour la fenêtre, le contrôle, les vues
 V1 (audit) et les vues lues par Power BI.
===============================================================================*/

/*
================================================================================
 10 - Rafraîchissement du modèle de restitution et vues
================================================================================
 comptage_API.usp_DQ_RafraichirModele : reconstruit, pour la FENETRE de dates, les tables DimTrain, FaitArret,
 FaitResultat à partir des résultats COURANTS (IsCurrent = 1) de audit.LogsDQ et
 audit.ScoresDQ. Les dimensions sont mises à jour par MERGE.
 Une seule transaction pour les tables de la fenêtre : Power BI voit l'ancien ou le nouvel état, jamais
 un état mélangé (activer READ_COMMITTED_SNAPSHOT sur la base, voir docs/06_industrialisation_v1/05).
================================================================================
*/
-- But : reconstruit le modèle en étoile pour la fenêtre : dimensions, DimTrain (14 statuts), faits et
-- agrégat.
CREATE OR ALTER PROCEDURE comptage_API.usp_DQ_RafraichirModele
    @SourceName  nvarchar(50),
    @DateDebut   date,
    @DateFin     date
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;

    -- ---------------- DimDate ----------------
    -- But : ajouter à la dimension date les jours manquants de la fenêtre.
    ;WITH n AS (
        SELECT TOP (DATEDIFF(DAY, @DateDebut, @DateFin) + 1)
               d = DATEADD(DAY, ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1, @DateDebut)
        FROM sys.all_columns AS a CROSS JOIN sys.all_columns AS b
    )
    INSERT comptage_API.DQ_DimDate (DateKey, [Date], Annee, Mois, NomMois, AnneeMois, JourSemaine, NomJour, EstWeekend)
    SELECT CONVERT(int, CONVERT(char(8), n.d, 112)), n.d, YEAR(n.d), MONTH(n.d),
           CHOOSE(MONTH(n.d), N'janvier', N'février', N'mars', N'avril', N'mai', N'juin', N'juillet', N'août',
                              N'septembre', N'octobre', N'novembre', N'décembre'),
           CONVERT(char(7), n.d, 23),
           CAST(DATEDIFF(DAY, '19000101', n.d) % 7 + 1 AS tinyint),                    -- 1900-01-01 est un lundi
           CHOOSE(DATEDIFF(DAY, '19000101', n.d) % 7 + 1, N'lundi', N'mardi', N'mercredi', N'jeudi', N'vendredi', N'samedi', N'dimanche'),
           CASE WHEN DATEDIFF(DAY, '19000101', n.d) % 7 >= 5 THEN 1 ELSE 0 END
    FROM n
    WHERE NOT EXISTS (SELECT 1 FROM comptage_API.DQ_DimDate AS x WHERE x.[Date] = n.d);

    -- ---------------- DimRegle ----------------
    MERGE comptage_API.DQ_DimRegle AS t
    USING (SELECT RegleDQID, SourceName, RuleCode, RuleName, SequenceOrder, [Description],
                  Granul = GrainName + COALESCE(N' + ' + (SELECT STRING_AGG(CAST(j.value AS nvarchar(100)), N' + ') FROM OPENJSON(DetailGrainsJson) AS j), N''),
                  ChoixValides, StatutValidation, ScoreWeight, IsActive, RuleVersion
           FROM audit.ReglesDQ WHERE SourceName = @SourceName) AS s
    ON t.RegleKey = s.RegleDQID
    WHEN MATCHED THEN UPDATE SET SourceName = s.SourceName, RuleCode = s.RuleCode, RuleName = s.RuleName,
         Libelle = s.RuleCode + N' ' + s.RuleName, Ordre = s.SequenceOrder,
         Granularite = s.Granul,
         Calcul = s.[Description], ChoixValides = s.ChoixValides, StatutValidation = s.StatutValidation,
         ScoreWeight = s.ScoreWeight, IsActive = s.IsActive, RuleVersion = s.RuleVersion
    WHEN NOT MATCHED THEN INSERT (RegleKey, SourceName, RuleCode, RuleName, Libelle, Ordre, Granularite, Calcul, ChoixValides,
                                  StatutValidation, ScoreWeight, IsActive, RuleVersion)
         VALUES (s.RegleDQID, s.SourceName, s.RuleCode, s.RuleName, s.RuleCode + N' ' + s.RuleName, s.SequenceOrder,
                 s.Granul, s.[Description], s.ChoixValides,
                 s.StatutValidation, s.ScoreWeight, s.IsActive, s.RuleVersion);

    -- ---------------- DimGare (nom le plus fréquent de chaque code) ----------------
    -- But : un nom par code gare, le plus fréquent (le nom d'une gare n'est pas fiable dans la source).
    ;WITH c AS (
        SELECT StationCode, StationName, n = COUNT(*),
               rn = ROW_NUMBER() OVER (PARTITION BY StationCode ORDER BY COUNT(*) DESC, StationName)
        FROM comptage_API.DQ_Arret WHERE StationCode IS NOT NULL AND StationName IS NOT NULL
        GROUP BY StationCode, StationName
    ),
    s AS (
        SELECT c.StationCode, StationName = MAX(CASE WHEN c.rn = 1 THEN c.StationName END), NbNoms = COUNT(*)
        FROM c GROUP BY c.StationCode
    )
    MERGE comptage_API.DQ_DimGare AS t
    USING s ON t.StationCode = s.StationCode
    WHEN MATCHED THEN UPDATE SET StationName = s.StationName, NbNomsDistincts = s.NbNoms
    WHEN NOT MATCHED THEN INSERT (StationCode, StationName, NbNomsDistincts) VALUES (s.StationCode, s.StationName, s.NbNoms);

    -- ---------------- Pivot des résultats courants au niveau Train ----------------
    -- But : pivot des résultats courants au niveau Train : une ligne par train, les 14 statuts en colonnes.
    SELECT l.SourceKey AS CountingId,
           DQ01 = MAX(CASE WHEN r.RuleCode = N'DQ-01' THEN l.[Status] END), DQ02 = MAX(CASE WHEN r.RuleCode = N'DQ-02' THEN l.[Status] END),
           DQ03 = MAX(CASE WHEN r.RuleCode = N'DQ-03' THEN l.[Status] END), DQ04 = MAX(CASE WHEN r.RuleCode = N'DQ-04' THEN l.[Status] END),
           DQ05 = MAX(CASE WHEN r.RuleCode = N'DQ-05' THEN l.[Status] END), DQ06 = MAX(CASE WHEN r.RuleCode = N'DQ-06' THEN l.[Status] END),
           DQ07 = MAX(CASE WHEN r.RuleCode = N'DQ-07' THEN l.[Status] END), DQ08 = MAX(CASE WHEN r.RuleCode = N'DQ-08' THEN l.[Status] END),
           DQ09 = MAX(CASE WHEN r.RuleCode = N'DQ-09' THEN l.[Status] END), DQ10 = MAX(CASE WHEN r.RuleCode = N'DQ-10' THEN l.[Status] END),
           DQ11 = MAX(CASE WHEN r.RuleCode = N'DQ-11' THEN l.[Status] END), DQ12 = MAX(CASE WHEN r.RuleCode = N'DQ-12' THEN l.[Status] END),
           DQ13 = MAX(CASE WHEN r.RuleCode = N'DQ-13' THEN l.[Status] END), DQ14 = MAX(CASE WHEN r.RuleCode = N'DQ-14' THEN l.[Status] END),
           ExtValides = MAX(CASE WHEN r.RuleCode = N'DQ-06' THEN JSON_VALUE(l.ObservedValue, '$.ext_valides') END),
           Dq06Invalides = MAX(CASE WHEN r.RuleCode = N'DQ-06' THEN TRY_CONVERT(int, JSON_VALUE(l.ObservedValue, '$.invalides')) END),
           Dq12Taux = MAX(CASE WHEN r.RuleCode = N'DQ-12' THEN TRY_CONVERT(decimal(9,2), JSON_VALUE(l.ObservedValue, '$.taux_pct')) END),
           NbFail = SUM(CASE WHEN l.[Status] IN ('FAIL', 'CRITICAL') THEN 1 ELSE 0 END),
           NbNotTested = SUM(CASE WHEN l.[Status] = 'NOT_TESTED' THEN 1 ELSE 0 END)
    INTO #PivotTrain
    FROM audit.LogsDQ AS l
    JOIN audit.ReglesDQ AS r ON r.RegleDQID = l.RegleDQID AND r.SourceName = @SourceName
    WHERE l.IsCurrent = 1 AND l.GrainLevel = 1 AND l.WindowDate BETWEEN @DateDebut AND @DateFin
    GROUP BY l.SourceKey;

    -- But : reconstruire les tables du modèle pour la fenêtre dans une transaction (suppression puis
    -- insertion).
    BEGIN TRAN;

    -- ---------------- DimTrain ----------------
    -- But : reconstruire DimTrain pour la fenêtre : un train par ligne avec ses statuts, score, verdict et
    -- imputation.
    DELETE FROM comptage_API.DQ_DimTrain WHERE DateCirculation BETWEEN @DateDebut AND @DateFin;
    INSERT comptage_API.DQ_DimTrain
        (CountingId, RunId, DateCirculation, DateKey, TrainNumber, Variant, Ligne, TypeTrain, Serie, Origine, Destination,
         NbArrets, NbArretsMesures, MotifManquants, ExtValides, ToutVert, Dq06Invalides, Dq12TauxPct,
         DQ01, DQ02, DQ03, DQ04, DQ05, DQ06, DQ07, DQ08, DQ09, DQ10, DQ11, DQ12, DQ13, DQ14,
         NbFail, NbNotTested, Score, Couverture, TrancheScore, Verdict, Imputation, PartArretsMesures, ArretsAImputer, ExecutionId)
    SELECT t.CountingId, t.RunId, t.CirculationDate, CONVERT(int, CONVERT(char(8), t.CirculationDate, 112)),
           t.TrainNumber, t.Variant,
           COALESCE(t.LineCode, N'Non renseigné'), COALESCE(t.TrainType, N'Non renseigné'), COALESCE(t.Series, N'Non renseigné'),
           COALESCE(t.DepartureStation, N'Non renseigné'), COALESCE(t.ArrivalStation, N'Non renseigné'),
           t.NbStops, t.NbStopsObs, sc.PositionManquants,
           COALESCE(p.ExtValides, N'Sans donnée'), CASE WHEN p.DQ06 = 'PASS' THEN N'Oui' ELSE N'Non' END,
           p.Dq06Invalides, p.Dq12Taux,
           p.DQ01, p.DQ02, p.DQ03, p.DQ04, p.DQ05, p.DQ06, p.DQ07, p.DQ08, p.DQ09, p.DQ10, p.DQ11, p.DQ12, p.DQ13, p.DQ14,
           COALESCE(p.NbFail, 0), COALESCE(p.NbNotTested, 0), sc.Score, sc.Couverture,
           CASE WHEN sc.Score IS NULL THEN NULL
                ELSE CONCAT(CASE WHEN sc.Score >= 90 THEN 90 ELSE CAST(FLOOR(sc.Score / 10) * 10 AS int) END, N'-',
                            CASE WHEN sc.Score >= 90 THEN 100 ELSE CAST(FLOOR(sc.Score / 10) * 10 AS int) + 10 END) END,
           COALESCE(sc.Verdict, N'Non évaluable'), COALESCE(sc.Imputation, N'Exclure'), sc.PartArretsMesures,
           NULLIF(sc.ArretsAImputer, N''), sc.ExecutionId
    FROM comptage_API.DQ_Train AS t
    LEFT JOIN #PivotTrain AS p ON p.CountingId = t.CountingId
    LEFT JOIN audit.ScoresDQ AS sc ON sc.SourceName = @SourceName AND sc.GrainLevel = 1 AND sc.IsCurrent = 1 AND sc.SourceKey = t.CountingId
    WHERE t.CirculationDate BETWEEN @DateDebut AND @DateFin;

    -- ---------------- FaitArret ----------------
    -- But : reconstruire FaitArret pour la fenêtre : un arrêt par ligne avec ses mesures, son score et son
    -- verdict.
    DELETE FROM comptage_API.DQ_FaitArret WHERE DateCirculation BETWEEN @DateDebut AND @DateFin;
    INSERT comptage_API.DQ_FaitArret
        (DateCirculation, DateKey, CountingId, Rang, StationCode, StopType, ArretMesure, SansDonnee, Heure, ExtValides,
         Occupation, Montees, Descentes, Capacite, CumulFlux, ScoreArret, VerdictArret, ExecutionId)
    SELECT a.CirculationDate, CONVERT(int, CONVERT(char(8), a.CirculationDate, 112)), a.CountingId, a.Rang, a.StationCode,
           COALESCE(a.StopType, N'Non renseigné'), a.HasData, 1 - a.HasData, a.Heure,
           COALESCE(JSON_VALUE(l6.ObservedValue, '$.ext_valides'), N'Sans donnée'),
           a.Occ, a.Boarding, a.Alighting, a.Capacity, a.CumulFlux, sc.Score, sc.Verdict, sc.ExecutionId
    FROM comptage_API.DQ_Arret AS a
    LEFT JOIN audit.ScoresDQ AS sc ON sc.SourceName = @SourceName AND sc.GrainLevel = 2 AND sc.IsCurrent = 1
                                  AND sc.SourceKey = a.CountingId AND sc.Rang = a.Rang
    OUTER APPLY (SELECT TOP (1) l.ObservedValue
                 FROM audit.LogsDQ AS l JOIN audit.ReglesDQ AS r ON r.RegleDQID = l.RegleDQID
                 WHERE r.SourceName = @SourceName AND r.RuleCode = N'DQ-06' AND l.IsCurrent = 1 AND l.GrainLevel = 2
                   AND l.RunId = a.RunId) AS l6
    WHERE a.CirculationDate BETWEEN @DateDebut AND @DateFin;

    -- ---------------- FaitResultat (format long, résultats courants) ----------------
    -- But : reconstruire FaitResultat pour la fenêtre : résultats courants du journal, insérés aux trois
    -- mailles (Train, Arrêt, Véhicule).
    DELETE FROM comptage_API.DQ_FaitResultat WHERE DateCirculation BETWEEN @DateDebut AND @DateFin;

    INSERT comptage_API.DQ_FaitResultat (DateCirculation, DateKey, CountingId, GrainKey, RegleKey, StatutKey, Rang, EVN, StationCode, StopType,
                             SerieVehicule, ExtValides, EcartAbsolu, EcartRelatif, MotifEchec, ExecutionId, LogDQID)
    SELECT l.WindowDate, CONVERT(int, CONVERT(char(8), l.WindowDate, 112)), l.SourceKey, 1, l.RegleDQID, s.StatutKey,
           NULL, NULL, NULL, NULL, NULL,
           CASE WHEN r.RuleCode = N'DQ-06' THEN JSON_VALUE(l.ObservedValue, '$.ext_valides') END,
           l.AbsoluteGap, l.RelativeGap, l.FailureReason, l.ExecutionId, l.LogDQID
    FROM audit.LogsDQ AS l
    JOIN audit.ReglesDQ AS r ON r.RegleDQID = l.RegleDQID AND r.SourceName = @SourceName
    JOIN comptage_API.DQ_DimStatut AS s ON s.Statut = l.[Status]
    WHERE l.IsCurrent = 1 AND l.GrainLevel = 1 AND l.WindowDate BETWEEN @DateDebut AND @DateFin;

    INSERT comptage_API.DQ_FaitResultat (DateCirculation, DateKey, CountingId, GrainKey, RegleKey, StatutKey, Rang, EVN, StationCode, StopType,
                             SerieVehicule, ExtValides, EcartAbsolu, EcartRelatif, MotifEchec, ExecutionId, LogDQID)
    SELECT l.WindowDate, CONVERT(int, CONVERT(char(8), l.WindowDate, 112)), l.SourceKey, 2, l.RegleDQID, s.StatutKey,
           a.Rang, NULL, a.StationCode, COALESCE(a.StopType, N'Non renseigné'), NULL,
           CASE WHEN r.RuleCode = N'DQ-06' THEN JSON_VALUE(l.ObservedValue, '$.ext_valides') END,
           l.AbsoluteGap, l.RelativeGap, l.FailureReason, l.ExecutionId, l.LogDQID
    FROM audit.LogsDQ AS l
    JOIN audit.ReglesDQ AS r ON r.RegleDQID = l.RegleDQID AND r.SourceName = @SourceName
    JOIN comptage_API.DQ_DimStatut AS s ON s.Statut = l.[Status]
    JOIN comptage_API.DQ_Arret AS a ON a.RunId = l.RunId
    WHERE l.IsCurrent = 1 AND l.GrainLevel = 2 AND l.WindowDate BETWEEN @DateDebut AND @DateFin;

    INSERT comptage_API.DQ_FaitResultat (DateCirculation, DateKey, CountingId, GrainKey, RegleKey, StatutKey, Rang, EVN, StationCode, StopType,
                             SerieVehicule, ExtValides, EcartAbsolu, EcartRelatif, MotifEchec, ExecutionId, LogDQID)
    SELECT l.WindowDate, CONVERT(int, CONVERT(char(8), l.WindowDate, 112)), l.SourceKey, 3, l.RegleDQID, s.StatutKey,
           e.Rang, e.EVN, a.StationCode, COALESCE(a.StopType, N'Non renseigné'), COALESCE(e.SerieVehicule, N'Non renseigné'),
           CASE WHEN r.RuleCode = N'DQ-06' THEN JSON_VALUE(l.ObservedValue, '$.ext_valides') END,
           l.AbsoluteGap, l.RelativeGap, l.FailureReason, l.ExecutionId, l.LogDQID
    FROM audit.LogsDQ AS l
    JOIN audit.ReglesDQ AS r ON r.RegleDQID = l.RegleDQID AND r.SourceName = @SourceName
    JOIN comptage_API.DQ_DimStatut AS s ON s.Statut = l.[Status]
    JOIN comptage_API.DQ_ArretEVN AS e ON e.RunId = l.RunId
    JOIN comptage_API.DQ_Arret AS a ON a.CountingId = e.CountingId AND a.Rang = e.Rang
    WHERE l.IsCurrent = 1 AND l.GrainLevel = 3 AND l.WindowDate BETWEEN @DateDebut AND @DateFin;

    COMMIT;
END;
GO

-- ===========================================================================
-- Contrôle du modèle (Sanity Check DWH) : le modèle correspond-il au parsing et au journal courant ?
--   erreur 50060 : nombre de trains du modèle <> nombre de trains parsés sur la fenêtre
--   erreur 50061 : nombre de résultats du modèle <> nombre de résultats courants du journal sur la fenêtre
-- ===========================================================================
-- But : contrôle de cohérence du modèle (trains et résultats) ; lève 50060 ou 50061 en cas d'écart.
CREATE OR ALTER PROCEDURE comptage_API.usp_DQ_ControlerModele
    @SourceName  nvarchar(50),
    @DateDebut   date,
    @DateFin     date
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @nTrain bigint, @nDim bigint, @nLog bigint, @nFait bigint, @msg nvarchar(500);
    -- But : comparer le nombre de trains parsés avec celui du modèle, et le nombre de résultats du journal
    -- avec celui du fait.
    SELECT @nTrain = COUNT_BIG(*) FROM comptage_API.DQ_Train WHERE CirculationDate BETWEEN @DateDebut AND @DateFin;
    SELECT @nDim   = COUNT_BIG(*) FROM comptage_API.DQ_DimTrain WHERE DateCirculation BETWEEN @DateDebut AND @DateFin;
    SELECT @nLog   = COUNT_BIG(*) FROM audit.LogsDQ AS l JOIN audit.ReglesDQ AS r ON r.RegleDQID = l.RegleDQID
                     WHERE r.SourceName = @SourceName AND l.IsCurrent = 1 AND l.WindowDate BETWEEN @DateDebut AND @DateFin;
    SELECT @nFait  = COUNT_BIG(*) FROM comptage_API.DQ_FaitResultat WHERE DateCirculation BETWEEN @DateDebut AND @DateFin;

    SELECT Controle = N'Trains', Attendu = @nTrain, Obtenu = @nDim, Resultat = CASE WHEN @nTrain = @nDim THEN 'OK' ELSE 'ECART' END
    UNION ALL
    SELECT N'Résultats', @nLog, @nFait, CASE WHEN @nLog = @nFait THEN 'OK' ELSE 'ECART' END;

    -- But : lever 50060 si le modèle n'a pas le bon nombre de trains.
    IF @nTrain <> @nDim
    BEGIN
        SET @msg = CONCAT(N'Modèle DWH : ', @nDim, N' trains au lieu de ', @nTrain, N' parsés sur la fenêtre.');
        THROW 50060, @msg, 1;
    END;
    -- But : lever 50061 si le modèle n'a pas le bon nombre de résultats.
    IF @nLog <> @nFait
    BEGIN
        SET @msg = CONCAT(N'Modèle DWH : ', @nFait, N' résultats au lieu de ', @nLog, N' dans le journal courant sur la fenêtre.');
        THROW 50061, @msg, 1;
    END;
END;
GO

-- ===========================================================================
-- Vue du journal enrichi (audit.*) : utilisée par la recette et les contrôles
-- ===========================================================================
-- But : vue : journal joint au catalogue et à l'exécution (utilisée par la recette et les contrôles).
CREATE OR ALTER VIEW audit.vw_DQ_LogsEnrichis
AS
SELECT l.LogDQID, l.ExecutionId, x.ExecutionDateTime, r.SourceName, l.RegleDQID, r.RuleCode, r.RuleName, r.GrainName,
       l.GrainLevel, GrainLevelLibelle = CASE l.GrainLevel WHEN 1 THEN N'Train' WHEN 2 THEN N'Arrêt' ELSE N'Véhicule' END,
       l.RunId, l.GrainValuesJson, l.[Status], l.FailureReason, l.ObservedValue, l.ExpectedValue, l.AbsoluteGap, l.RelativeGap,
       l.ErrorDescription, l.SourceKey, l.WindowDate, l.IsCurrent,
       StatutBinaire = CASE WHEN l.[Status] = 'PASS' THEN 0 ELSE 1 END,                 -- compatibilité DWH : PASS -> 0, autres -> 1
       EstTeste = CASE WHEN l.[Status] IN ('NOT_TESTED', 'N/A', 'MEASURE') THEN 0 ELSE 1 END
FROM audit.LogsDQ AS l
JOIN audit.ReglesDQ AS r ON r.RegleDQID = l.RegleDQID
JOIN audit.ExecutionsDQ AS x ON x.ExecutionId = l.ExecutionId;
GO

-- ===========================================================================
-- Droits de lecture de Power BI : tables listées uniquement (plus de vues de lecture, Power BI lit les tables)
-- ===========================================================================
GRANT SELECT ON comptage_API.DQ_DimDate    TO db_dq_lecteur;
GRANT SELECT ON comptage_API.DQ_DimStatut  TO db_dq_lecteur;
GRANT SELECT ON comptage_API.DQ_DimGrain   TO db_dq_lecteur;
GRANT SELECT ON comptage_API.DQ_DimRegle   TO db_dq_lecteur;
GRANT SELECT ON comptage_API.DQ_DimGare    TO db_dq_lecteur;
GRANT SELECT ON comptage_API.DQ_DimTrain   TO db_dq_lecteur;
GRANT SELECT ON comptage_API.DQ_FaitResultat TO db_dq_lecteur;
GRANT SELECT ON comptage_API.DQ_FaitArret  TO db_dq_lecteur;
GRANT SELECT ON audit.ExecutionsDQ         TO db_dq_lecteur;
GRANT SELECT ON audit.ExecutionsRegleDQ    TO db_dq_lecteur;
GRANT SELECT ON audit.ParametresDQ         TO db_dq_lecteur;
GRANT SELECT ON audit.ReglesDQ             TO db_dq_lecteur;
GO

-- ===========================================================================
-- Nettoyage d'une installation précédente (sans effet sur une base neuve) : objets retirés de la version réduite
-- ===========================================================================
IF EXISTS (SELECT 1 FROM sys.database_permissions WHERE class = 3 AND major_id = SCHEMA_ID(N'comptage_API')
           AND grantee_principal_id = DATABASE_PRINCIPAL_ID(N'db_dq_lecteur') AND permission_name = N'SELECT' AND state = 'G')
    REVOKE SELECT ON SCHEMA::comptage_API FROM db_dq_lecteur;
DROP VIEW IF EXISTS comptage_API.vw_DQ_DimDate, comptage_API.vw_DQ_DimStatut, comptage_API.vw_DQ_DimGrain, comptage_API.vw_DQ_DimRegle,
                    comptage_API.vw_DQ_DimGare, comptage_API.vw_DQ_DimTrain, comptage_API.vw_DQ_FaitResultat, comptage_API.vw_DQ_FaitArret,
                    comptage_API.vw_DQ_AggStatutRegle, comptage_API.vw_DQ_FaitResultatRecent, comptage_API.vw_DQ_FaitArretRecent,
                    comptage_API.vw_DQ_FaitExecution, comptage_API.vw_DQ_ParametresScore,
                    audit.vw_DQ_FailedRecords, audit.vw_DQ_RuleReport, audit.vw_DQ_HighLevelReport, audit.vw_ReglesDQ_DataGalaxy;
DROP TABLE IF EXISTS comptage_API.DQ_AggStatutRegle;
GO

/*==============================================================================
 ÉTAPE 25/27 - Pipeline complet (point d'entrée appelé après SSIS)
 Source : sql/11_pipeline.sql
 But : Une seule procédure enchaîne staging, contrôles, parsing, règles,
 score, modèle et clôture.
===============================================================================*/

/*
================================================================================
 11 - Pipeline complet : appelé UNE FOIS après le job SSIS qui alimente la table source
================================================================================
 EXEC audit.usp_DQ_Pipeline_SIV_APC @DateDebut = ?, @DateFin = ?;      -- dans une tâche « Exécuter une tâche SQL »

 Enchaînement (une seule exécution à la fois, verrou applicatif) :
   1. ouverture de l'exécution (ExecutionId)          audit.usp_DQ_OuvrirExecution
   2. staging de la fenêtre                           comptage_API.usp_DQ_ChargerStaging
   3. contrôles techniques (bloquants)                comptage_API.usp_DQ_ControlerStaging
   4. parsing JSON (Train, Arrêt, Véhicule)           comptage_API.usp_DQ_ParserStaging
   5. orchestrateur : toutes les règles actives       audit.usp_DQ_ExecuterRegles
   6. score, verdict, imputation                      audit.usp_DQ_CalculerScore
   7. rafraîchissement du modèle Power BI             comptage_API.usp_DQ_RafraichirModele
   8. clôture de l'exécution

 Erreur technique : l'exécution est clôturée en Echec (ou SuccesPartiel) et l'erreur est relancée, donc la tâche SSIS
 échoue. Non-conformité métier (FAIL) : journalisée, le pipeline réussit.
 Dates par défaut (si NULL) : J-n à J-1, n = ParametresDQ.fenetre_jours_defaut (3).
================================================================================
*/
-- But : POINT D'ENTRÉE appelé après SSIS : applock, staging, contrôles, parsing, règles, score,
-- modèle, clôture.
CREATE OR ALTER PROCEDURE audit.usp_DQ_Pipeline_SIV_APC
    @DateDebut       date   = NULL,
    @DateFin         date   = NULL,
    @SsisExecutionId bigint = NULL,
    @ExecutionId     bigint = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    DECLARE @src nvarchar(50) = N'SIV_APC', @lock int, @n int;

    -- But : fenêtre par défaut J-n à J-1 quand aucune date n'est fournie.
    IF @DateDebut IS NULL OR @DateFin IS NULL
    BEGIN
        SELECT @n = COALESCE(TRY_CONVERT(int, Valeur), 3) FROM audit.ParametresDQ WHERE SourceName = @src AND Cle = N'fenetre_jours_defaut';
        SET @n = COALESCE(@n, 3);
        SET @DateFin = COALESCE(@DateFin, CAST(DATEADD(DAY, -1, SYSDATETIME()) AS date));
        SET @DateDebut = COALESCE(@DateDebut, DATEADD(DAY, -(@n - 1), @DateFin));
    END;
    IF @DateFin < @DateDebut THROW 50051, N'@DateFin doit être >= @DateDebut.', 1;

    -- But : verrou applicatif : un seul pipeline à la fois (staging partagé).
    EXEC @lock = sys.sp_getapplock @Resource = N'DQ_SIV_APC', @LockMode = 'Exclusive', @LockOwner = 'Session', @LockTimeout = 0;
    IF @lock < 0 THROW 50050, N'Un autre pipeline DQ SIV_APC est déjà en cours.', 1;

    BEGIN TRY
        -- But : étape 1, ouvrir l'exécution (ExecutionId).
        EXEC audit.usp_DQ_OuvrirExecution @src, @DateDebut, @DateFin, @ExecutionId OUTPUT, @SsisExecutionId;

        -- But : étapes 2 à 4, staging de la fenêtre, contrôles techniques, parsing du JSON.
        EXEC comptage_API.usp_DQ_ChargerStaging @DateDebut, @DateFin;
        EXEC comptage_API.usp_DQ_ControlerStaging @ExecutionId;
        EXEC comptage_API.usp_DQ_ParserStaging @DateDebut, @DateFin, @ExecutionId;

        -- But : étape 5, lancer les règles actives (la clôture est faite ici, pas par l'orchestrateur).
        EXEC audit.usp_DQ_ExecuterRegles @SourceName = @src, @DateDebut = @DateDebut, @DateFin = @DateFin,
                                         @ExecutionId = @ExecutionId OUTPUT, @Cloturer = 0;

        -- But : étapes 6 et 7, score puis rafraîchissement du modèle Power BI.
        EXEC audit.usp_DQ_CalculerScore @src, @ExecutionId, @DateDebut, @DateFin;
        EXEC comptage_API.usp_DQ_RafraichirModele @src, @DateDebut, @DateFin;

        -- But : étape 8, clôturer en succès et libérer le verrou.
        EXEC audit.usp_DQ_CloreExecution @ExecutionId, 'Succes';
        EXEC sys.sp_releaseapplock @Resource = N'DQ_SIV_APC', @LockOwner = 'Session';
    END TRY
    -- But : erreur technique : clôturer l'exécution (Echec ou SuccesPartiel), libérer le verrou et relancer
    -- l'erreur pour faire échouer la tâche SSIS.
    BEGIN CATCH
        DECLARE @msg nvarchar(2000) = LEFT(ERROR_MESSAGE(), 2000), @num int = ERROR_NUMBER();
        IF XACT_STATE() <> 0 ROLLBACK TRAN;
        IF @ExecutionId IS NOT NULL
        BEGIN
            DECLARE @ok int = (SELECT COUNT(*) FROM audit.ExecutionsRegleDQ WHERE ExecutionId = @ExecutionId AND Statut = 'Succes');
            EXEC audit.usp_DQ_CloreExecution @ExecutionId, CASE WHEN @num = 50020 AND @ok > 0 THEN 'SuccesPartiel' ELSE 'Echec' END, @msg;
        END;
        EXEC sys.sp_releaseapplock @Resource = N'DQ_SIV_APC', @LockOwner = 'Session';
        THROW;
    END CATCH;
END;
GO

/*==============================================================================
 ÉTAPE 26/27 - Données de départ : catalogue des 14 règles et paramètres du score
 Source : sql/12_seed_catalogue.sql
 But : Insère ou met à jour (MERGE) les 14 règles avec leurs seuils et les
 paramètres du score.
===============================================================================*/

/*
================================================================================
 12 - Alimentation du catalogue des 14 règles (SIV_APC) et des paramètres du score
================================================================================
 Rejouable (MERGE sur SourceName + RuleCode). Les seuils sont des RATIOS (0,02 = 2 %), comme dans les exemples
 de la proposition V1. Les valeurs reprennent le moteur Python avec les décisions validées le 2026-11-11.
 Statut de validation : VALIDEE | PARTIELLE | A_TRANCHER | ATTEND_PO_SIV (voir 07_choix_a_trancher.md).
================================================================================
*/
DECLARE @g nvarchar(1000) = N'["TrainNumber","CirculationDate"]';

-- But : alimenter audit.ReglesDQ (MERGE : insère les lignes absentes, met à jour les autres ;
-- rejouable). catalogue des règles : code, procédure, ordre, seuils, activation, version, poids du
-- score. Piloté par les données, aucun redéploiement pour changer un seuil.
MERGE audit.ReglesDQ AS t
USING (VALUES
 (N'DQ-01', N'Cohérence flux / occupation', 10, N'Train', N'["Arrêt"]', N'audit.usp_DQ_BR_DQ01_CoherenceFluxOccupation',
  NULL, 0.02, NULL, N'ratio',
  N'PASS si l''écart entre l''occupation mesurée et l''occupation reconstruite est <= MAX(5 voyageurs ; 2 % de la reconstruite).',
  N'{"tolerance_abs":5}', N'VALIDEE',
  N'Écart = |occupation mesurée(n) - cumul(montées - descentes) de l''origine à n| ; seuil = MAX(5 ; 2 % x reconstruite). PASS si écart <= seuil, sinon FAIL. NOT_TESTED : arrêt sans donnée ou flux absent sur 1..n. Train = pire statut des arrêts.',
  N'Reconstruction CUMULEE depuis l''origine (validé le 2026-11-11, remplace la reconstruction locale depuis l''arrêt précédent). Origine = premier arrêt listé.'),
 (N'DQ-02', N'Complétude EVN', 20, N'Train', N'["Arrêt"]', N'audit.usp_DQ_BR_DQ02_CompletudeEVN',
  NULL, NULL, 9, N'nombre',
  N'PASS si le nombre d''EVN observés à l''arrêt égale le nombre d''EVN attendus et que l''attendu est compris entre 1 et 9.',
  NULL, N'ATTEND_PO_SIV',
  N'EVN observés à l''arrêt = nombre d''EVN de EuropeanVehicleNumbersJson et attendu <= 9 -> PASS ; sinon FAIL. Attendu inconnu (liste vide) ou > 9 -> FAIL. Arrêt sans donnée -> NOT_TESTED.',
  N'En attente du PO SIV : origine de EuropeanVehicleNumbersJson (composition ARAMIS ?). Comparaison des identités des véhicules prévue en V2.'),
 (N'DQ-03', N'Remise à zéro au terminus', 30, N'Train', NULL, N'audit.usp_DQ_BR_DQ03_RemiseZeroTerminus',
  0.02, NULL, NULL, N'ratio',
  N'Taux résiduel = |occupation au terminus - descentes| / capacité ; PASS si <= 2 %.',
  NULL, N'VALIDEE',
  N'Taux résiduel = |occupation au terminus - descentes au terminus| / capacité au terminus. PASS si <= 2 %, FAIL sinon. Terminus = arrêt stopType End. Pas de donnée au End ou pas de End -> NOT_TESTED.',
  N'Occupation du terminus mesurée AVANT les descentes (confirmé le 2026-11-11, constat C30).'),
 (N'DQ-04', N'Charge critique', 40, N'Train', N'["Arrêt","Véhicule"]', N'audit.usp_DQ_BR_DQ04_ChargeCritiqueEVN',
  2.00, 2.50, NULL, N'ratio',
  N'Taux de charge = occupation / capacité. PASS <= 200 % ; WARNING <= 250 % ; FAIL au-delà.',
  NULL, N'VALIDEE',
  N'Taux de charge = occupation / capacité. PASS <= 200 % ; WARNING 200-250 % ; FAIL > 250 %. Capacité nulle ou absente : NOT_TESTED si occupation 0, FAIL si occupation > 0. Occupation absente -> NOT_TESTED. Train = pire statut du détail train, arrêts et véhicules.',
  N'Capacité nulle avec occupation 0 -> NOT_TESTED (validé le 2026-11-11, option A). Capacité : véhicule = sensorCapacity, arrêt = capacity, train = TotalCapacity.'),
 (N'DQ-05', N'État du matériel', 50, N'Train', N'["Arrêt","Véhicule"]', N'audit.usp_DQ_BR_DQ05_EtatMateriel',
  NULL, NULL, NULL, NULL,
  N'FAIL si l''état dégradé est vrai, PASS sinon.',
  NULL, N'VALIDEE',
  N'État = 1 si dégradé -> FAIL ; 0 si conforme -> PASS. Train = IsDegraded ; arrêt = isDegraded de l''arrêt ; EVN hérite de son arrêt. Flag absent -> NOT_TESTED.',
  N'Le sens de « dégradé » reste à demander à l''exploitant.'),
 (N'DQ-06', N'Disponibilité des capteurs', 60, N'Train', N'["Arrêt","Véhicule"]', N'audit.usp_DQ_BR_DQ06_DisponibiliteCapteurs',
  0, 1, NULL, N'capteurs invalides',
  N'0 capteur invalide -> PASS ; 1 -> WARNING ; 2 ou plus -> FAIL.',
  N'{"variante":"ACTUELLE"}', N'A_TRANCHER',
  N'Capteurs invalides = capteurs attendus - capteurs valides (valide = 100 %). 0 -> PASS ; 1 -> WARNING ; plus de 1 -> FAIL ; aucune donnée -> NOT_TESTED. Variante ACTUELLE : 1 EVN = 2 capteurs (extérieur + intérieur), un capteur sans valeur est invalide.',
  N'A TRANCHER : variante EXTERIEUR_SEUL proposée (capteurs extérieurs seulement, capteur sans valeur = NOT_TESTED). Statut de H5 (extérieur à 0 % de bout en bout) à décider.'),
 (N'DQ-07', N'Complétude de la séquence d''arrêts', 70, N'Train', NULL, N'audit.usp_DQ_BR_DQ07_SequenceArrets',
  NULL, NULL, NULL, NULL,
  N'PASS si tous les arrêts attendus ont une occupation mesurée.',
  NULL, N'PARTIELLE',
  N'Arrêts observés = arrêts attendus -> PASS ; sinon FAIL. Arrêts attendus = nombre d''éléments de StopsJson ; arrêt observé = arrêt avec occupation. Aucun arrêt -> NOT_TESTED.',
  N'Validé sur un seul cas à l''atelier ; cas 2 à 6 et hypothèses à repasser (en particulier arrêt non desservi compté manquant).'),
 (N'DQ-08', N'Équilibre des flux', 80, N'Train', NULL, N'audit.usp_DQ_BR_DQ08_EquilibreFlux',
  0.05, NULL, NULL, N'ratio',
  N'FAIL si l''écart global ET l''écart intermédiaire entre montées et descentes dépassent 5 %.',
  N'{"variante":"ACTUELLE"}', N'A_TRANCHER',
  N'Écart global = |Σ montées - Σ descentes| / Σ montées ; écart intermédiaire idem sur les arrêts hors premier et dernier. FAIL si les deux > 5 %, PASS sinon. Un flux absent sur le trajet ou dénominateur nul -> NOT_TESTED.',
  N'A TRANCHER : variante INTERMEDIAIRES_SI_EXTREMITE_VIDE proposée (extrémités sans flux ou à 0 -> on ne regarde que les arrêts intermédiaires).'),
 (N'DQ-09', N'Remise à zéro à l''origine', 90, N'Train', NULL, N'audit.usp_DQ_BR_DQ09_RemiseZeroOrigine',
  0.02, NULL, NULL, N'ratio',
  N'FAIL si occupation 0 avec des montées, ou écart |occupation - montées| / capacité > 2 %.',
  NULL, N'VALIDEE',
  N'Écart origine = |occupation à l''origine - montées à l''origine|. FAIL si occupation = 0 avec montées > 0, ou écart > 2 % de la capacité ; PASS sinon. Origine = arrêt Start ; pas de donnée -> NOT_TESTED.',
  N'Dénominateur de 2 % = capacité à l''origine ; capacité nulle -> NOT_TESTED (validé).'),
 (N'DQ-10', N'Occupation reconstruite non négative', 100, N'Train', N'["Arrêt"]', N'audit.usp_DQ_BR_DQ10_OccupationNonNegative',
  0, -3, NULL, N'voyageurs',
  N'Cumul(montées - descentes) >= 0 -> PASS ; >= -3 -> WARNING ; en dessous -> FAIL.',
  NULL, N'VALIDEE',
  N'Cumul(n) = Σ montées - Σ descentes jusqu''à n. Train : minimum du cumul. PASS >= 0 ; WARNING entre -3 et 0 ; FAIL < -3. Un arrêt sans flux sur le trajet -> NOT_TESTED.',
  N'Départ du cumul au premier arrêt listé (validé).'),
 (N'DQ-11', N'Cohérence entre les mailles', 110, N'Train', N'["Arrêt"]', N'audit.usp_DQ_BR_DQ11_CoherenceMailles',
  0.01, 0.05, NULL, N'ratio',
  N'Écart relatif arrêt / somme des véhicules (occupation, montées, descentes) : PASS <= 1 % ; WARNING <= 5 % ; FAIL au-delà.',
  NULL, N'PARTIELLE',
  N'Écart relatif = |A - B| / MAX(|A| ; |B|) entre l''arrêt et la somme de ses véhicules (on garde le pire des trois mesures). PASS <= 1 % ; WARNING 1-5 % ; FAIL > 5 %. Vue incomplète -> NOT_TESTED. Train = pire statut des arrêts.',
  N'Hypothèses H2 (flux EVN = 1re + 2e classe) et H3 (écart toujours 0) sans réponse ; règle gardable à poids 0 si les valeurs d''arrêt sont des sommes des véhicules.'),
 (N'DQ-12', N'Valeurs exploitables', 120, N'Train', N'["Arrêt","Véhicule"]', N'audit.usp_DQ_BR_DQ12_ValeursExploitables',
  0.98, 1.00, NULL, N'ratio',
  N'Taux de valeurs lues : PASS = 100 % ; WARNING >= 98 % ; FAIL en dessous.',
  NULL, N'VALIDEE',
  N'Taux exploitable = 1 - (valeurs absentes + illisibles) / valeurs attendues. PASS = 100 % ; WARNING 98-100 % ; FAIL < 98 %. Les vrais zéros sont exploitables. Train : 3 valeurs du train + 4 valeurs de chaque arrêt AVEC donnée.',
  N'Calcul au niveau Train sur les arrêts qui ont une donnée seulement (validé le 2026-11-11) : les arrêts muets sont signalés par DQ-07.'),
 (N'DQ-13', N'Capteur figé', 130, N'Train', N'["Véhicule"]', N'audit.usp_DQ_BR_DQ13_CapteurFige',
  3, 5, 6, N'répétitions',
  N'Plus longue suite d''arrêts consécutifs à occupation identique : PASS <= 3 ; WARNING 4-5 ; FAIL >= 6 ou occupation constante.',
  N'{"variante":"ACTUELLE","min_arrets":5}', N'A_TRANCHER',
  N'Répétitions = plus longue suite d''arrêts consécutifs où un EVN a la même occupation. PASS <= 3 sans occupation constante ; WARNING 4 ou 5 ; FAIL >= 6 ou constante sur au moins 5 arrêts. NOT_TESTED : séquence incomplète ou moins de 5 arrêts. Train = pire statut des EVN.',
  N'A TRANCHER : variante MOUVEMENT_NET proposée (une répétition n''est suspecte que si l''EVN a un mouvement net aux arrêts). Règlerait le constat C28 (zéros répétés).'),
 (N'DQ-14', N'Flux aux extrémités', 140, N'Train', NULL, N'audit.usp_DQ_BR_DQ14_FluxExtremites',
  0.02, NULL, NULL, N'ratio',
  N'Part = (descentes à l''origine + montées au terminus) / total des flux : PASS si les deux sont nuls ; WARNING <= 2 % ; FAIL au-delà.',
  NULL, N'VALIDEE',
  N'Part aux extrémités = (descentes à l''origine + montées au terminus) / total des flux x 100. PASS si les deux sont nuls ; WARNING si part <= 2 % ; FAIL si > 2 %. NOT_TESTED seulement si une extrémité ou son flux manque ou si le total est nul.',
  N'NOT_TESTED seulement si une extrémité manque ; total des flux = arrêts qui ont leurs flux (validé le 2026-11-11). Rattachement Dosto (constat C27) à confirmer.')
) AS s (RuleCode, RuleName, SequenceOrder, GrainName, DetailGrainsJson, StoredProc,
        ThresholdLow, ThresholdMedium, ThresholdHigh, ThresholdUnit, ThresholdDescription,
        ParamsJson, StatutValidation, [Description], ChoixValides)
ON t.SourceName = N'SIV_APC' AND t.RuleCode = s.RuleCode
WHEN MATCHED THEN UPDATE SET
     RuleName = s.RuleName, SequenceOrder = s.SequenceOrder, GrainName = s.GrainName, GrainDefinitionJson = @g,
     DetailGrainsJson = s.DetailGrainsJson, StoredProc = s.StoredProc,
     ThresholdLow = s.ThresholdLow, ThresholdMedium = s.ThresholdMedium, ThresholdHigh = s.ThresholdHigh,
     ThresholdUnit = s.ThresholdUnit, ThresholdDescription = s.ThresholdDescription,
     [Description] = s.[Description], ChoixValides = s.ChoixValides, StatutValidation = s.StatutValidation
WHEN NOT MATCHED THEN INSERT
     (SourceName, RuleCode, RuleName, SequenceOrder, GrainName, GrainDefinitionJson, DetailGrainsJson, StoredProc,
      ThresholdLow, ThresholdMedium, ThresholdHigh, ThresholdUnit, ThresholdDescription, ParamsJson, StatutValidation,
      [Description], ChoixValides, IsActive, ScoreWeight)
     VALUES (N'SIV_APC', s.RuleCode, s.RuleName, s.SequenceOrder, s.GrainName, @g, s.DetailGrainsJson, s.StoredProc,
      s.ThresholdLow, s.ThresholdMedium, s.ThresholdHigh, s.ThresholdUnit, s.ThresholdDescription, s.ParamsJson, s.StatutValidation,
      s.[Description], s.ChoixValides, 1, 1);
-- Remarque : ParamsJson n'est PAS écrasé à la mise à jour (la variante choisie par le métier est conservée).
GO

-- But : alimenter audit.ParametresDQ (MERGE : insère les lignes absentes, met à jour les autres ;
-- rejouable). paramètres du score et de l'exploitation (points par statut, seuils de verdict, fenêtre
-- par défaut, rétention).
MERGE audit.ParametresDQ AS t
USING (VALUES
 (N'points_PASS',    N'1',   N'Valeur du statut PASS dans le score (1 = 100 %)'),
 (N'points_WARNING', N'0.5', N'Valeur du statut WARNING dans le score'),
 (N'points_FAIL',    N'0',   N'Valeur du statut FAIL dans le score'),
 (N'not_tested',     N'exclu', N'Traitement des règles non testables : exclu | fail | moitie'),
 (N'seuil_bonne',    N'80',  N'Score minimal pour le verdict Bonne'),
 (N'seuil_a_surveiller', N'60', N'Score minimal pour À surveiller ; en dessous : Mauvaise'),
 (N'couverture_min', N'50',  N'En dessous de cette couverture (en %) : Non évaluable'),
 (N'imputation_part_min_arrets_mesures', N'50', N'Part minimale (en %) d''arrêts mesurés pour recommander d''imputer'),
 (N'imputation_verdicts_imputables', N'Bonne,À surveiller', N'Verdicts pour lesquels on recommande d''imputer'),
 (N'fenetre_jours_defaut', N'3', N'Fenêtre par défaut du pipeline : J-n à J-1'),
 (N'retention_jours_historique', N'90', N'Conservation des résultats non courants (audit.usp_DQ_Purger)')
) AS s (Cle, Valeur, [Description])
ON t.SourceName = N'SIV_APC' AND t.Cle = s.Cle
WHEN NOT MATCHED THEN INSERT (SourceName, Cle, Valeur, [Description]) VALUES (N'SIV_APC', s.Cle, s.Valeur, s.[Description]);
-- Les paramètres existants ne sont pas écrasés (paramètres PROVISOIRES, poids égaux en attendant les poids métier).
GO

/*==============================================================================
 ÉTAPE 27/27 - Purge et maintenance
 Source : sql/13_maintenance.sql
 But : Purge l'historique ancien et maintient les index columnstore et les
 statistiques.
===============================================================================*/

/*
================================================================================
 13 - Maintenance : purge de l'historique, compression columnstore, statistiques
================================================================================
 A planifier dans un travail SQL Server Agent hebdomadaire (voir docs/06_industrialisation_v1/04).
 A faire une fois sur la base : ALTER DATABASE CFL_GOV SET READ_COMMITTED_SNAPSHOT ON;
 (lecture Power BI sans blocage pendant le rafraîchissement du modèle ; à valider avec l'équipe DWH).
================================================================================
*/
-- But : supprime les résultats non courants des exécutions plus vieilles que la rétention (les
-- résultats courants ne sont jamais purgés).
CREATE OR ALTER PROCEDURE audit.usp_DQ_Purger
    @SourceName     nvarchar(50),
    @JoursHistorique int = NULL          -- NULL : paramètre retention_jours_historique (90)
AS
BEGIN
    SET NOCOUNT ON;
    IF @JoursHistorique IS NULL
        SELECT @JoursHistorique = COALESCE(TRY_CONVERT(int, Valeur), 90)
        FROM audit.ParametresDQ WHERE SourceName = @SourceName AND Cle = N'retention_jours_historique';
    SET @JoursHistorique = COALESCE(@JoursHistorique, 90);

    -- But : date limite de conservation (paramètre de rétention, 90 jours par défaut).
    DECLARE @limite datetime2(0) = DATEADD(DAY, -@JoursHistorique, SYSUTCDATETIME()), @n int = 1;

    -- Résultats NON courants des exécutions anciennes (les résultats courants ne sont jamais purgés)
    -- But : supprimer par lots de 200 000 les résultats non courants des vieilles exécutions.
    WHILE @n > 0
    BEGIN
        DELETE TOP (200000) l
        FROM audit.LogsDQ AS l
        JOIN audit.ExecutionsDQ AS x ON x.ExecutionId = l.ExecutionId
        WHERE l.IsCurrent = 0 AND x.SourceName = @SourceName AND x.ExecutionDateTime < @limite;
        SET @n = @@ROWCOUNT;
    END;
    -- But : supprimer les anciens scores non courants.
    DELETE s FROM audit.ScoresDQ AS s
    JOIN audit.ExecutionsDQ AS x ON x.ExecutionId = s.ExecutionId
    WHERE s.IsCurrent = 0 AND x.SourceName = @SourceName AND x.ExecutionDateTime < @limite;

    -- But : supprimer les anciens contrôles techniques.
    DELETE c FROM audit.ControlesTechniquesDQ AS c WHERE c.CreatedAt < @limite
        AND c.ExecutionId IN (SELECT ExecutionId FROM audit.ExecutionsDQ WHERE SourceName = @SourceName);
END;
GO

-- But : ferme les groupes de lignes columnstore et met à jour les statistiques.
CREATE OR ALTER PROCEDURE audit.usp_DQ_Maintenance
AS
BEGIN
    SET NOCOUNT ON;
    -- Fermeture des groupes de lignes ouverts (deltastore) et compression
    -- But : compresser les groupes de lignes ouverts des index columnstore.
    ALTER INDEX CCI_LogsDQ ON audit.LogsDQ REORGANIZE WITH (COMPRESS_ALL_ROW_GROUPS = ON);
    ALTER INDEX CCI_ScoresDQ ON audit.ScoresDQ REORGANIZE WITH (COMPRESS_ALL_ROW_GROUPS = ON);
    ALTER INDEX CCI_rpt_FaitResultat ON comptage_API.DQ_FaitResultat REORGANIZE WITH (COMPRESS_ALL_ROW_GROUPS = ON);
    ALTER INDEX CCI_rpt_FaitArret ON comptage_API.DQ_FaitArret REORGANIZE WITH (COMPRESS_ALL_ROW_GROUPS = ON);
    -- But : mettre à jour les statistiques des tables de parsing.
    UPDATE STATISTICS comptage_API.DQ_Train WITH FULLSCAN;
    UPDATE STATISTICS comptage_API.DQ_Arret WITH FULLSCAN;
    UPDATE STATISTICS comptage_API.DQ_ArretEVN WITH FULLSCAN;
END;
GO

/*==============================================================================
 ANNEXE A - Recette (comparaison aux chiffres de référence du moteur Python)
 Source : sql/tests/recette_chiffres_cles.sql
 À exécuter après un premier pipeline sur le jeu de référence. Lignes commentées : décommenter pour jouer.
===============================================================================*/

-- /*
-- ================================================================================
--  Recette : compare les résultats SQL aux chiffres de référence du moteur Python
-- ================================================================================
--  Chiffres de référence : sorties de src/dq_engine.py et src/score_engine.py avec les décisions validées le
--  2026-11-11 (PR #12), sur l'extraction d'août 2026 (5 000 trains, 4 au 26 août). A utiliser UNIQUEMENT :
--    - avec ce jeu de données chargé dans la table source ;
--    - avec les variantes par défaut (ParamsJson.variante = ACTUELLE pour DQ-06, DQ-08, DQ-13) ;
--    - après un pipeline sur toute la période : EXEC audit.usp_DQ_Pipeline_SIV_APC '2026-08-04', '2026-08-26';
--  Lecture : un écart (Resultat = 'ECART') est à expliquer avant la mise en service. Les écarts de score affichés
--  de 0,1 point (arrondi) ne sont pas testés ici ; les verdicts et décisions d'imputation le sont.
--  Après la recette : re-exécuter le pipeline sur la même fenêtre et vérifier que les comptes courants sont identiques
--  (rejouabilité), puis que audit.LogsDQ garde l'historique (IsCurrent = 0 pour l'ancienne exécution).
-- ================================================================================
-- */
-- USE CFL_GOV;
-- GO
--
-- DECLARE @ExecutionId bigint = (SELECT MAX(ExecutionId) FROM audit.ExecutionsDQ WHERE SourceName = N'SIV_APC' AND Statut = 'Succes');
-- PRINT CONCAT(N'Exécution contrôlée : ', @ExecutionId);
--
-- CREATE TABLE #AttenduRegle (GrainLevel tinyint NOT NULL, RuleCode nvarchar(20) NOT NULL, [Status] varchar(12) NOT NULL, Attendu bigint NOT NULL);
-- INSERT #AttenduRegle VALUES
--     (1, N'DQ-01', 'PASS', 1029),
--     (1, N'DQ-01', 'WARNING', 0),
--     (1, N'DQ-01', 'FAIL', 2047),
--     (1, N'DQ-01', 'NOT_TESTED', 1924),
--     (1, N'DQ-02', 'PASS', 4517),
--     (1, N'DQ-02', 'WARNING', 0),
--     (1, N'DQ-02', 'FAIL', 483),
--     (1, N'DQ-02', 'NOT_TESTED', 0),
--     (1, N'DQ-03', 'PASS', 1173),
--     (1, N'DQ-03', 'WARNING', 0),
--     (1, N'DQ-03', 'FAIL', 1183),
--     (1, N'DQ-03', 'NOT_TESTED', 2644),
--     (1, N'DQ-04', 'PASS', 4996),
--     (1, N'DQ-04', 'WARNING', 3),
--     (1, N'DQ-04', 'FAIL', 0),
--     (1, N'DQ-04', 'NOT_TESTED', 1),
--     (1, N'DQ-05', 'PASS', 2511),
--     (1, N'DQ-05', 'WARNING', 0),
--     (1, N'DQ-05', 'FAIL', 2489),
--     (1, N'DQ-05', 'NOT_TESTED', 0),
--     (1, N'DQ-06', 'PASS', 2074),
--     (1, N'DQ-06', 'WARNING', 297),
--     (1, N'DQ-06', 'FAIL', 2622),
--     (1, N'DQ-06', 'NOT_TESTED', 7),
--     (1, N'DQ-07', 'PASS', 2594),
--     (1, N'DQ-07', 'WARNING', 0),
--     (1, N'DQ-07', 'FAIL', 2406),
--     (1, N'DQ-07', 'NOT_TESTED', 0),
--     (1, N'DQ-08', 'PASS', 390),
--     (1, N'DQ-08', 'WARNING', 0),
--     (1, N'DQ-08', 'FAIL', 1368),
--     (1, N'DQ-08', 'NOT_TESTED', 3242),
--     (1, N'DQ-09', 'PASS', 1934),
--     (1, N'DQ-09', 'WARNING', 0),
--     (1, N'DQ-09', 'FAIL', 324),
--     (1, N'DQ-09', 'NOT_TESTED', 2742),
--     (1, N'DQ-10', 'PASS', 948),
--     (1, N'DQ-10', 'WARNING', 242),
--     (1, N'DQ-10', 'FAIL', 679),
--     (1, N'DQ-10', 'NOT_TESTED', 3131),
--     (1, N'DQ-11', 'PASS', 4825),
--     (1, N'DQ-11', 'WARNING', 0),
--     (1, N'DQ-11', 'FAIL', 0),
--     (1, N'DQ-11', 'NOT_TESTED', 175),
--     (1, N'DQ-12', 'PASS', 4248),
--     (1, N'DQ-12', 'WARNING', 0),
--     (1, N'DQ-12', 'FAIL', 752),
--     (1, N'DQ-12', 'NOT_TESTED', 0),
--     (1, N'DQ-13', 'PASS', 473),
--     (1, N'DQ-13', 'WARNING', 507),
--     (1, N'DQ-13', 'FAIL', 1516),
--     (1, N'DQ-13', 'NOT_TESTED', 2504),
--     (1, N'DQ-14', 'PASS', 1907),
--     (1, N'DQ-14', 'WARNING', 2),
--     (1, N'DQ-14', 'FAIL', 4),
--     (1, N'DQ-14', 'NOT_TESTED', 3087),
--     (2, N'DQ-01', 'PASS', 15073),
--     (2, N'DQ-01', 'WARNING', 0),
--     (2, N'DQ-01', 'FAIL', 12251),
--     (2, N'DQ-01', 'NOT_TESTED', 17625),
--     (2, N'DQ-02', 'PASS', 36905),
--     (2, N'DQ-02', 'WARNING', 0),
--     (2, N'DQ-02', 'FAIL', 3172),
--     (2, N'DQ-02', 'NOT_TESTED', 4872),
--     (2, N'DQ-04', 'PASS', 39319),
--     (2, N'DQ-04', 'WARNING', 0),
--     (2, N'DQ-04', 'FAIL', 0),
--     (2, N'DQ-04', 'NOT_TESTED', 5630),
--     (2, N'DQ-05', 'PASS', 33872),
--     (2, N'DQ-05', 'WARNING', 0),
--     (2, N'DQ-05', 'FAIL', 11077),
--     (2, N'DQ-05', 'NOT_TESTED', 0),
--     (2, N'DQ-06', 'PASS', 25347),
--     (2, N'DQ-06', 'WARNING', 2997),
--     (2, N'DQ-06', 'FAIL', 10984),
--     (2, N'DQ-06', 'NOT_TESTED', 5621),
--     (2, N'DQ-10', 'PASS', 23915),
--     (2, N'DQ-10', 'WARNING', 1004),
--     (2, N'DQ-10', 'FAIL', 2405),
--     (2, N'DQ-10', 'NOT_TESTED', 17625),
--     (2, N'DQ-11', 'PASS', 37257),
--     (2, N'DQ-11', 'WARNING', 0),
--     (2, N'DQ-11', 'FAIL', 0),
--     (2, N'DQ-11', 'NOT_TESTED', 7692),
--     (2, N'DQ-12', 'PASS', 39314),
--     (2, N'DQ-12', 'WARNING', 0),
--     (2, N'DQ-12', 'FAIL', 5635),
--     (2, N'DQ-12', 'NOT_TESTED', 0),
--     (3, N'DQ-04', 'PASS', 164021),
--     (3, N'DQ-04', 'WARNING', 19),
--     (3, N'DQ-04', 'FAIL', 0),
--     (3, N'DQ-04', 'NOT_TESTED', 3513),
--     (3, N'DQ-05', 'PASS', 120764),
--     (3, N'DQ-05', 'WARNING', 0),
--     (3, N'DQ-05', 'FAIL', 46789),
--     (3, N'DQ-05', 'NOT_TESTED', 0),
--     (3, N'DQ-06', 'PASS', 122098),
--     (3, N'DQ-06', 'WARNING', 39290),
--     (3, N'DQ-06', 'FAIL', 483),
--     (3, N'DQ-06', 'NOT_TESTED', 5682),
--     (3, N'DQ-12', 'PASS', 161829),
--     (3, N'DQ-12', 'WARNING', 0),
--     (3, N'DQ-12', 'FAIL', 5724),
--     (3, N'DQ-12', 'NOT_TESTED', 0),
--     (3, N'DQ-13', 'PASS', 50042),
--     (3, N'DQ-13', 'WARNING', 28849),
--     (3, N'DQ-13', 'FAIL', 32539),
--     (3, N'DQ-13', 'NOT_TESTED', 56123);
--
-- CREATE TABLE #AttenduScore (Famille nvarchar(20) NOT NULL, Valeur nvarchar(40) NOT NULL, Attendu bigint NOT NULL);
-- INSERT #AttenduScore VALUES
--     (N'Verdict', N'Bonne', 1319),
--     (N'Verdict', N'Mauvaise', 1438),
--     (N'Verdict', N'Non évaluable', 8),
--     (N'Verdict', N'À surveiller', 2235),
--     (N'Imputation', N'Exclure', 467),
--     (N'Imputation', N'Imputer', 1939),
--     (N'Imputation', N'Rien à imputer', 2594),
--     (N'VerdictArret', N'Bonne', 26688),
--     (N'VerdictArret', N'Mauvaise', 2009),
--     (N'VerdictArret', N'Non évaluable', 4872),
--     (N'VerdictArret', N'À surveiller', 11380);
--
-- CREATE TABLE #AttenduVolume (Mesure nvarchar(40) NOT NULL, Attendu bigint NOT NULL);
-- INSERT #AttenduVolume VALUES (N'Trains', 5000), (N'Arrêts', 44949), (N'Arrêts mesurés', 40077), (N'Véhicules x arrêts', 167553),
--                              (N'EVN distincts', 162), (N'Gares (codes distincts)', 82);
--
-- -- 1. Statuts par règle et par maille
-- SELECT N'Règle' AS Controle, a.RuleCode, CASE a.GrainLevel WHEN 1 THEN N'Train' WHEN 2 THEN N'Arrêt' ELSE N'Véhicule' END AS Maille,
--        a.[Status], a.Attendu, COALESCE(o.n, 0) AS Obtenu, COALESCE(o.n, 0) - a.Attendu AS Ecart,
--        CASE WHEN COALESCE(o.n, 0) = a.Attendu THEN 'OK' ELSE 'ECART' END AS Resultat
-- FROM #AttenduRegle AS a
-- LEFT JOIN (SELECT GrainLevel, RuleCode, [Status], n = COUNT_BIG(*)
--            FROM audit.vw_DQ_LogsEnrichis WHERE ExecutionId = @ExecutionId AND SourceName = N'SIV_APC'
--            GROUP BY GrainLevel, RuleCode, [Status]) AS o
--        ON o.GrainLevel = a.GrainLevel AND o.RuleCode = a.RuleCode AND o.[Status] = a.[Status]
-- ORDER BY CASE WHEN COALESCE(o.n, 0) = a.Attendu THEN 1 ELSE 0 END, a.GrainLevel, a.RuleCode, a.[Status];
--
-- -- 2. Verdicts, décisions d'imputation, verdicts par arrêt
-- SELECT N'Score' AS Controle, a.Famille, a.Valeur, a.Attendu, COALESCE(o.n, 0) AS Obtenu, COALESCE(o.n, 0) - a.Attendu AS Ecart,
--        CASE WHEN COALESCE(o.n, 0) = a.Attendu THEN 'OK' ELSE 'ECART' END AS Resultat
-- FROM #AttenduScore AS a
-- LEFT JOIN (SELECT Famille = N'Verdict', Valeur = Verdict, n = COUNT_BIG(*) FROM audit.ScoresDQ WHERE GrainLevel = 1 AND IsCurrent = 1 AND SourceName = N'SIV_APC' GROUP BY Verdict
--            UNION ALL SELECT N'Imputation', Imputation, COUNT_BIG(*) FROM audit.ScoresDQ WHERE GrainLevel = 1 AND IsCurrent = 1 AND SourceName = N'SIV_APC' GROUP BY Imputation
--            UNION ALL SELECT N'VerdictArret', Verdict, COUNT_BIG(*) FROM audit.ScoresDQ WHERE GrainLevel = 2 AND IsCurrent = 1 AND SourceName = N'SIV_APC' GROUP BY Verdict) AS o
--        ON o.Famille = a.Famille AND o.Valeur = a.Valeur
-- ORDER BY CASE WHEN COALESCE(o.n, 0) = a.Attendu THEN 1 ELSE 0 END, a.Famille, a.Valeur;
--
-- -- 3. Volumes de la couche de parsing
-- SELECT N'Volume' AS Controle, a.Mesure, a.Attendu, o.n AS Obtenu, o.n - a.Attendu AS Ecart,
--        CASE WHEN o.n = a.Attendu THEN 'OK' ELSE 'ECART' END AS Resultat
-- FROM #AttenduVolume AS a
-- JOIN (SELECT N'Trains' AS Mesure, COUNT_BIG(*) AS n FROM comptage_API.DQ_Train
--       UNION ALL SELECT N'Arrêts', COUNT_BIG(*) FROM comptage_API.DQ_Arret
--       UNION ALL SELECT N'Arrêts mesurés', COUNT_BIG(*) FROM comptage_API.DQ_Arret WHERE HasData = 1
--       UNION ALL SELECT N'Véhicules x arrêts', COUNT_BIG(*) FROM comptage_API.DQ_ArretEVN
--       UNION ALL SELECT N'EVN distincts', COUNT_BIG(DISTINCT EVN) FROM comptage_API.DQ_ArretEVN
--       UNION ALL SELECT N'Gares (codes distincts)', COUNT_BIG(DISTINCT StationCode) FROM comptage_API.DQ_Arret) AS o ON o.Mesure = a.Mesure;
--
-- -- 4. Cohérence interne : une seule ligne courante par règle et par objet
-- SELECT N'Unicité' AS Controle, COUNT_BIG(*) AS NbDoublonsCourants,
--        CASE WHEN COUNT_BIG(*) = 0 THEN 'OK' ELSE 'ECART' END AS Resultat
-- FROM (SELECT RegleDQID, RunId FROM audit.LogsDQ WHERE IsCurrent = 1 GROUP BY RegleDQID, RunId HAVING COUNT_BIG(*) > 1) AS d;
--
-- -- 5. Cohérence du modèle Power BI avec les résultats
-- SELECT N'Modèle' AS Controle,
--        (SELECT COUNT_BIG(*) FROM comptage_API.DQ_DimTrain) AS Trains_DimTrain, (SELECT COUNT_BIG(*) FROM comptage_API.DQ_Train) AS Trains_apc,
--        (SELECT COUNT_BIG(*) FROM comptage_API.DQ_FaitResultat) AS Lignes_FaitResultat,
--        (SELECT COUNT_BIG(*) FROM audit.LogsDQ WHERE IsCurrent = 1) AS Lignes_LogsDQ_courantes,
--        CASE WHEN (SELECT COUNT_BIG(*) FROM comptage_API.DQ_FaitResultat) = (SELECT COUNT_BIG(*) FROM audit.LogsDQ WHERE IsCurrent = 1)
--              AND (SELECT COUNT_BIG(*) FROM comptage_API.DQ_DimTrain) = (SELECT COUNT_BIG(*) FROM comptage_API.DQ_Train) THEN 'OK' ELSE 'ECART' END AS Resultat;
-- GO
--

/*==============================================================================
 ANNEXE B - Exemples d'appel depuis SSIS et SQL Agent
 Source : sql/ssis/execute_sql_task.sql
 Exemples de commandes à copier dans une tâche Exécuter SQL ou une étape de job. Lignes commentées.
===============================================================================*/

-- /*
-- ================================================================================
--  Exemples d'appel depuis SSIS / SQL Server Agent (après le chargement de la table source)
-- ================================================================================
-- */
--
-- -- ---------------------------------------------------------------------------
-- -- A. Cas recommandé : UNE tâche « Exécuter une tâche SQL » après le chargement de la table comptage API
-- --    (SQLStatement ci-dessous ; les deux ? sont mappés sur les variables SSIS DateDebut / DateFin, type DATE)
-- -- ---------------------------------------------------------------------------
-- EXEC audit.usp_DQ_Pipeline_SIV_APC
--      @DateDebut       = ?,
--      @DateFin         = ?,
--      @SsisExecutionId = NULL;       -- ou la variable système ServerExecutionID du package, pour la corrélation SSISDB
--
-- -- ---------------------------------------------------------------------------
-- -- B. Variante « proposition V1 » à la lettre : une tâche de préparation, puis l'orchestrateur seul
-- --    (l'orchestrateur ne fait que lancer les règles actives ; score et modèle sont alors des tâches suivantes)
-- -- ---------------------------------------------------------------------------
-- -- tâche 07 (préparation) :
-- --   EXEC comptage_API.usp_DQ_ChargerStaging @DateDebut = ?, @DateFin = ?;
-- --   EXEC comptage_API.usp_DQ_ParserStaging  @DateDebut = ?, @DateFin = ?;
-- -- tâche 08 (règles DQ, commande unique de la V1) :
-- EXEC audit.usp_DQ_ExecuterRegles
--      @SourceName  = N'SIV_APC',
--      @DateDebut   = ?,
--      @DateFin     = ?,
--      @ExecutionId = NULL;
-- -- tâches 09 et 10 (score et modèle ; nécessitent l'ExecutionId : variable SSIS alimentée par un OUTPUT) :
-- --   EXEC audit.usp_DQ_CalculerScore @SourceName = N'SIV_APC', @ExecutionId = ?, @DateDebut = ?, @DateFin = ?;
-- --   EXEC comptage_API.usp_DQ_RafraichirModele  @SourceName = N'SIV_APC', @DateDebut = ?, @DateFin = ?;
--
-- -- ---------------------------------------------------------------------------
-- -- C. Étape SQL Server Agent (T-SQL) avec la fenêtre par défaut J-3 à J-1
-- -- ---------------------------------------------------------------------------
-- -- EXEC audit.usp_DQ_Pipeline_SIV_APC;
--
-- -- ---------------------------------------------------------------------------
-- -- D. Relance ciblée d'une seule règle (test, correction d'un seuil)
-- -- ---------------------------------------------------------------------------
-- -- DECLARE @e bigint;
-- -- EXEC audit.usp_DQ_OuvrirExecution N'SIV_APC', '2026-08-04', '2026-08-26', @e OUTPUT;
-- -- EXEC audit.usp_DQ_BR_DQ03_RemiseZeroTerminus N'SIV_APC', (SELECT RegleDQID FROM audit.ReglesDQ WHERE RuleCode = N'DQ-03'), @e, '2026-08-04', '2026-08-26';
-- -- EXEC audit.usp_DQ_CloreExecution @e, 'Succes';
--
