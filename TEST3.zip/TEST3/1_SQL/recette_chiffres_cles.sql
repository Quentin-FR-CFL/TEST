/*
================================================================================
 Recette : compare les résultats SQL aux chiffres de référence du moteur Python
================================================================================
 Chiffres de référence : sorties de src/dq_engine.py et src/score_engine.py avec les décisions validées le
 2026-11-11 (PR #12), sur l'extraction d'août 2026 (5 000 trains, 4 au 26 août). A utiliser UNIQUEMENT :
   - avec ce jeu de données chargé dans la table source ;
   - avec les variantes par défaut (ParamsJson.variante = ACTUELLE pour DQ-06, DQ-08, DQ-13) ;
   - après un pipeline sur toute la période : EXEC audit.usp_DQ_Pipeline_SIV_APC '2026-08-04', '2026-08-26';
 Lecture : un écart (Resultat = 'ECART') est à expliquer avant la mise en service. Les écarts de score affichés
 de 0,1 point (arrondi) ne sont pas testés ici ; les verdicts et décisions d'imputation le sont.
 Après la recette : re-exécuter le pipeline sur la même fenêtre et vérifier que les comptes courants sont identiques
 (rejouabilité), puis que audit.LogsDQ garde l'historique (IsCurrent = 0 pour l'ancienne exécution).
================================================================================
*/
USE CFL_GOV;
GO

DECLARE @ExecutionId bigint = (SELECT MAX(ExecutionId) FROM audit.ExecutionsDQ WHERE SourceName = N'SIV_APC' AND Statut = 'Succes');
PRINT CONCAT(N'Exécution contrôlée : ', @ExecutionId);

CREATE TABLE #AttenduRegle (GrainLevel tinyint NOT NULL, RuleCode nvarchar(20) NOT NULL, [Status] varchar(12) NOT NULL, Attendu bigint NOT NULL);
INSERT #AttenduRegle VALUES
    (1, N'DQ-01', 'PASS', 1029),
    (1, N'DQ-01', 'WARNING', 0),
    (1, N'DQ-01', 'FAIL', 2047),
    (1, N'DQ-01', 'NOT_TESTED', 1924),
    (1, N'DQ-02', 'PASS', 4517),
    (1, N'DQ-02', 'WARNING', 0),
    (1, N'DQ-02', 'FAIL', 483),
    (1, N'DQ-02', 'NOT_TESTED', 0),
    (1, N'DQ-03', 'PASS', 1173),
    (1, N'DQ-03', 'WARNING', 0),
    (1, N'DQ-03', 'FAIL', 1183),
    (1, N'DQ-03', 'NOT_TESTED', 2644),
    (1, N'DQ-04', 'PASS', 4996),
    (1, N'DQ-04', 'WARNING', 3),
    (1, N'DQ-04', 'FAIL', 0),
    (1, N'DQ-04', 'NOT_TESTED', 1),
    (1, N'DQ-05', 'PASS', 2511),
    (1, N'DQ-05', 'WARNING', 0),
    (1, N'DQ-05', 'FAIL', 2489),
    (1, N'DQ-05', 'NOT_TESTED', 0),
    (1, N'DQ-06', 'PASS', 2074),
    (1, N'DQ-06', 'WARNING', 297),
    (1, N'DQ-06', 'FAIL', 2622),
    (1, N'DQ-06', 'NOT_TESTED', 7),
    (1, N'DQ-07', 'PASS', 2594),
    (1, N'DQ-07', 'WARNING', 0),
    (1, N'DQ-07', 'FAIL', 2406),
    (1, N'DQ-07', 'NOT_TESTED', 0),
    (1, N'DQ-08', 'PASS', 390),
    (1, N'DQ-08', 'WARNING', 0),
    (1, N'DQ-08', 'FAIL', 1368),
    (1, N'DQ-08', 'NOT_TESTED', 3242),
    (1, N'DQ-09', 'PASS', 1934),
    (1, N'DQ-09', 'WARNING', 0),
    (1, N'DQ-09', 'FAIL', 324),
    (1, N'DQ-09', 'NOT_TESTED', 2742),
    (1, N'DQ-10', 'PASS', 948),
    (1, N'DQ-10', 'WARNING', 242),
    (1, N'DQ-10', 'FAIL', 679),
    (1, N'DQ-10', 'NOT_TESTED', 3131),
    (1, N'DQ-11', 'PASS', 4825),
    (1, N'DQ-11', 'WARNING', 0),
    (1, N'DQ-11', 'FAIL', 0),
    (1, N'DQ-11', 'NOT_TESTED', 175),
    (1, N'DQ-12', 'PASS', 4248),
    (1, N'DQ-12', 'WARNING', 0),
    (1, N'DQ-12', 'FAIL', 752),
    (1, N'DQ-12', 'NOT_TESTED', 0),
    (1, N'DQ-13', 'PASS', 473),
    (1, N'DQ-13', 'WARNING', 507),
    (1, N'DQ-13', 'FAIL', 1516),
    (1, N'DQ-13', 'NOT_TESTED', 2504),
    (1, N'DQ-14', 'PASS', 1907),
    (1, N'DQ-14', 'WARNING', 2),
    (1, N'DQ-14', 'FAIL', 4),
    (1, N'DQ-14', 'NOT_TESTED', 3087),
    (2, N'DQ-01', 'PASS', 15073),
    (2, N'DQ-01', 'WARNING', 0),
    (2, N'DQ-01', 'FAIL', 12251),
    (2, N'DQ-01', 'NOT_TESTED', 17625),
    (2, N'DQ-02', 'PASS', 36905),
    (2, N'DQ-02', 'WARNING', 0),
    (2, N'DQ-02', 'FAIL', 3172),
    (2, N'DQ-02', 'NOT_TESTED', 4872),
    (2, N'DQ-04', 'PASS', 39319),
    (2, N'DQ-04', 'WARNING', 0),
    (2, N'DQ-04', 'FAIL', 0),
    (2, N'DQ-04', 'NOT_TESTED', 5630),
    (2, N'DQ-05', 'PASS', 33872),
    (2, N'DQ-05', 'WARNING', 0),
    (2, N'DQ-05', 'FAIL', 11077),
    (2, N'DQ-05', 'NOT_TESTED', 0),
    (2, N'DQ-06', 'PASS', 25347),
    (2, N'DQ-06', 'WARNING', 2997),
    (2, N'DQ-06', 'FAIL', 10984),
    (2, N'DQ-06', 'NOT_TESTED', 5621),
    (2, N'DQ-10', 'PASS', 23915),
    (2, N'DQ-10', 'WARNING', 1004),
    (2, N'DQ-10', 'FAIL', 2405),
    (2, N'DQ-10', 'NOT_TESTED', 17625),
    (2, N'DQ-11', 'PASS', 37257),
    (2, N'DQ-11', 'WARNING', 0),
    (2, N'DQ-11', 'FAIL', 0),
    (2, N'DQ-11', 'NOT_TESTED', 7692),
    (2, N'DQ-12', 'PASS', 39314),
    (2, N'DQ-12', 'WARNING', 0),
    (2, N'DQ-12', 'FAIL', 5635),
    (2, N'DQ-12', 'NOT_TESTED', 0),
    (3, N'DQ-04', 'PASS', 164021),
    (3, N'DQ-04', 'WARNING', 19),
    (3, N'DQ-04', 'FAIL', 0),
    (3, N'DQ-04', 'NOT_TESTED', 3513),
    (3, N'DQ-05', 'PASS', 120764),
    (3, N'DQ-05', 'WARNING', 0),
    (3, N'DQ-05', 'FAIL', 46789),
    (3, N'DQ-05', 'NOT_TESTED', 0),
    (3, N'DQ-06', 'PASS', 122098),
    (3, N'DQ-06', 'WARNING', 39290),
    (3, N'DQ-06', 'FAIL', 483),
    (3, N'DQ-06', 'NOT_TESTED', 5682),
    (3, N'DQ-12', 'PASS', 161829),
    (3, N'DQ-12', 'WARNING', 0),
    (3, N'DQ-12', 'FAIL', 5724),
    (3, N'DQ-12', 'NOT_TESTED', 0),
    (3, N'DQ-13', 'PASS', 50042),
    (3, N'DQ-13', 'WARNING', 28849),
    (3, N'DQ-13', 'FAIL', 32539),
    (3, N'DQ-13', 'NOT_TESTED', 56123);

CREATE TABLE #AttenduScore (Famille nvarchar(20) NOT NULL, Valeur nvarchar(40) NOT NULL, Attendu bigint NOT NULL);
INSERT #AttenduScore VALUES
    (N'Verdict', N'Bonne', 1319),
    (N'Verdict', N'Mauvaise', 1438),
    (N'Verdict', N'Non évaluable', 8),
    (N'Verdict', N'À surveiller', 2235),
    (N'Imputation', N'Exclure', 467),
    (N'Imputation', N'Imputer', 1939),
    (N'Imputation', N'Rien à imputer', 2594),
    (N'VerdictArret', N'Bonne', 26688),
    (N'VerdictArret', N'Mauvaise', 2009),
    (N'VerdictArret', N'Non évaluable', 4872),
    (N'VerdictArret', N'À surveiller', 11380);

CREATE TABLE #AttenduVolume (Mesure nvarchar(40) NOT NULL, Attendu bigint NOT NULL);
INSERT #AttenduVolume VALUES (N'Trains', 5000), (N'Arrêts', 44949), (N'Arrêts mesurés', 40077), (N'Véhicules x arrêts', 167553),
                             (N'EVN distincts', 162), (N'Gares (codes distincts)', 82);

-- 1. Statuts par règle et par maille
SELECT N'Règle' AS Controle, a.RuleCode, CASE a.GrainLevel WHEN 1 THEN N'Train' WHEN 2 THEN N'Arrêt' ELSE N'Véhicule' END AS Maille,
       a.[Status], a.Attendu, COALESCE(o.n, 0) AS Obtenu, COALESCE(o.n, 0) - a.Attendu AS Ecart,
       CASE WHEN COALESCE(o.n, 0) = a.Attendu THEN 'OK' ELSE 'ECART' END AS Resultat
FROM #AttenduRegle AS a
LEFT JOIN (SELECT GrainLevel, RuleCode, [Status], n = COUNT_BIG(*)
           FROM audit.vw_DQ_LogsEnrichis WHERE ExecutionId = @ExecutionId AND SourceName = N'SIV_APC'
           GROUP BY GrainLevel, RuleCode, [Status]) AS o
       ON o.GrainLevel = a.GrainLevel AND o.RuleCode = a.RuleCode AND o.[Status] = a.[Status]
ORDER BY CASE WHEN COALESCE(o.n, 0) = a.Attendu THEN 1 ELSE 0 END, a.GrainLevel, a.RuleCode, a.[Status];

-- 2. Verdicts, décisions d'imputation, verdicts par arrêt
SELECT N'Score' AS Controle, a.Famille, a.Valeur, a.Attendu, COALESCE(o.n, 0) AS Obtenu, COALESCE(o.n, 0) - a.Attendu AS Ecart,
       CASE WHEN COALESCE(o.n, 0) = a.Attendu THEN 'OK' ELSE 'ECART' END AS Resultat
FROM #AttenduScore AS a
LEFT JOIN (SELECT Famille = N'Verdict', Valeur = Verdict, n = COUNT_BIG(*) FROM audit.ScoresDQ WHERE GrainLevel = 1 AND IsCurrent = 1 AND SourceName = N'SIV_APC' GROUP BY Verdict
           UNION ALL SELECT N'Imputation', Imputation, COUNT_BIG(*) FROM audit.ScoresDQ WHERE GrainLevel = 1 AND IsCurrent = 1 AND SourceName = N'SIV_APC' GROUP BY Imputation
           UNION ALL SELECT N'VerdictArret', Verdict, COUNT_BIG(*) FROM audit.ScoresDQ WHERE GrainLevel = 2 AND IsCurrent = 1 AND SourceName = N'SIV_APC' GROUP BY Verdict) AS o
       ON o.Famille = a.Famille AND o.Valeur = a.Valeur
ORDER BY CASE WHEN COALESCE(o.n, 0) = a.Attendu THEN 1 ELSE 0 END, a.Famille, a.Valeur;

-- 3. Volumes de la couche de parsing
SELECT N'Volume' AS Controle, a.Mesure, a.Attendu, o.n AS Obtenu, o.n - a.Attendu AS Ecart,
       CASE WHEN o.n = a.Attendu THEN 'OK' ELSE 'ECART' END AS Resultat
FROM #AttenduVolume AS a
JOIN (SELECT N'Trains' AS Mesure, COUNT_BIG(*) AS n FROM comptage_API.DQ_Train
      UNION ALL SELECT N'Arrêts', COUNT_BIG(*) FROM comptage_API.DQ_Arret
      UNION ALL SELECT N'Arrêts mesurés', COUNT_BIG(*) FROM comptage_API.DQ_Arret WHERE HasData = 1
      UNION ALL SELECT N'Véhicules x arrêts', COUNT_BIG(*) FROM comptage_API.DQ_ArretEVN
      UNION ALL SELECT N'EVN distincts', COUNT_BIG(DISTINCT EVN) FROM comptage_API.DQ_ArretEVN
      UNION ALL SELECT N'Gares (codes distincts)', COUNT_BIG(DISTINCT StationCode) FROM comptage_API.DQ_Arret) AS o ON o.Mesure = a.Mesure;

-- 4. Cohérence interne : une seule ligne courante par règle et par objet
SELECT N'Unicité' AS Controle, COUNT_BIG(*) AS NbDoublonsCourants,
       CASE WHEN COUNT_BIG(*) = 0 THEN 'OK' ELSE 'ECART' END AS Resultat
FROM (SELECT RegleDQID, RunId FROM audit.LogsDQ WHERE IsCurrent = 1 GROUP BY RegleDQID, RunId HAVING COUNT_BIG(*) > 1) AS d;

-- 5. Cohérence du modèle Power BI avec les résultats
SELECT N'Modèle' AS Controle,
       (SELECT COUNT_BIG(*) FROM comptage_API.DQ_DimTrain) AS Trains_DimTrain, (SELECT COUNT_BIG(*) FROM comptage_API.DQ_Train) AS Trains_apc,
       (SELECT COUNT_BIG(*) FROM comptage_API.DQ_FaitResultat) AS Lignes_FaitResultat,
       (SELECT COUNT_BIG(*) FROM audit.LogsDQ WHERE IsCurrent = 1) AS Lignes_LogsDQ_courantes,
       CASE WHEN (SELECT COUNT_BIG(*) FROM comptage_API.DQ_FaitResultat) = (SELECT COUNT_BIG(*) FROM audit.LogsDQ WHERE IsCurrent = 1)
             AND (SELECT COUNT_BIG(*) FROM comptage_API.DQ_DimTrain) = (SELECT COUNT_BIG(*) FROM comptage_API.DQ_Train) THEN 'OK' ELSE 'ECART' END AS Resultat;
GO
