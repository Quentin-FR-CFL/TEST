# TEST4 : moteur DQ générique, mise en place pas à pas

> **Rien n'a été testé** (SQL Server, SSIS, Power BI Desktop). Fais tout en **DEV**. Chaque étape a un « Je crée » et un « Je vérifie » : ne passe pas à la suite si la vérification échoue. Concepts et extension : [11_moteur_generique.md](11_moteur_generique.md). TEST3 reste le plan B (ne mélange pas les deux scripts sur la même base).

```
Source (ODS, intouchée)
  └─ SSIS STA  : un master, paramètre SourceName ──► audit.usp_DQ_Preparer (domaine) ──► règles ──► score
       └─ SSIS DWH : un master ──► audit.usp_DQ_RafraichirModele ──► étoile générique DQ_Dim* / DQ_Fait*
            └─ Power BI (.pbix, import) : 10 tables, 8 pages, aucun mot métier dans le modèle
```

## PARTIE 1 : SQL Server
1. **Prérequis** : base `CFL_GOV`, `comptage_API.Counting` alimentée. *Je vérifie* : `SELECT COUNT(*) FROM comptage_API.Counting;` > 0.
2. **Installer** : ouvrir `1_SQL/DQ_script_unique.sql` dans SSMS (connecté à `CFL_GOV`), exécuter en entier. Rejouable. Il migre TEST3 : anciennes vues et tables d'étoile supprimées, `LogsDQ` et `ScoresDQ` recréés si ancienne forme.
   *Je vérifie* :
   ```sql
   SELECT SourceName, ProcPreparation, ProcDecision, ProcModele FROM audit.DomainesDQ;   -- 1 ligne SIV_APC
   SELECT Niveau, Nom, NiveauParent, EstMailleScore FROM audit.MaillesDQ ORDER BY Niveau; -- Train, Arrêt, Véhicule
   SELECT COUNT(*) FROM audit.ReglesDQ;                                                   -- 14
   SELECT name FROM sys.views WHERE schema_id IN (SCHEMA_ID('audit'),SCHEMA_ID('comptage_API')); -- vw_DQ_SourceTrain, vw_DQ_TrainMotif, vw_DQ_LogsEnrichis
   ```
3. **Premier passage en SQL seul** :
   ```sql
   EXEC audit.usp_DQ_Pipeline @SourceName = N'SIV_APC', @DateDebut = '2026-08-04', @DateFin = '2026-08-26';
   ```
   *Je vérifie* :
   ```sql
   SELECT TOP (3) ExecutionId, Statut, NbObjets, NbReglesEnErreur, Message FROM audit.ExecutionsDQ ORDER BY ExecutionId DESC; -- Succes
   SELECT COUNT(*) FROM audit.ObjetsDQ WHERE Niveau = 1;                                   -- = nombre de trains de la fenêtre
   SELECT RuleCode, [Status], COUNT_BIG(*) N FROM audit.vw_DQ_LogsEnrichis WHERE IsCurrent = 1 GROUP BY RuleCode,[Status] ORDER BY 1,2; -- 14 règles
   SELECT TOP (10) Cle1, Libelle, Score, Verdict, Decision, Indicateur FROM audit.ScoresDQ ORDER BY ScoreDQID DESC;
   SELECT COUNT(*) FROM comptage_API.DQ_DimObjet; SELECT COUNT(*) FROM comptage_API.DQ_FaitResultat;
   ```
   Rejeu : mêmes commandes, résultats courants identiques, ancienne exécution en `IsCurrent = 0`.
4. **Recette** (jeu d'août 2026 uniquement) : `1_SQL/recette_chiffres_cles.sql`. Un `ECART` s'explique avant mise en service.
5. **Droits** : `ALTER ROLE db_dq_executeur ADD MEMBER [compte SSIS]; ALTER ROLE db_dq_lecteur ADD MEMBER [compte Power BI];`. *Je vérifie* : le compte Power BI lit `DQ_DimObjet`, pas `audit.LogsDQ`.
6. **Changer le score sans toucher Power BI** : `UPDATE audit.ReglesDQ SET ScoreWeight = 2 WHERE RuleCode = N'DQ-01';` ; seuils et imputation dans `audit.ParametresDQ` ; relancer le pipeline.

## PARTIE 2 : SSIS (2 masters)
Dossier `2_SSIS` : `CFL_STA_COMPTAGE/SIV_MasterPackage_OdsToSta.dtsx`, `CFL_DWH_COMPTAGE/SIV_MasterPackage_StaToDwh.dtsx`, `generer_packages.py`.
1. **GUID de `CM_STA`** : le fichier contient `{00000000-0000-0000-0000-000000000000}`. Remplace-le par le `DTS:DTSID` de `CM_STA.conmgr` de chaque projet (le projet DWH a le sien), ou : `python generer_packages.py --sta-cm-sta {GUID_STA} --dwh-cm-sta {GUID_DWH}`. *Je vérifie* : plus de GUID nul.
2. **STA** : sauvegarder le projet ; supprimer `SIV_Dq_Counting_Parsing`, `_Regles`, `_Score` s'ils existent ; remplacer le master ; l'ouvrir. *Je vérifie* : paramètres `SourceName` (`SIV_APC`), `NbJoursFenetre` ; tâches *Initialiser batch* → *Fenêtre de dates* → *Ouvrir l'exécution DQ* → `SIV_Split_Counting_Station_EVN` (existant) → **un seul** *Préparer le domaine* (`audit.usp_DQ_Preparer`) → *Exécuter les règles* → *Calculer le score* → *Clore* / *Finaliser batch*.
3. **DWH** : supprimer `SIV_Dwh_Counting_Modele` et `_Controle`, remplacer le master. *Je vérifie* : *Rafraîchir le modèle* (`usp_DQ_RafraichirModele`) → *Contrôler le modèle* (`usp_DQ_ControlerModele`).
4. **Exécuter** (DEV) STA puis DWH, puis les requêtes de la partie 1 (étape 3). Une règle en FAIL n'est pas une erreur SSIS. Erreur 50060/50061 au contrôle : relancer STA puis DWH.
5. Ordre du job : ODS → STA → DWH. Les tâches `usp_StartNewBatchStep` / `usp_FinalizeBatchStep` sont des **suppositions** : aligne-les sur ton master ODS.
6. **Autre domaine** : même package, `SourceName` = l'autre domaine (voir [11](11_moteur_generique.md) §4).

## PARTIE 3 : Power BI (.pbix, import)
Dossier `3_POWER_BI/powerbi_generique/DQ_Moteur.pbip` (+ `kit_report_server/` en secours). Report Server (mai 2026) ne publie que des `.pbix` : ouvrir le `.pbip` avec un Desktop classique (préversions *PBIP*, *TMDL*, *PBIR* cochées), puis **Enregistrer sous .pbix**.
1. Paramètres (Transformer les données > Gérer les paramètres) : `Serveur`, `BaseDeDonnees` (`CFL_GOV`), `JoursDetail` (30 : jours de détail pour les mailles ≥ 2 ; le niveau racine garde tout l'historique).
2. *Je vérifie* les 10 tables : `DimDate`, `DimStatut`, `DimMaille`, `DimRegle`, `DimObjet`, `DimRacine`, `FaitResultat`, `FaitScore`, `FaitExecution`, `ParametresScore` ; 10 relations (`kit_report_server/relations.txt`), `DimDate` marquée table de dates ; 8 pages avec données ; le nombre d'objets de maille 1 = `SELECT COUNT(*) FROM audit.ObjetsDQ WHERE Niveau = 1`.
3. **Renommer pour le métier** (une fois, dans Power BI) : `DimRacine` → *Train*, `Attr1..5` → noms de `audit.MaillesDQ`, `Objet` → *Train / Arrêt*. Aucun SQL à changer.
4. Enregistrer en `.pbix` (Desktop au plus égal à celui de Report Server, à confirmer), publier, planifier l'actualisation après le job DWH. Secours : kit texte (requêtes M, mesures DAX, relations ; les visuels sont à refaire).

## Points à confirmer et limites
Voir [11_moteur_generique.md](11_moteur_generique.md) §6. En plus : colonnes M explicites (une colonne renommée en SQL casse la requête, l'erreur dit laquelle) ; 4 vues `audit` V1 supprimées (à confirmer qu'aucun rapport ne les lit).
