# Moteur DQ générique (TEST4) : concepts, ajouter une règle, ajouter un domaine

> **Non testé** sur SQL Server, SSIS ni Power BI Desktop (écrit et relu seulement). Les 14 règles, le score et le dashboard Python ne changent pas ; ce qui change, c'est que le moteur ne connaît plus aucun mot métier.

## 1. Principe : le moteur ne connaît que 4 notions

| Notion | Table | Exemple comptage |
|---|---|---|
| **Domaine** : un jeu de données à contrôler | `audit.DomainesDQ` (3 procédures du domaine) | `SIV_APC` |
| **Maille** : un niveau d'objet contrôlé (1 = racine, 2 = enfant…), avec les noms de ses clés et de 5 attributs | `audit.MaillesDQ` | 1 Train, 2 Arrêt, 3 Véhicule |
| **Objet** : une instance de maille, déclarée par la préparation du domaine | `audit.ObjetsDQ` (`Niveau`, `Cle1..3`, `Libelle`, `DateFenetre`, `Attr1..5`) | un train, un arrêt |
| **Règle** : une procédure + une ligne de catalogue (maille, seuils, poids, texte) | `audit.ReglesDQ` | `DQ-01` |

Résultats : `audit.LogsDQ` (règle × objet × exécution), `audit.ScoresDQ` (score et verdict de l'objet racine). Aucune colonne ne porte de mot métier.

```
Domaine ──► procédure de PRÉPARATION (propre au domaine) : staging, contrôles, parsing, remplit audit.ObjetsDQ
        ──► moteur : exécute les règles actives ──► LogsDQ ──► score (mailles EstMailleScore=1) ──► ScoresDQ
        ──► procédure de DÉCISION (facultative, ex. imputation) ──► colonnes Decision / Indicateur / Info1 / Info2
        ──► moteur : étoile générique ──► procédure de MODÈLE (facultative, table de faits propre au domaine)
```

## 2. Étoile générique (restitution)

`DQ_DimDate`, `DQ_DimStatut`, `DQ_DimMaille`, `DQ_DimRegle`, `DQ_DimObjet` (un seul tableau pour toutes les mailles, `Attr1..5`), `DQ_FaitResultat`, `DQ_FaitScore` (+ `DQ_FaitArret`, table de faits **propre au comptage**, facultative). Les faits portent `ObjetRacineKey` et `Niveau` : Power BI filtre un arrêt par les attributs de son train via la table `DimRacine` (même table que `DimObjet`, filtrée sur le niveau 1).

Renommer pour un autre sujet = **dans Power BI uniquement** (nom de table, de colonne, de mesure) ; `Attr1..5` portent les noms de `audit.MaillesDQ` (`Attr1Nom`…) : les reprendre en renommant les colonnes. Le texte des règles, des statuts et des mailles vient des tables de catalogue, pas du code.

## 3. Ajouter une règle (une procédure + une ligne)

1. **Procédure** `audit.usp_DQ_BR_DQxx_Nom (@SourceName, @RegleDQID, @ExecutionId, @DateDebut, @DateFin)`. Elle remplit la table temporaire `#R` puis appelle `audit.usp_DQ_EcrireResultats`. Colonnes **positionnelles** (noms historiques) : `GrainLevel` = **Niveau** de la maille, `CountingId` = **Cle1**, `Rang` = **Cle2**, `VehIdx` = **Cle3**, puis `Status` (`PASS` / `WARNING` / `FAIL` / `NOT_TESTED`), `FailureReason`, `ObservedValue`, `ExpectedValue`, `AbsoluteGap`, `RelativeGap`. Modèle à recopier : `sql/regles/DQ05_EtatMateriel.sql` (la plus courte).
2. **Ligne** dans `audit.ReglesDQ` (voir `sql/12_seed_catalogue.sql`) : `SourceName`, `RuleCode`, nom, ordre, procédure, seuils (`ThresholdPass`, `ThresholdWarning`…), `ScoreWeight`, `IsActive`, texte du calcul.
3. Relancer `EXEC audit.usp_DQ_Pipeline @SourceName = N'…'`. Rien d'autre : le score, l'étoile et Power BI prennent la règle (`DimRegle`, `FaitResultat`).

Un résultat sur un objet absent de `audit.ObjetsDQ` est ignoré (contrôle d'intégrité). Règle sur une maille de rang 1 qui doit remonter d'une maille enfant : `audit.usp_DQ_SyntheseParent` (voir DQ-01).

## 4. Ajouter un domaine (une préparation + des lignes)

1. **Procédure de préparation** `schéma.usp_DQ_Prep_xxx (@DateDebut, @DateFin, @ExecutionId)` : charge et contrôle ses données, **remplit `audit.ObjetsDQ`** (rejouable : supprimer les objets de la fenêtre puis réinsérer). Modèle : `sql/14_domaine_comptage.sql`, partie 1.
2. Procédures **facultatives** : `usp_DQ_Decision_xxx (@SourceName, @ExecutionId, @DateDebut, @DateFin)` (remplit `Decision`, `Indicateur`, `Info1`, `Info2` de `audit.ScoresDQ`) et `usp_DQ_ModeleDomaine_xxx (@SourceName, @DateDebut, @DateFin)` (faits propres au domaine).
3. **Lignes** : `audit.DomainesDQ` (les 3 noms de procédures), `audit.MaillesDQ` (noms des clés et attributs), `audit.ReglesDQ`, `audit.ParametresDQ` (points par statut, seuils de verdict, fenêtre).
4. SSIS : même master STA, paramètre de package `SourceName` = le nouveau domaine. Power BI : même modèle, le modèle lit toutes les lignes de `DQ_*` (un seul domaine par base : si plusieurs, filtrer sur `DQ_DimObjet[SourceName]` ; à confirmer) et renommer.

Seuls les noms de procédures déclarés dans `audit.DomainesDQ` sont appelés (liste blanche, contrôlée avec `OBJECT_ID`).

## 5. Ce qui reste propre au comptage (volontairement isolé)

`sql/14_domaine_comptage.sql` (3 procédures), `sql/01`, `02`, `04`, `05` (source, parsing JSON), les 14 règles `sql/regles/`, la décision d'imputation, `comptage_API.DQ_FaitArret`. Rien de cela n'est appelé par le moteur autrement que par les noms de `audit.DomainesDQ`.

## 6. Limites connues (à confirmer)

- Colonnes de `#R` : noms historiques (`CountingId`, `Rang`, `VehIdx`) mais sens générique ; renommage évité pour ne pas retoucher les 14 règles.
- Le rapport Power BI générique n'a pas les pages propres au comptage (Complétude et imputation, Capteurs DQ-06, 14 colonnes de statut par train, DimGare) : matrice règle × statut à la place. Elles se refont sur `DQ_FaitArret` et `Attr*`.
- Les attributs `Attr1..5` gardent ce nom dans Power BI : à renommer à la main par domaine.
- % FAIL sur longue période : détail limité à `JoursDetail` jours pour les mailles ≥ 2 (voir guide 12).
- Tâches d'audit de batch SSIS (`usp_StartNewBatchStep`, `usp_FinalizeBatchStep`) : suppositions.
- La migration de TEST3 vers TEST4 supprime et recrée `LogsDQ`, `ScoresDQ` et l'étoile : relancer le pipeline sur la fenêtre pour les remplir.
