# TEST4

Pack de déploiement du **moteur DQ générique** (domaine / maille / objet / règle, étoile neutre). Le comptage voyageurs en est le premier domaine.
**Lis `GUIDE_TEST4.md`** : SQL Server, SSIS STA puis DWH, Power BI (.pbix), avec « je crée / je vérifie » à chaque étape. Ajouter une règle ou un domaine : `4_DOCUMENTATION/11_moteur_generique.md`.

| Dossier | Contenu |
|---|---|
| `1_SQL` | `DQ_script_unique.sql` (tout le SQL, rejouable, migre TEST3) et la recette |
| `2_SSIS` | les 2 masters (+ générateur pour les GUID) |
| `3_POWER_BI` | `powerbi_generique/DQ_Moteur.pbip` à ouvrir puis enregistrer en `.pbix`, kit texte de secours |
| `4_DOCUMENTATION` | moteur générique (11), lineage, règles, référentiel, constats |

Rien n'est testé sur un vrai serveur : DEV d'abord. TEST3.zip reste le plan B.
